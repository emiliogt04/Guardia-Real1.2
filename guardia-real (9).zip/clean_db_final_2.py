import json

db = {
  "users": [],
  "companies": [],
  "employees": [],
  "auditLogs": [],
  "notifications": [],
  "guardCheckins": [],
  "securityConfig": {}
}

with open('data/db.json', 'w') as f:
    json.dump(db, f, indent=2)
