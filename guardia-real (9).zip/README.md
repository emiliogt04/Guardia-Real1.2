# Guardia Real

Control de asistencia por QR y nómina quincenal para guardias de seguridad (React + Vite + Express, datos en `data/db.json`).

## Ejecutar en local

Requisitos: Node.js 20 o superior.

```bash
npm install
npm run dev      # http://localhost:3000
```

La primera vez, el servidor crea `data/db.json` con datos iniciales (administrador, empresas y configuración).
Ese archivo contiene datos reales de colaboradores y **no se sube a GitHub** (está en `.gitignore`).
Para trabajar con tus datos, copia tu `db.json` a la carpeta `data/`.

## Scripts

| Comando | Qué hace |
|---|---|
| `npm run dev` | Servidor de desarrollo (Express + Vite) |
| `npm run build` | Compila el frontend en `dist/` |
| `npm start` | Igual que `dev`; con `NODE_ENV=production` sirve `dist/` |
| `npm run lint` | Revisión de tipos con TypeScript |
| `npm test` | Pruebas de la lógica de cuotas por quincena |

## Descuentos por cuotas

Cada descuento guarda su número de cuotas y su **quincena de inicio**. Se aplica solo en las quincenas
desde el inicio hasta `inicio + cuotas - 1`, y se cierra solo al cobrarse la última cuota.
La planilla guardada es un registro fijo: el Centro de Nómina lee lo guardado y no recalcula.
La lógica está en `src/utils/quincenas.ts` (compartida por servidor e interfaz).

## Trabajar con GitHub

- Usa un repositorio **privado**: el código incluye códigos de acceso por defecto y los scripts `.py` traen nombres de personal.
- Trabaja en ramas y abre Pull Requests hacia `main`; el workflow de `.github/workflows/ci.yml` corre pruebas y compilación.
- Las copias de seguridad de `db.json` guárdalas fuera del repositorio.

## Importar en Google AI Studio

Desde un repositorio de GitHub o subiendo el `.zip` del proyecto (con los archivos en la raíz).
La app no necesita `GEMINI_API_KEY` para funcionar.
