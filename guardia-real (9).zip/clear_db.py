import json

with open('data/db.json', 'r') as f:
    db = json.load(f)

db['companies'] = []
db['employees'] = []
db['auditLogs'] = []

with open('data/db.json', 'w') as f:
    json.dump(db, f, indent=2)
