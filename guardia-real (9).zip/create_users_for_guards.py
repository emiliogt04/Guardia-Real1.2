import json
import random

with open('data/db.json', 'r') as f:
    db = json.load(f)

# Crear un conjunto de nombres de usuarios existentes para evitar duplicados
existing_user_names = {u['name'] for u in db['users']}

for emp in db['employees']:
    # Saltar si el usuario ya existe
    if emp['name'] in existing_user_names:
        continue

    # Generar un PIN aleatorio de 4 dígitos
    pin = str(random.randint(1000, 9999))

    new_user = {
        "id": f"user-{emp['id']}",
        "name": emp['name'],
        "username": emp['name'].lower().replace(" ", "."),
        "email": f"{emp['id']}@guardia.com", # Correo temporal
        "role": "GUARD",
        "personalAccessCode": pin,
        "permissions": {
            "canViewCompanies": False,
            "canViewEmployees": False,
            "canViewSalaries": False,
            "canViewAuditLog": False,
            "canScanQR": True,
            "canEditEmployees": False,
            "canCreateEmployees": False,
            "canDeleteEmployees": False,
            "canManageCompanies": False,
            "canExportExcel": False,
            "canModifySalaries": False
        },
        "createdAt": "2026-10-19T08:55:00Z"
    }
    db['users'].append(new_user)

with open('data/db.json', 'w') as f:
    json.dump(db, f, indent=2)
