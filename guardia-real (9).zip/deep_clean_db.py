import json

with open('data/db.json', 'r') as f:
    db = json.load(f)

# Clear business data, keep users
db['companies'] = []
db['employees'] = []
db['auditLogs'] = []
db['notifications'] = []
db['payments'] = []
db['receipts'] = []

with open('data/db.json', 'w') as f:
    json.dump(db, f, indent=2)
