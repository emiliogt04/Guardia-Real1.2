// Ejecutar con: npm test
import assert from 'node:assert/strict';
import {
  QuincenaRef, isDiscountApplicable, getInstallmentNumber, getInstallmentAmount, getDiscountProgress, quincenaKey,
} from '../src/utils/quincenas';

const q = (year: number, month: number, quincena: 1 | 2): QuincenaRef => ({ year, month, quincena });

// Caso del prompt: 3 cuotas con inicio en la 2da quincena de octubre
const d = { amount: 300, installments: 3, startYear: 2026, startMonth: 10, startQuincena: 2, status: 'ACTIVO' };

const cases: [QuincenaRef, boolean][] = [
  [q(2026, 10, 1), false],
  [q(2026, 10, 2), true],   // cuota 1
  [q(2026, 11, 1), true],   // cuota 2
  [q(2026, 11, 2), true],   // cuota 3
  [q(2026, 12, 1), false],
  [q(2026, 12, 2), false],
  [q(2027, 1, 1), false],
];
for (const [target, expected] of cases) {
  assert.equal(isDiscountApplicable(d, target), expected, `aplica en ${quincenaKey(target)}`);
}
assert.equal(getInstallmentNumber(d, q(2026, 10, 2)), 1);
assert.equal(getInstallmentNumber(d, q(2026, 11, 2)), 3);

// Cruce de año: 3 cuotas desde 2da quincena de diciembre -> dic 2da, ene 1ra, ene 2da
const y = { amount: 90, installments: 3, startYear: 2026, startMonth: 12, startQuincena: 2 };
assert.ok(isDiscountApplicable(y, q(2027, 1, 1)) && isDiscountApplicable(y, q(2027, 1, 2)) && !isDiscountApplicable(y, q(2027, 2, 1)));

// Repetir la misma evaluación nunca cambia el resultado (no hay contadores)
for (let i = 0; i < 5; i++) assert.equal(getInstallmentNumber(d, q(2026, 11, 1)), 2);

// Los estados cerrados no se aplican
assert.equal(isDiscountApplicable({ ...d, status: 'FINALIZADO' }, q(2026, 10, 2)), false);

// Redondeo: las cuotas suman exactamente el total
const r = { amount: 100, installments: 3 };
const sum = [1, 2, 3].reduce((a, n) => a + getInstallmentAmount(r, n), 0);
assert.ok(Math.abs(sum - 100) < 1e-9);

// Progreso
const prog = getDiscountProgress({ ...d, paidPeriods: ['2026-10-Q2'] });
assert.deepEqual([prog.applied, prog.remaining, prog.total], [1, 2, 3]);

console.log('Pruebas de quincenas: OK');
