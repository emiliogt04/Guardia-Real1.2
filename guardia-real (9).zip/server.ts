import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { AppUser, Company, Employee, AuditLog, RealtimeNotification, UserPermissions, GuardCheckin, SystemSecurityConfig, StoreCheckpoint, GuardPayment, GuardDiscount, PaymentReceipt } from './src/types';
import {
  MONTH_NAMES_ES, QuincenaRef, quincenaIndex, quincenaKey, quincenaLabel, parseQuincenaRef, quincenaFromDate,
  currentQuincena, normalizePeriodKey, getStartQuincena, getTotalInstallments, getInstallmentNumber,
  getInstallmentAmount, isDiscountApplicable,
} from './src/utils/quincenas';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Persistent database file setup
const DATA_DIR = path.resolve(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export interface DatabaseSchema {
  users: AppUser[];
  companies: Company[];
  employees: Employee[];
  auditLogs: AuditLog[];
  notifications: RealtimeNotification[];
  guardCheckins: GuardCheckin[];
  payments: GuardPayment[];
  receipts: PaymentReceipt[];
  securityConfig: SystemSecurityConfig;
  payrollHistory: any[];
}

// 24 Authentic Guatemalan companies requested by user
const requestedCompaniesList: Company[] = [
  { id: 'comp-1', name: 'Fermac', nit: '8912340-1', industry: 'Ferretería y Materiales de Construcción', address: 'Zona 1, Quetzaltenango', phone: '+502 7761-1200', createdAt: '2026-01-01T08:00:00Z', updatedAt: '2026-01-01T08:00:00Z' },
  { id: 'comp-2', name: 'Fermac Kiché', nit: '8912340-2', industry: 'Distribución y Ferretería', address: 'Santa Cruz del Quiché, El Quiché', phone: '+502 7755-4300', createdAt: '2026-01-01T08:00:00Z', updatedAt: '2026-01-01T08:00:00Z' },
  { id: 'comp-3', name: 'Piedra Azul', nit: '7823901-4', industry: 'Extracción de Agregados y Cantera', address: 'Salcajá, Quetzaltenango', phone: '+502 7768-9900', createdAt: '2026-01-02T08:00:00Z', updatedAt: '2026-01-02T08:00:00Z' },
  { id: 'comp-4', name: 'Bazar Chino Xela', nit: '6541298-7', industry: 'Comercio Mayorista y Minorista', address: '4ta Calle 12-40, Zona 1, Xela', phone: '+502 7765-8811', createdAt: '2026-01-03T08:00:00Z', updatedAt: '2026-01-03T08:00:00Z' },
  { id: 'comp-5', name: 'Country Club', nit: '4532109-8', industry: 'Recreación, Deportes y Eventos', address: 'Carretera a Almolonga Km 4, Quetzaltenango', phone: '+502 7763-5522', createdAt: '2026-01-04T08:00:00Z', updatedAt: '2026-01-04T08:00:00Z' },
  { id: 'comp-6', name: 'Bella Luna', nit: '3490123-5', industry: 'Restaurante y Salón de Recepciones', address: 'Avenida Las Américas, Zona 9, Xela', phone: '+502 7767-4400', createdAt: '2026-01-05T08:00:00Z', updatedAt: '2026-01-05T08:00:00Z' },
  { id: 'comp-7', name: 'Relámpago Xela', nit: '9012456-3', industry: 'Mensajería, Envíos y Logística', address: '12 Avenida 5-20, Zona 1, Xela', phone: '+502 7761-9090', createdAt: '2026-01-06T08:00:00Z', updatedAt: '2026-01-06T08:00:00Z' },
  { id: 'comp-8', name: 'Relámpago Huehue', nit: '9012456-4', industry: 'Logística y Transporte de Encomiendas', address: 'Zona 4, Huehuetenango', phone: '+502 7764-1020', createdAt: '2026-01-07T08:00:00Z', updatedAt: '2026-01-07T08:00:00Z' },
  { id: 'comp-9', name: 'San Bartolomé', nit: '2345678-9', industry: 'Agropecuaria y Granos Básicos', address: 'San Bartolo Aguas Calientes, Totonicapán', phone: '+502 7766-3040', createdAt: '2026-01-08T08:00:00Z', updatedAt: '2026-01-08T08:00:00Z' },
  { id: 'comp-10', name: 'Bazar Chino San Mateo', nit: '6541298-9', industry: 'Comercio General y Bazar', address: 'San Mateo, Quetzaltenango', phone: '+502 7768-4050', createdAt: '2026-01-09T08:00:00Z', updatedAt: '2026-01-09T08:00:00Z' },
  { id: 'comp-11', name: 'Hotel Centenario', nit: '1298745-6', industry: 'Hotelería y Turismo', address: 'Centro Histórico, Zona 1, Quetzaltenango', phone: '+502 7761-2233', createdAt: '2026-01-10T08:00:00Z', updatedAt: '2026-01-10T08:00:00Z' },
  { id: 'comp-12', name: 'San Bartolomé 29 Avenida', nit: '2345678-0', industry: 'Comercializadora y Distribución', address: '29 Avenida, Zona 7, Xela', phone: '+502 7763-8899', createdAt: '2026-01-11T08:00:00Z', updatedAt: '2026-01-11T08:00:00Z' },
  { id: 'comp-13', name: 'Comercial Sendala Huehue', nit: '5678912-3', industry: 'Venta de Electrodomésticos y Hogar', address: 'Calzada Kaibil Balam, Huehuetenango', phone: '+502 7764-7711', createdAt: '2026-01-12T08:00:00Z', updatedAt: '2026-01-12T08:00:00Z' },
  { id: 'comp-14', name: 'Licorera', nit: '8765432-1', industry: 'Distribuidora de Licores y Bebidas', address: 'Zona 3, Quetzaltenango', phone: '+502 7761-5500', createdAt: '2026-01-13T08:00:00Z', updatedAt: '2026-01-13T08:00:00Z' },
  { id: 'comp-15', name: 'Coca Cola Reu', nit: '3210987-4', industry: 'Embotellado y Distribución de Bebidas', address: 'Km 182 Carretera al Pacífico, Retalhuleu', phone: '+502 7771-4400', createdAt: '2026-01-14T08:00:00Z', updatedAt: '2026-01-14T08:00:00Z' },
  { id: 'comp-16', name: 'Italpel', nit: '4567890-2', industry: 'Manufactura y Confección Textil', address: 'Parque Industrial Las Rosas, Xela', phone: '+502 7767-1122', createdAt: '2026-01-15T08:00:00Z', updatedAt: '2026-01-15T08:00:00Z' },
  { id: 'comp-17', name: 'Supermercado Rosario', nit: '9876543-0', industry: 'Cadena de Supermercados y Abarrotes', address: 'Diagonal 3, Zona 2, Quetzaltenango', phone: '+502 7765-6677', createdAt: '2026-01-16T08:00:00Z', updatedAt: '2026-01-16T08:00:00Z' },
  { id: 'comp-18', name: 'Plaza Macedonia', nit: '6789012-4', industry: 'Centro Comercial y Arrendamiento', address: 'Calzada Manuel Lisandro Barillas, Zona 5, Xela', phone: '+502 7763-9900', createdAt: '2026-01-17T08:00:00Z', updatedAt: '2026-01-17T08:00:00Z' },
  { id: 'comp-19', name: 'Bazzar Chinos 1 a 8', nit: '6541298-1', industry: 'Cadena de Galerías y Bazares', address: 'Zona 3 Terminal Minerva, Quetzaltenango', phone: '+502 7761-3344', createdAt: '2026-01-18T08:00:00Z', updatedAt: '2026-01-18T08:00:00Z' },
  { id: 'comp-20', name: 'Ciudad de los Altos 2', nit: '7890123-5', industry: 'Desarrollo Inmobiliario y Residencial', address: 'Sector La Floresta, Zona 9, Xela', phone: '+502 7767-8890', createdAt: '2026-01-19T08:00:00Z', updatedAt: '2026-01-19T08:00:00Z' },
  { id: 'comp-21', name: 'Ciudad de los Altos 4', nit: '7890123-7', industry: 'Condominios y Bienes Raíces', address: 'Avenida Las Américas, Zona 9, Xela', phone: '+502 7767-8892', createdAt: '2026-01-20T08:00:00Z', updatedAt: '2026-01-20T08:00:00Z' },
  { id: 'comp-22', name: 'Bazzar Chino Terminal', nit: '6541298-3', industry: 'Importaciones y Venta Minorista', address: 'Cerca de Terminal Minerva, Zona 3, Xela', phone: '+502 7761-4455', createdAt: '2026-01-21T08:00:00Z', updatedAt: '2026-01-21T08:00:00Z' },
  { id: 'comp-23', name: 'Vía Vetenango', nit: '8901234-6', industry: 'Complejo Comercial y Gastronómico', address: 'Entrada Principal, Huehuetenango', phone: '+502 7764-8800', createdAt: '2026-01-22T08:00:00Z', updatedAt: '2026-01-22T08:00:00Z' },
  { id: 'comp-24', name: 'Constructora Edifica', nit: '9012345-7', industry: 'Ingeniería Civil y Edificaciones', address: 'Edificio Las Américas, Nivel 4, Xela', phone: '+502 7763-7744', createdAt: '2026-01-23T08:00:00Z', updatedAt: '2026-01-23T08:00:00Z' },
];

const defaultData: DatabaseSchema = {
  users: [
    {
      id: 'user-admin',
      name: 'E. Leiva (Administrador Principal)',
      username: 'eleiva',
      personalAccessCode: '2004',
      email: 'michbaquiaxgt@gmail.com',
      role: 'ADMIN',
      permissions: {
        canViewCompanies: true,
        canViewEmployees: true,
        canViewSalaries: true,
        canViewAuditLog: true,
        canScanQR: true,
        canEditEmployees: true,
        canCreateEmployees: true,
        canDeleteEmployees: true,
        canManageCompanies: true,
        canExportExcel: true,
        canModifySalaries: true,
      },
      createdAt: '2026-01-01T08:00:00Z',
    },
  ],
  companies: requestedCompaniesList,
  employees: [],
  auditLogs: [],
  notifications: [],
  guardCheckins: [],
  securityConfig: {
    adminAccessCode: '2004',
    guardAccessCode: 'GUARDIA-7788',
    guestAccessCode: 'INVITADO-1234',
    guardWallpaperUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1920&q=80',
    checkpoints: [
      {
        id: 'chkpoint-1',
        name: 'Tienda Central Fermac Zona 1',
        companyId: 'comp-1',
        companyName: 'Fermac',
        googleMapsUrl: 'https://maps.google.com/?q=14.8348,-91.5181',
        address: 'Zona 1, Quetzaltenango (Garita Principal)',
        code: 'QR-TIENDA-FERMAC-01',
        createdAt: '2026-01-01T08:00:00Z',
      },
      {
        id: 'chkpoint-2',
        name: 'Garita Country Club Xela',
        companyId: 'comp-5',
        companyName: 'Country Club',
        googleMapsUrl: 'https://maps.google.com/?q=14.8210,-91.5050',
        address: 'Carretera a Almolonga Km 4, Quetzaltenango',
        code: 'QR-TIENDA-COUNTRYCLUB-02',
        createdAt: '2026-01-04T08:00:00Z',
      },
      {
        id: 'chkpoint-3',
        name: 'Piedra Azul Cantera Salcajá',
        companyId: 'comp-3',
        companyName: 'Piedra Azul',
        googleMapsUrl: 'https://maps.google.com/?q=14.8722,-91.4601',
        address: 'Salcajá, Quetzaltenango',
        code: 'QR-TIENDA-PIEDRAAZUL-03',
        createdAt: '2026-01-02T08:00:00Z',
      },
      {
        id: 'chkpoint-4',
        name: 'Bazar Chino Xela Terminal',
        companyId: 'comp-4',
        companyName: 'Bazar Chino Xela',
        googleMapsUrl: 'https://maps.google.com/?q=14.8415,-91.5290',
        address: '4ta Calle 12-40, Zona 1, Xela',
        code: 'QR-TIENDA-BAZARCHINO-04',
        createdAt: '2026-01-03T08:00:00Z',
      },
    ],
    guardBaseSalary: 4200,
    igssPercentage: 4.83,
    uniformPrices: {
      gorra: 60,
      pantalon: 180,
      botas: 250,
      camisaCafe: 120,
      playeraPolo: 90,
    },
    inventoryItems: [
      { id: 'inv-1', name: 'Gorra', stock: 25, price: 60, description: 'Gorra institucional con bordado' },
      { id: 'inv-2', name: 'Pantalón', stock: 20, price: 180, description: 'Pantalón táctico / formal' },
      { id: 'inv-3', name: 'Botas', stock: 15, price: 250, description: 'Botas de seguridad industrial' },
      { id: 'inv-4', name: 'Camisa café', stock: 30, price: 120, description: 'Camisa manga larga color café' },
      { id: 'inv-5', name: 'Playera tipo polo', stock: 30, price: 90, description: 'Playera polo con escudo' },
    ],
  },
  payments: [],
  receipts: [],
  payrollHistory: [],
};

// ==========================================
// DESCUENTOS EN CUOTAS POR QUINCENA (ver src/utils/quincenas.ts)
// ==========================================
function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

/** Mantiene la copia del descuento en discountHistory igual a la versión vigente. */
function syncDiscountHistory(emp: Employee, disc: GuardDiscount): void {
  if (!emp.discountHistory) emp.discountHistory = [];
  const idx = emp.discountHistory.findIndex(h => h.id === disc.id);
  if (idx >= 0) emp.discountHistory[idx] = { ...disc };
}

/** Recalcula cuotas cobradas y cierra automáticamente el descuento cuando ya se aplicó la última cuota. */
function refreshDiscountState(emp: Employee, disc: GuardDiscount): void {
  disc.paidPeriods = Array.from(new Set((disc.paidPeriods || []).map(normalizePeriodKey)));
  const total = getTotalInstallments(disc);
  const paid = disc.paidPeriods.length;
  disc.installmentsPaid = paid;
  if (disc.status !== 'ELIMINADO' && disc.status !== 'CANCELADO') {
    if (paid >= total) {
      disc.status = 'FINALIZADO';
      if (!disc.finalizedAt) disc.finalizedAt = new Date().toISOString();
    } else if (disc.status === 'FINALIZADO') {
      disc.status = 'ACTIVO';
      delete disc.finalizedAt;
    }
  }
  syncDiscountHistory(emp, disc);
}

/**
 * Migración (idempotente) de descuentos creados antes de existir la "quincena de inicio":
 * deduce la quincena de inicio, normaliza las quincenas cobradas y finaliza los descuentos ya cumplidos.
 */
function migrateEmployeeDiscounts(emp: Employee): boolean {
  let changed = false;
  for (const d of emp.discounts || []) {
    if (d.status === 'ELIMINADO') continue;
    const before = JSON.stringify(d);

    if (!getStartQuincena(d)) {
      const base = quincenaFromDate(d.date || new Date().toISOString().slice(0, 10));
      const forced = d.period === '1RA_QUINCENA' ? 1 : d.period === '2DA_QUINCENA' ? 2 : base.quincena;
      d.startYear = base.year;
      d.startMonth = base.month;
      d.startQuincena = forced as 1 | 2;
    }
    if (!d.installments || d.installments < 1) d.installments = 1;

    const normalized = Array.from(new Set((d.paidPeriods || []).map(normalizePeriodKey)));
    const total = getTotalInstallments(d);
    const legacyCounter = d.installmentsPaid || 0;
    const hadPayment = normalized.length > 0 || legacyCounter > 0;
    d.paidPeriods = normalized;
    d.installmentsPaid = normalized.length;

    const completed = normalized.length >= total || legacyCounter >= total || (d.status === 'CANCELADO' && hadPayment);
    if (completed) {
      d.status = 'FINALIZADO';
      if (!d.finalizedAt) d.finalizedAt = d.date ? `${d.date}T00:00:00.000Z` : new Date().toISOString();
      if (normalized.length < total && legacyCounter >= total) d.installmentsPaid = total;
    } else if (d.status === 'FINALIZADO') {
      d.status = 'ACTIVO';
      delete d.finalizedAt;
    }

    if (JSON.stringify(d) !== before) {
      changed = true;
      syncDiscountHistory(emp, d);
    }
  }
  return changed;
}

interface PayrollDiscountSnapshot {
  id: string;
  reason: string;
  discountType?: string;
  amount: number;
  totalInstallments: number;
  currentInstallment: number;
  remainingInstallments: number;
  amountToCharge: number;
}

function computeEmployeePayrollRow(db: DatabaseSchema, emp: Employee, target: QuincenaRef) {
  const monthlySalary = emp.monthlySalary || db.securityConfig?.guardBaseSalary || 4200;
  const quincenalBase = round2(monthlySalary / 2);
  const igssPercentage = emp.appliesIGSS !== false ? (db.securityConfig?.igssPercentage ?? 4.83) : 0;
  const igssDeduction = round2((quincenalBase * igssPercentage) / 100);

  const appliedDiscounts: PayrollDiscountSnapshot[] = [];
  let discountsTotal = 0;
  for (const d of emp.discounts || []) {
    const n = getInstallmentNumber(d, target);
    if (n === null || !isDiscountApplicable(d, target)) continue;
    const amountToCharge = getInstallmentAmount(d, n);
    discountsTotal += amountToCharge;
    appliedDiscounts.push({
      id: d.id,
      reason: d.reason,
      discountType: d.discountType,
      amount: d.amount,
      totalInstallments: getTotalInstallments(d),
      currentInstallment: n,
      remainingInstallments: getTotalInstallments(d) - n,
      amountToCharge,
    });
  }
  discountsTotal = round2(discountsTotal);

  return {
    employeeId: emp.id,
    employeeName: emp.name,
    dpi: emp.dpi,
    position: emp.position,
    companyId: emp.companyId,
    monthlySalary,
    quincenalBase,
    igssDeduction,
    discountsTotal,
    appliedDiscounts,
    netAmount: Math.max(0, round2(quincenalBase - igssDeduction - discountsTotal)),
  };
}

function payrollRecordQuincena(h: any): QuincenaRef | null {
  return parseQuincenaRef(h?.anio, h?.mes, h?.tipo_quincena);
}

/** Planillas guardadas (registro fijo) de una quincena, sin importar el alcance (todas las empresas o una sola). */
function findSavedPayrolls(db: DatabaseSchema, target: QuincenaRef): any[] {
  const idx = quincenaIndex(target);
  return (db.payrollHistory || []).filter((h: any) => {
    const q = payrollRecordQuincena(h);
    return q !== null && quincenaIndex(q) === idx;
  });
}

/** Quita una quincena de los descuentos de las filas guardadas y reabre los que se habían finalizado. */
function releasePayrollRecord(db: DatabaseSchema, record: any): void {
  const q = payrollRecordQuincena(record);
  if (!q) return;
  const key = quincenaKey(q);
  for (const row of record.rows || []) {
    const emp = db.employees.find((e: Employee) => e.id === row.employeeId);
    if (!emp) continue;
    for (const applied of row.appliedDiscounts || []) {
      const disc = (emp.discounts || []).find(d => d.id === applied.id);
      if (!disc) continue;
      disc.paidPeriods = (disc.paidPeriods || []).map(normalizePeriodKey).filter(k => k !== key);
      refreshDiscountState(emp, disc);
    }
  }
}

function readDatabase(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(defaultData, null, 2), 'utf-8');
      return defaultData;
    }
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    let modified = false;

    // Removed automatic company re-population to allow empty state
    // Normalizar colecciones faltantes (db.json antiguos no traen todas las claves)
    for (const key of ['companies', 'employees', 'auditLogs', 'notifications', 'guardCheckins', 'payments', 'receipts', 'payrollHistory'] as const) {
      if (!Array.isArray((parsed as any)[key])) {
        (parsed as any)[key] = [];
        modified = true;
      }
    }

    if (!parsed.securityConfig) {
      parsed.securityConfig = defaultData.securityConfig;
      modified = true;
    } else {
      if (!parsed.securityConfig.adminAccessCode) {
        parsed.securityConfig.adminAccessCode = 'ADMIN-2026';
        modified = true;
      }
      if (!parsed.securityConfig.guardAccessCode) {
        parsed.securityConfig.guardAccessCode = 'GUARDIA-7788';
        modified = true;
      }
      if (!parsed.securityConfig.guestAccessCode) {
        parsed.securityConfig.guestAccessCode = 'INVITADO-1234';
        modified = true;
      }
      if (!parsed.securityConfig.guardWallpaperUrl) {
        parsed.securityConfig.guardWallpaperUrl = defaultData.securityConfig.guardWallpaperUrl;
        modified = true;
      }
      if (!parsed.securityConfig.checkpoints || parsed.securityConfig.checkpoints.length === 0) {
        parsed.securityConfig.checkpoints = defaultData.securityConfig.checkpoints;
        modified = true;
      }
      if (parsed.securityConfig.guardBaseSalary === undefined) {
        parsed.securityConfig.guardBaseSalary = 4200;
        modified = true;
      }
      if (parsed.securityConfig.igssPercentage === undefined) {
        parsed.securityConfig.igssPercentage = 4.83;
        modified = true;
      }
      if (!parsed.securityConfig.inventoryItems) {
        parsed.securityConfig.inventoryItems = defaultData.securityConfig.inventoryItems;
        modified = true;
      }
    }

    // Ensure all employees have a unique PIN code and dedicated guard employees exist
    if (parsed.employees) {
      let pinCount = 4420;
      for (const emp of parsed.employees) {
        if (migrateEmployeeDiscounts(emp)) modified = true;
        if (!emp.pinCode) {
          pinCount++;
          emp.pinCode = String(pinCount);
          modified = true;
        }
      }

      // Removed hardcoded employee re-population logic
    }

    // Ensure users have all permissions and include guard users
    if (!parsed.users || parsed.users.length === 0) {
      parsed.users = defaultData.users;
      modified = true;
    } else {
      // Ensure main admin user has username 'eleiva' and password/access code '2004'
      const adminInDb = parsed.users.find((u: AppUser) => u.id === 'user-admin');
      if (adminInDb) {
        if (!adminInDb.username || adminInDb.username !== 'eleiva') {
          adminInDb.username = 'eleiva';
          adminInDb.name = 'E. Leiva (Administrador Principal)';
          adminInDb.personalAccessCode = '2004';
          modified = true;
        }
        if (!adminInDb.personalAccessCode) {
          adminInDb.personalAccessCode = '2004';
          modified = true;
        }
      }
      if (parsed.securityConfig && parsed.securityConfig.adminAccessCode === 'ADMIN-2026') {
        parsed.securityConfig.adminAccessCode = '2004';
        modified = true;
      }

      for (const defUser of defaultData.users) {
        const existing = parsed.users.find((u: AppUser) => u.id === defUser.id);
        if (!existing) {
          parsed.users.push(defUser);
          modified = true;
        }
      }
      for (const user of parsed.users) {
        if (!user.permissions) {
          user.permissions = { ...defaultData.users[0].permissions };
          modified = true;
        }
        if (user.permissions.canViewCompanies === undefined) {
          user.permissions.canViewCompanies = true;
          modified = true;
        }
        if (user.permissions.canViewEmployees === undefined) {
          user.permissions.canViewEmployees = true;
          modified = true;
        }
        if (user.permissions.canViewSalaries === undefined) {
          user.permissions.canViewSalaries = user.role !== 'GUARD';
          modified = true;
        }
        if (user.permissions.canViewAuditLog === undefined) {
          user.permissions.canViewAuditLog = user.role === 'ADMIN';
          modified = true;
        }
        if (user.permissions.canScanQR === undefined) {
          user.permissions.canScanQR = user.role === 'GUARD' || user.role === 'ADMIN';
          modified = true;
        }
        // Strict guard rule: Guards cannot view salaries or payroll deductions
        if (user.role === 'GUARD') {
          user.permissions.canViewSalaries = false;
          user.permissions.canViewAuditLog = false;
        }
      }
    }

    if (modified) {
      writeDatabase(parsed);
    }

    return parsed;
  } catch (err) {
    console.error('Error reading database file:', err);
    return defaultData;
  }
}

function writeDatabase(data: DatabaseSchema): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing database file:', err);
  }
}

// Varios colaboradores pueden compartir PIN (p. ej. reasignado de empresa): se prefiere el registro ACTIVO.
function findEmployeeByPin(employees: Employee[], pin: string): Employee | undefined {
  const matches = employees.filter(e => e.pinCode && e.pinCode.trim() === pin);
  return matches.find(e => e.status === 'ACTIVO') || matches[0];
}

// Authentication / permission helper
function getUserFromHeader(req: express.Request, db: DatabaseSchema): AppUser {
  const userId = req.headers['x-user-id'] as string;
  const user = db.users.find((u: AppUser) => u.id === userId);
  if (user) return user;
  // Los guardias que inician sesión con su PIN (id "guard-<empleado>") no se guardan en db.users:
  // se reconstruyen con permisos restringidos en lugar de caer al administrador.
  if (typeof userId === 'string' && userId.startsWith('guard-')) {
    const emp = db.employees.find((e: Employee) => e.id === userId.slice('guard-'.length));
    if (emp) {
      return {
        id: userId,
        name: emp.name,
        email: emp.email || `${emp.id}@guardiareal.gt`,
        role: 'GUARD',
        employeeId: emp.id,
        pinCode: emp.pinCode,
        permissions: {
          canViewCompanies: false,
          canViewEmployees: false,
          canViewSalaries: false,
          canViewAuditLog: false,
          canScanQR: true,
          canEditEmployees: false,
          canCreateEmployees: false,
          canDeleteEmployees: false,
          canManageCompanies: false,
          canExportExcel: false,
          canModifySalaries: false,
        },
        createdAt: emp.createdAt,
      } as AppUser;
    }
  }
  return db.users[0];
}

// ==========================================
// API ROUTES
// ==========================================

// Bootstrap / All data (Securely masked for non-admin roles and credential privacy)
app.get('/api/bootstrap', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  const isAdmin = currentUser.role === 'ADMIN';
  const canViewSal = isAdmin || (currentUser.role !== 'GUARD' && currentUser.permissions?.canViewSalaries !== false);

  // If user cannot view salaries, mask monthlySalary to 0
  // And if user is not admin, mask pinCode from employees so other users cannot see credentials
  const safeEmployees = db.employees.map((e: Employee) => ({
    ...e,
    monthlySalary: canViewSal ? e.monthlySalary : 0,
    pinCode: isAdmin ? e.pinCode : undefined,
  }));

  // Mask credentials of other users if not admin
  const safeUsers = db.users.map((u: AppUser) => {
    if (isAdmin || u.id === currentUser.id) {
      return u;
    }
    const sanitized = { ...u };
    delete (sanitized as any).personalAccessCode;
    delete (sanitized as any).password;
    delete (sanitized as any).pinCode;
    return sanitized;
  });

  // Mask system access codes if not admin
  const safeSecurityConfig = db.securityConfig ? {
    ...db.securityConfig,
    adminAccessCode: isAdmin ? db.securityConfig.adminAccessCode : '••••••••',
    guardAccessCode: isAdmin ? db.securityConfig.guardAccessCode : '••••••••',
    guestAccessCode: isAdmin ? db.securityConfig.guestAccessCode : '••••••••',
  } : null;

  res.json({
    companies: db.companies,
    employees: safeEmployees,
    auditLogs: (isAdmin || currentUser.permissions?.canViewAuditLog) ? db.auditLogs : [],
    users: safeUsers,
    notifications: db.notifications,
    guardCheckins: db.guardCheckins || [],
    payments: db.payments || [],
    receipts: db.receipts || [],
    securityConfig: safeSecurityConfig,
  });
});

// Users & Permissions Management
app.get('/api/users', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  const isAdmin = currentUser.role === 'ADMIN';

  if (!isAdmin) {
    const sanitized = db.users.map((u: AppUser) => {
      if (u.id === currentUser.id) return u;
      const copy = { ...u };
      delete (copy as any).personalAccessCode;
      delete (copy as any).password;
      delete (copy as any).pinCode;
      return copy;
    });
    return res.json(sanitized);
  }
  res.json(db.users);
});

app.post('/api/users', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede crear nuevos usuarios.' });
  }

  const { name, email, role, permissions, stationName, companyId, pinCode } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: 'Nombre y correo son requeridos.' });
  }

  const isGuardRole = role === 'GUARD';
  const cleanPin = pinCode && String(pinCode).trim() ? String(pinCode).trim() : String(Math.floor(1000 + Math.random() * 9000));

  let finalStationName = stationName;
  let targetCompanyId = companyId;
  if (isGuardRole) {
    if (companyId) {
      const comp = db.companies.find((c: Company) => c.id === companyId);
      if (comp) {
        finalStationName = `Garita - ${comp.name}`;
      }
    } else {
      targetCompanyId = db.companies[0]?.id || 'comp-1';
      finalStationName = `Garita - ${db.companies[0]?.name || 'Puesto Central'}`;
    }
  }

  const newUser: AppUser = {
    id: `user-${Date.now()}`,
    name: name.trim(),
    email: email.trim().toLowerCase(),
    role: role || 'GUEST',
    stationName: finalStationName || (isGuardRole ? 'Puesto de Guardia General' : undefined),
    personalAccessCode: cleanPin,
    pinCode: isGuardRole ? cleanPin : undefined,
    permissions: permissions || {
      canViewCompanies: !isGuardRole,
      canViewEmployees: !isGuardRole,
      canViewSalaries: false, // Guardias NUNCA ven salarios
      canViewAuditLog: false,
      canScanQR: isGuardRole || role === 'ADMIN',
      canEditEmployees: role === 'GUEST',
      canCreateEmployees: false,
      canDeleteEmployees: false,
      canManageCompanies: false,
      canExportExcel: false,
      canModifySalaries: false,
    },
    createdAt: new Date().toISOString(),
  };

  // If guard, also create their official employee record assigned to that store
  if (isGuardRole) {
    const newEmployee: Employee = {
      id: `emp-guard-${Date.now()}`,
      companyId: targetCompanyId || (db.companies[0]?.id || 'comp-1'),
      name: name.trim(),
      dpi: `DPI-${Math.floor(1000000000000 + Math.random() * 9000000000000)}`,
      position: finalStationName || 'Guardia de Seguridad',
      monthlySalary: Number(db.securityConfig?.guardBaseSalary) || 3800,
      appliesIGSS: true,
      startDate: new Date().toISOString().slice(0, 10),
      endDate: null,
      status: 'ACTIVO',
      phone: '',
      email: email.trim().toLowerCase(),
      pinCode: cleanPin,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastModifiedBy: currentUser.name,
      lastModifiedById: currentUser.id,
    };
    db.employees.push(newEmployee);
    newUser.employeeId = newEmployee.id;
  }

  db.users.push(newUser);

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'CAMBIO_PERMISOS',
    entityType: 'USUARIO_PERMISOS',
    entityId: newUser.id,
    entityName: newUser.name,
    summary: `Nuevo usuario creado (${newUser.role === 'GUARD' ? 'Guardia Asignado a Tienda' : 'Usuario Invitado'}): ${newUser.name}. PIN personal: ${cleanPin}`,
    changes: [
      { field: 'role', label: 'Rol Asignado', oldValue: null, newValue: newUser.role },
      { field: 'pin', label: 'PIN Personal', oldValue: null, newValue: 'Generado y Asignado' }
    ],
    isCritical: true,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.status(201).json(newUser);
});

app.put('/api/users/:id/permissions', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede modificar permisos de acceso.' });
  }

  const targetUser = db.users.find((u: AppUser) => u.id === req.params.id);
  if (!targetUser) {
    return res.status(404).json({ error: 'Usuario no encontrado.' });
  }

  const oldPermissions: UserPermissions = { ...targetUser.permissions };
  const newPermissions: UserPermissions = { ...oldPermissions, ...req.body.permissions };
  
  // Guard safeguard: if target is guard, ensure salary viewing remains protected unless explicitly permitted by admin
  if (targetUser.role === 'GUARD' && req.body.permissions.canViewSalaries === undefined) {
    newPermissions.canViewSalaries = false;
  }
  
  targetUser.permissions = newPermissions;

  const changes = [];
  const keys: (keyof UserPermissions)[] = [
    'canViewCompanies',
    'canViewEmployees',
    'canViewSalaries',
    'canViewAuditLog',
    'canScanQR',
    'canEditEmployees',
    'canCreateEmployees',
    'canDeleteEmployees',
    'canManageCompanies',
    'canExportExcel',
    'canModifySalaries',
  ];

  const labelsMap: Record<keyof UserPermissions, string> = {
    canViewCompanies: '👁️ Ver Pestaña Empresas',
    canViewEmployees: '👁️ Ver Pestaña Trabajadores',
    canViewSalaries: '💰 Ver Sueldos y Descuentos',
    canViewAuditLog: '👁️ Ver Pestaña Planilla & Auditoría',
    canScanQR: '📱 Pestaña Guardias & Marcaje QR',
    canEditEmployees: '✏️ Editar Trabajadores',
    canCreateEmployees: '➕ Registrar Trabajadores',
    canDeleteEmployees: '🗑️ Eliminar Trabajadores',
    canManageCompanies: '🏢 Gestionar Empresas',
    canExportExcel: '📥 Exportar Planilla en Excel',
    canModifySalaries: '💵 Modificar Salarios Mensuales',
  };

  for (const key of keys) {
    if (oldPermissions[key] !== newPermissions[key]) {
      changes.push({
        field: key,
        label: labelsMap[key] || `Permiso: ${key}`,
        oldValue: oldPermissions[key] ? 'Habilitado' : 'Deshabilitado',
        newValue: newPermissions[key] ? 'Habilitado' : 'Deshabilitado',
      });
    }
  }

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'CAMBIO_PERMISOS',
    entityType: 'USUARIO_PERMISOS',
    entityId: targetUser.id,
    entityName: targetUser.name,
    summary: `Permisos actualizados para ${targetUser.name}`,
    changes,
    isCritical: true,
  };
  db.auditLogs.unshift(logEntry);

  const notif: RealtimeNotification = {
    id: `notif-${Date.now()}`,
    timestamp: new Date().toISOString(),
    title: 'Permisos de Usuario Actualizados',
    message: `${currentUser.name} actualizó los privilegios del usuario ${targetUser.name}.`,
    type: 'permission',
    actorName: currentUser.name,
    read: false,
    linkTab: 'permissions',
  };
  db.notifications.unshift(notif);

  writeDatabase(db);
  res.json(targetUser);
});

app.delete('/api/users/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede eliminar usuarios.' });
  }

  const { id } = req.params;
  if (id === 'user-admin' || id === currentUser.id) {
    return res.status(400).json({ error: 'No se puede eliminar al administrador principal o a tu usuario activo.' });
  }

  const index = db.users.findIndex((u: AppUser) => u.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Usuario no encontrado.' });
  }

  const removed = db.users.splice(index, 1)[0];
  writeDatabase(db);
  res.json({ success: true, removed });
});

// Update User Role and Personal Access Code (by Admin)
app.put('/api/users/:id/role-and-code', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador principal puede modificar roles y claves de acceso de los usuarios.' });
  }

  const targetUser = db.users.find((u: AppUser) => u.id === req.params.id);
  if (!targetUser) {
    return res.status(404).json({ error: 'Usuario no encontrado.' });
  }

  const { role, personalAccessCode, username, permissions } = req.body;
  const changes = [];

  if (role && role !== targetUser.role) {
    changes.push({ field: 'role', label: 'Rol de Usuario', oldValue: targetUser.role, newValue: role });
    targetUser.role = role;
  }

  if (username !== undefined && username.trim() !== targetUser.username) {
    changes.push({ field: 'username', label: 'Usuario', oldValue: targetUser.username || '(Ninguno)', newValue: username.trim() });
    targetUser.username = username.trim() || undefined;
  }

  if (personalAccessCode !== undefined && personalAccessCode.trim() !== targetUser.personalAccessCode) {
    changes.push({ field: 'personalAccessCode', label: 'Clave de Acceso', oldValue: '••••', newValue: 'Actualizada' });
    targetUser.personalAccessCode = personalAccessCode.trim() || undefined;
  }

  if (permissions) {
    targetUser.permissions = { ...targetUser.permissions, ...permissions };
  }

  if (changes.length > 0) {
    const logEntry: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      action: 'CAMBIO_PERMISOS',
      entityType: 'USUARIO_PERMISOS',
      entityId: targetUser.id,
      entityName: targetUser.name,
      summary: `El administrador asignó nuevo rol o clave de acceso a ${targetUser.name}.`,
      changes,
      isCritical: true,
    };
    db.auditLogs.unshift(logEntry);
  }

  writeDatabase(db);
  res.json(targetUser);
});

// Companies Management
app.get('/api/companies', (req, res) => {
  const db = readDatabase();
  res.json(db.companies);
});

app.post('/api/companies', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN' && !currentUser.permissions.canManageCompanies) {
    return res.status(403).json({ error: 'No tienes autorización para agregar o gestionar empresas.' });
  }

  const { name, nit, industry, address, phone, email } = req.body;
  if (!name || !nit) {
    return res.status(400).json({ error: 'Nombre de empresa y NIT son obligatorios.' });
  }

  const newCompany: Company = {
    id: `comp-${Date.now()}`,
    name,
    nit,
    industry: industry || 'Comercio General',
    address: address || 'Guatemala',
    phone: phone || '',
    email: email || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.companies.push(newCompany);

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'CREAR_EMPRESA',
    entityType: 'EMPRESA',
    entityId: newCompany.id,
    entityName: newCompany.name,
    companyId: newCompany.id,
    companyName: newCompany.name,
    summary: `Nueva empresa registrada: ${newCompany.name} (NIT: ${newCompany.nit})`,
    changes: [
      { field: 'name', label: 'Razón Social', oldValue: null, newValue: newCompany.name },
      { field: 'nit', label: 'NIT', oldValue: null, newValue: newCompany.nit },
    ],
    isCritical: true,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.status(201).json(newCompany);
});

app.put('/api/companies/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN' && !currentUser.permissions.canManageCompanies) {
    return res.status(403).json({ error: 'No tienes autorización para editar empresas.' });
  }

  const compIndex = db.companies.findIndex((c: Company) => c.id === req.params.id);
  if (compIndex === -1) {
    return res.status(404).json({ error: 'Empresa no encontrada.' });
  }

  const oldCompany = db.companies[compIndex];
  const { name, nit, industry, address, phone, email } = req.body;

  const updatedCompany: Company = {
    ...oldCompany,
    name: name || oldCompany.name,
    nit: nit || oldCompany.nit,
    industry: industry || oldCompany.industry,
    address: address || oldCompany.address,
    phone: phone !== undefined ? phone : oldCompany.phone,
    email: email !== undefined ? email : oldCompany.email,
    updatedAt: new Date().toISOString(),
  };

  db.companies[compIndex] = updatedCompany;
  writeDatabase(db);
  res.json(updatedCompany);
});

app.delete('/api/companies/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede eliminar empresas.' });
  }

  const compIndex = db.companies.findIndex((c: Company) => c.id === req.params.id);
  if (compIndex === -1) {
    return res.status(404).json({ error: 'Empresa no encontrada.' });
  }

  const comp = db.companies[compIndex];
  db.companies.splice(compIndex, 1);
  writeDatabase(db);
  res.json({ success: true });
});

// Employees Management
app.get('/api/employees', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  const canViewSal = currentUser.role === 'ADMIN' || (currentUser.role !== 'GUARD' && currentUser.permissions?.canViewSalaries !== false);

  const companyId = req.query.companyId as string;
  let list = companyId ? db.employees.filter((e: Employee) => e.companyId === companyId) : db.employees;
  if (!canViewSal) {
    list = list.map((e: Employee) => ({ ...e, monthlySalary: 0 }));
  }
  res.json(list);
});

app.post('/api/employees', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN' && !currentUser.permissions.canCreateEmployees) {
    return res.status(403).json({ error: 'No tienes permisos para registrar nuevos colaboradores. Consulta al administrador.' });
  }

  const { companyId, name, dpi, position, monthlySalary, appliesIGSS, startDate, endDate, phone, email, pinCode, bankName, paymentMethodPreference, bankAccountNumber } = req.body;
  if (!companyId || !name || !dpi || !position) {
    return res.status(400).json({ error: 'Empresa, nombre, DPI y puesto son obligatorios.' });
  }

  const targetComp = db.companies.find((c: Company) => c.id === companyId);
  if (!targetComp) {
    return res.status(400).json({ error: 'La empresa especificada no existe.' });
  }

  const parsedSalary = Number(monthlySalary) || 0;
  const assignedPin = (currentUser.role === 'ADMIN' && pinCode && String(pinCode).trim()) 
    ? String(pinCode).trim() 
    : String(Math.floor(1000 + Math.random() * 9000));

  const newEmp: Employee = {
    id: `emp-${Date.now()}`,
    companyId,
    name: name.trim(),
    dpi: dpi.trim(),
    position: position.trim(),
    monthlySalary: parsedSalary,
    appliesIGSS: appliesIGSS !== undefined ? !!appliesIGSS : true, // Default to true
    startDate: startDate || new Date().toISOString().slice(0, 10),
    endDate: endDate || null,
    status: (endDate ? 'DE_BAJA' : 'ACTIVO'),
    phone: phone || '',
    email: email || '',
    bankName: bankName ? String(bankName).trim() : 'Banco de Desarrollo Rural, S. A. (Banrural)',
    paymentMethodPreference: paymentMethodPreference || (bankName === 'En efectivo' ? 'EFECTIVO' : 'TRANSFERENCIA'),
    bankAccountNumber: bankAccountNumber ? String(bankAccountNumber).trim() : '',
    discounts: [],
    discountHistory: [],
    pinCode: assignedPin,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    lastModifiedBy: currentUser.name,
    lastModifiedById: currentUser.id,
  };

  db.employees.push(newEmp);

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'CREAR_EMPLEADO',
    entityType: 'EMPLEADO',
    entityId: newEmp.id,
    entityName: newEmp.name,
    companyId: targetComp.id,
    companyName: targetComp.name,
    summary: `Nuevo colaborador ${newEmp.name} agregado a ${targetComp.name} (IGSS: ${newEmp.appliesIGSS ? 'Aplica' : 'Exento'}) por ${currentUser.name}`,
    changes: [
      { field: 'name', label: 'Nombre Completo', oldValue: null, newValue: newEmp.name },
      { field: 'monthlySalary', label: 'Salario Mensual', oldValue: null, newValue: `Q${parsedSalary.toLocaleString('es-GT', { minimumFractionDigits: 2 })}` },
      { field: 'appliesIGSS', label: 'Cálculo IGSS 4.83%', oldValue: null, newValue: newEmp.appliesIGSS ? 'Sí (Aplica)' : 'No (Exento)' },
    ],
    isCritical: false,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.status(201).json(newEmp);
});

app.put('/api/employees/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN' && !currentUser.permissions.canEditEmployees) {
    return res.status(403).json({ error: 'No tienes permisos para editar colaboradores.' });
  }

  const empIndex = db.employees.findIndex((e: Employee) => e.id === req.params.id);
  if (empIndex === -1) {
    return res.status(404).json({ error: 'Colaborador no encontrado.' });
  }

  const oldEmp = db.employees[empIndex];
  const { name, dpi, position, monthlySalary, appliesIGSS, startDate, endDate, companyId, phone, email, status, pinCode } = req.body;

  const salaryRequested = monthlySalary !== undefined ? Number(monthlySalary) : oldEmp.monthlySalary;
  const isSalaryChanged = salaryRequested !== oldEmp.monthlySalary;

  if (isSalaryChanged && currentUser.role !== 'ADMIN' && !currentUser.permissions.canModifySalaries) {
    return res.status(403).json({
      error: 'No tienes permiso para modificar el salario mensual del trabajador.',
    });
  }

  const changes = [];
  if (name && name.trim() !== oldEmp.name) {
    changes.push({ field: 'name', label: 'Nombre Completo', oldValue: oldEmp.name, newValue: name.trim() });
  }
  if (dpi && dpi.trim() !== oldEmp.dpi) {
    changes.push({ field: 'dpi', label: 'DPI', oldValue: oldEmp.dpi, newValue: dpi.trim() });
  }
  if (position && position.trim() !== oldEmp.position) {
    changes.push({ field: 'position', label: 'Puesto', oldValue: oldEmp.position, newValue: position.trim() });
  }
  if (currentUser.role === 'ADMIN' && pinCode !== undefined && String(pinCode).trim() !== (oldEmp.pinCode || '')) {
    changes.push({ field: 'pinCode', label: 'Código PIN de Guardia', oldValue: '••••', newValue: 'Actualizado' });
  }
  if (isSalaryChanged) {
    changes.push({
      field: 'monthlySalary',
      label: 'Salario Mensual',
      oldValue: `Q${oldEmp.monthlySalary.toLocaleString('es-GT', { minimumFractionDigits: 2 })}`,
      newValue: `Q${salaryRequested.toLocaleString('es-GT', { minimumFractionDigits: 2 })}`,
    });
  }
  if (appliesIGSS !== undefined && appliesIGSS !== oldEmp.appliesIGSS) {
    changes.push({
      field: 'appliesIGSS',
      label: 'Cálculo Retención IGSS',
      oldValue: oldEmp.appliesIGSS ? 'Sí (Aplica)' : 'No (Exento)',
      newValue: appliesIGSS ? 'Sí (Aplica)' : 'No (Exento)',
    });
  }

  const newEndDate = endDate !== undefined ? (endDate ? endDate : null) : oldEmp.endDate;
  const calculatedStatus = newEndDate ? 'DE_BAJA' : (status || (oldEmp.status === 'DE_BAJA' && !newEndDate ? 'ACTIVO' : oldEmp.status));

  if (newEndDate !== oldEmp.endDate) {
    changes.push({
      field: 'endDate',
      label: 'Fecha de Baja',
      oldValue: oldEmp.endDate || 'Sin baja registrada',
      newValue: newEndDate || 'Removida (Reactivado)',
    });
  }

  const targetComp = db.companies.find((c: Company) => c.id === (companyId || oldEmp.companyId));
  const isCritical = isSalaryChanged || calculatedStatus === 'DE_BAJA' || oldEmp.status === 'DE_BAJA';

  const actionType = calculatedStatus === 'DE_BAJA' && oldEmp.status !== 'DE_BAJA' 
    ? 'BAJA_EMPLEADO' 
    : (oldEmp.status === 'DE_BAJA' && calculatedStatus === 'ACTIVO' ? 'REACTIVAR_EMPLEADO' : 'EDITAR_EMPLEADO');

  const finalPin = (currentUser.role === 'ADMIN' && pinCode !== undefined && String(pinCode).trim())
    ? String(pinCode).trim()
    : oldEmp.pinCode;

  const updatedEmp: Employee = {
    ...oldEmp,
    name: name ? name.trim() : oldEmp.name,
    dpi: dpi ? dpi.trim() : oldEmp.dpi,
    position: position ? position.trim() : oldEmp.position,
    monthlySalary: salaryRequested,
    appliesIGSS: appliesIGSS !== undefined ? !!appliesIGSS : (oldEmp.appliesIGSS !== undefined ? oldEmp.appliesIGSS : true),
    startDate: startDate || oldEmp.startDate,
    endDate: newEndDate,
    status: calculatedStatus as 'ACTIVO' | 'DE_BAJA',
    companyId: companyId || oldEmp.companyId,
    phone: phone !== undefined ? phone : oldEmp.phone,
    email: email !== undefined ? email : oldEmp.email,
    bankName: req.body.bankName !== undefined ? req.body.bankName : oldEmp.bankName,
    paymentMethodPreference: req.body.paymentMethodPreference !== undefined ? req.body.paymentMethodPreference : oldEmp.paymentMethodPreference,
    bankAccountNumber: req.body.bankAccountNumber !== undefined ? req.body.bankAccountNumber : oldEmp.bankAccountNumber,
    discounts: oldEmp.discounts || [],
    pinCode: finalPin,
    updatedAt: new Date().toISOString(),
    lastModifiedBy: currentUser.name,
    lastModifiedById: currentUser.id,
  };

  db.employees[empIndex] = updatedEmp;

  if (changes.length > 0) {
    const logEntry: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      action: actionType,
      entityType: 'EMPLEADO',
      entityId: updatedEmp.id,
      entityName: updatedEmp.name,
      companyId: targetComp?.id,
      companyName: targetComp?.name,
      summary: `Actualización de datos para ${updatedEmp.name} (IGSS: ${updatedEmp.appliesIGSS ? 'Sí' : 'No'}) por ${currentUser.name}`,
      changes,
      isCritical,
    };
    db.auditLogs.unshift(logEntry);

    if (isCritical) {
      const notif: RealtimeNotification = {
        id: `notif-${Date.now()}`,
        timestamp: new Date().toISOString(),
        title: isSalaryChanged ? 'Cambio Crítico de Salario' : 'Cambio de Estado Laboral (Baja/Reactivación)',
        message: `${currentUser.name} actualizó a ${updatedEmp.name}.`,
        type: isSalaryChanged ? 'salary' : 'status',
        actorName: currentUser.name,
        read: false,
        linkTab: 'audit',
      };
      db.notifications.unshift(notif);
    }
  }

  writeDatabase(db);
  res.json(updatedEmp);
});

app.delete('/api/employees/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN' && !currentUser.permissions.canDeleteEmployees) {
    return res.status(403).json({ error: 'No tienes autorización para eliminar registros de trabajadores.' });
  }

  const empIndex = db.employees.findIndex((e: Employee) => e.id === req.params.id);
  if (empIndex === -1) {
    return res.status(404).json({ error: 'Colaborador no encontrado.' });
  }

  const emp = db.employees[empIndex];
  db.employees.splice(empIndex, 1);
  writeDatabase(db);
  res.json({ success: true });
});

// ==========================================
// DESCUENTOS DE GUARDIAS (ANTICIPO O UNIFORME HASTA 7 QUINCENAS)
// ==========================================
app.post('/api/employees/:id/discounts', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN' && !currentUser.permissions?.canEditEmployees && currentUser.role !== 'GUEST') {
    return res.status(403).json({ error: 'No tienes permisos para aplicar descuentos.' });
  }

  const employee = db.employees.find((e: Employee) => e.id === req.params.id);
  if (!employee) {
    return res.status(404).json({ error: 'Guardia de seguridad no encontrado.' });
  }

  const { amount, reason, description, period, discountType, installments, installmentAmount, uniformItems, uniformItemIds, uniformQuantities, uniformItemDetails, date, startYear, startMonth, startQuincena } = req.body;
  const numAmount = Number(amount);
  if (!numAmount || numAmount <= 0) {
    return res.status(400).json({ error: 'Ingresa un monto de descuento válido en Quetzales mayor a cero.' });
  }
  if (!reason || !reason.trim()) {
    return res.status(400).json({ error: 'El motivo por el cual se descontará dicho monto es estrictamente obligatorio.' });
  }

  if (!employee.discounts) {
    employee.discounts = [];
  }
  if (!employee.discountHistory) {
    employee.discountHistory = [];
  }

  // Cuotas y quincena de inicio (por defecto, la quincena que se está trabajando; se puede cambiar)
  const totalInstallments = installments === undefined || installments === null || installments === '' ? 1 : Math.floor(Number(installments));
  if (!Number.isFinite(totalInstallments) || totalInstallments < 1 || totalInstallments > 24) {
    return res.status(400).json({ error: 'El número de cuotas (quincenas) debe ser un entero entre 1 y 24.' });
  }
  const hasStartInput = startYear !== undefined || startMonth !== undefined || startQuincena !== undefined;
  const startRef = hasStartInput
    ? parseQuincenaRef(startYear, startMonth, startQuincena)
    : (date ? quincenaFromDate(String(date)) : currentQuincena());
  if (!startRef) {
    return res.status(400).json({ error: 'La quincena de inicio es inválida: indica año, mes y quincena (1ra o 2da).' });
  }

  // Validar conflicto: Misma fecha (mes/año) y mismo periodo (si aplica) para el mismo empleado
  const discountDate = new Date(date || new Date().toISOString().slice(0, 10));
  const monthKey = `${discountDate.getFullYear()}-${discountDate.getMonth() + 1}`;
  const isConflict = employee.discounts.some((d: GuardDiscount) => {
    const existingDate = new Date(d.date);
    const existingMonthKey = `${existingDate.getFullYear()}-${existingDate.getMonth() + 1}`;
    // Si tienen el mismo periodo (si es que se usa) o simplemente ocurren en el mismo mes y son el mismo motivo
    return existingMonthKey === monthKey && d.period === period && d.reason === reason.trim();
  });

  if (isConflict) {
    return res.status(409).json({ error: 'Ya existe un descuento igual registrado para este colaborador en el periodo seleccionado.' });
  }

  const newDiscount: GuardDiscount = {
    id: `disc-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    amount: numAmount,
    reason: reason.trim(),
    description: description ? description.trim() : undefined,
    period: period || '1RA_QUINCENA',
    date: date || new Date().toISOString().slice(0, 10),
    appliedBy: currentUser.name,
    discountType: discountType || (reason.toLowerCase().includes('uniforme') ? 'UNIFORME' : (reason.toLowerCase().includes('anticipo') ? 'ANTICIPO' : 'OTRO')),
    installments: totalInstallments,
    installmentAmount: getInstallmentAmount({ amount: numAmount, installments: totalInstallments }, 1),
    startYear: startRef.year,
    startMonth: startRef.month,
    startQuincena: startRef.quincena,
    paidPeriods: [],
    installmentsPaid: 0,
    uniformItems: Array.isArray(uniformItems) ? uniformItems : undefined,
    uniformItemIds: Array.isArray(uniformItemIds) ? uniformItemIds : undefined,
    uniformQuantities: uniformQuantities && typeof uniformQuantities === 'object' ? uniformQuantities : undefined,
    uniformItemDetails: Array.isArray(uniformItemDetails) ? uniformItemDetails : undefined,
    status: 'ACTIVO',
  };

  // Decrement inventory if uniform items were assigned
  if (db.securityConfig?.inventoryItems) {
    if (Array.isArray(uniformItemDetails) && uniformItemDetails.length > 0) {
      for (const detail of uniformItemDetails) {
        const item = db.securityConfig.inventoryItems.find((i: any) => i.id === detail.id || i.name.toLowerCase() === (detail.name || '').toLowerCase());
        if (item) {
          const qty = Number(detail.quantity) || 1;
          item.stock = Math.max(0, item.stock - qty);
        }
      }
    } else if (uniformQuantities && typeof uniformQuantities === 'object') {
      for (const [invId, qty] of Object.entries(uniformQuantities)) {
        const item = db.securityConfig.inventoryItems.find((i: any) => i.id === invId);
        if (item) {
          item.stock = Math.max(0, item.stock - (Number(qty) || 1));
        }
      }
    } else if (Array.isArray(uniformItemIds) && uniformItemIds.length > 0) {
      for (const invId of uniformItemIds) {
        const item = db.securityConfig.inventoryItems.find((i: any) => i.id === invId);
        if (item) {
          item.stock = Math.max(0, item.stock - 1);
        }
      }
    } else if (Array.isArray(uniformItems) && uniformItems.length > 0) {
      for (const uStr of uniformItems) {
        const item = db.securityConfig.inventoryItems.find((i: any) => uStr.toLowerCase().includes(i.name.toLowerCase()));
        if (item) {
          item.stock = Math.max(0, item.stock - 1);
        }
      }
    }
  }

  employee.discounts.push(newDiscount);
  employee.discountHistory.unshift(newDiscount);
  employee.updatedAt = new Date().toISOString();
  employee.lastModifiedBy = currentUser.name;
  employee.lastModifiedById = currentUser.id;

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'EDITAR_EMPLEADO',
    entityType: 'EMPLEADO',
    entityId: employee.id,
    entityName: employee.name,
    summary: `Descuento de Q${newDiscount.amount.toFixed(2)} [${newDiscount.discountType || 'DESCUENTO'}] aplicado al guardia ${employee.name}. Motivo: ${newDiscount.reason}`,
    changes: [{ 
      field: 'discount', 
      label: 'Descuento Aplicado', 
      oldValue: null, 
      newValue: `Q${newDiscount.amount.toFixed(2)} (${newDiscount.reason}${newDiscount.installments && newDiscount.installments > 1 ? ` - ${newDiscount.installments} cuotas desde la ${quincenaLabel(startRef)}` : ` - ${quincenaLabel(startRef)}`})` 
    }],
    isCritical: true,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.json({
    success: true,
    discount: newDiscount,
    employee,
    inventoryItems: db.securityConfig.inventoryItems,
    securityConfig: db.securityConfig,
  });
});

// Editar la quincena de inicio (y opcionalmente el número de cuotas) de un descuento
app.put('/api/employees/:id/discounts/:discountId', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede editar la quincena de inicio de un descuento.' });
  }
  const employee = db.employees.find((e: Employee) => e.id === req.params.id);
  if (!employee) {
    return res.status(404).json({ error: 'Guardia no encontrado.' });
  }
  const disc = (employee.discounts || []).find(d => d.id === req.params.discountId);
  if (!disc) {
    return res.status(404).json({ error: 'Descuento no encontrado.' });
  }
  if (disc.status === 'ELIMINADO' || disc.status === 'CANCELADO') {
    return res.status(409).json({ error: 'No se puede editar un descuento anulado.' });
  }

  const { startYear, startMonth, startQuincena, installments } = req.body || {};
  const newStart = parseQuincenaRef(startYear ?? disc.startYear, startMonth ?? disc.startMonth, startQuincena ?? disc.startQuincena);
  if (!newStart) {
    return res.status(400).json({ error: 'La quincena de inicio es inválida: indica año, mes y quincena (1ra o 2da).' });
  }
  const newTotal = installments === undefined ? getTotalInstallments(disc) : Math.floor(Number(installments));
  if (!Number.isFinite(newTotal) || newTotal < 1 || newTotal > 24) {
    return res.status(400).json({ error: 'El número de cuotas (quincenas) debe ser un entero entre 1 y 24.' });
  }

  const candidate = { ...disc, startYear: newStart.year, startMonth: newStart.month, startQuincena: newStart.quincena, installments: newTotal };
  // Las cuotas ya guardadas en planillas son un registro fijo: deben seguir dentro del nuevo rango.
  const outside = (disc.paidPeriods || []).map(normalizePeriodKey).filter(key => {
    const [y, m, qq] = key.split('-');
    const ref = parseQuincenaRef(y, m, String(qq).replace(/^Q/i, ''));
    return !ref || getInstallmentNumber(candidate, ref) === null;
  });
  if (outside.length > 0) {
    return res.status(409).json({
      error: `Ese cambio dejaría fuera quincenas ya guardadas en planilla (${outside.join(', ')}). Reabre esas quincenas en el Centro de Nómina y vuelve a editar.`,
    });
  }

  const before = `${quincenaLabel(getStartQuincena(disc) || newStart)} · ${getTotalInstallments(disc)} cuota(s)`;
  disc.startYear = newStart.year;
  disc.startMonth = newStart.month;
  disc.startQuincena = newStart.quincena;
  disc.installments = newTotal;
  disc.installmentAmount = getInstallmentAmount({ amount: disc.amount, installments: newTotal }, 1);
  refreshDiscountState(employee, disc);

  employee.updatedAt = new Date().toISOString();
  employee.lastModifiedBy = currentUser.name;
  employee.lastModifiedById = currentUser.id;
  db.auditLogs.unshift({
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'EDITAR_EMPLEADO',
    entityType: 'EMPLEADO',
    entityId: employee.id,
    entityName: employee.name,
    summary: `Descuento "${disc.reason}" de ${employee.name}: quincena de inicio / cuotas modificadas.`,
    changes: [{ field: 'discountStart', label: 'Inicio del descuento', oldValue: before, newValue: `${quincenaLabel(newStart)} · ${newTotal} cuota(s)` }],
    isCritical: true,
  });
  writeDatabase(db);
  res.json({ success: true, discount: disc, employee });
});

app.delete('/api/employees/:id/discounts/:discountId', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede eliminar o anular descuentos.' });
  }

  const employee = db.employees.find((e: Employee) => e.id === req.params.id);
  if (!employee) {
    return res.status(404).json({ error: 'Guardia no encontrado.' });
  }

  if (!employee.discounts) {
    employee.discounts = [];
  }
  if (!employee.discountHistory) {
    employee.discountHistory = [];
  }

  const discountIndex = employee.discounts.findIndex((d: any) => d.id === req.params.discountId);
  if (discountIndex === -1) {
    return res.status(404).json({ error: 'Descuento activo no encontrado.' });
  }

  const removedDisc = employee.discounts[discountIndex];
  const deletionReason = String(req.query.reason || req.body?.reason || 'Eliminado/Anulado por el Administrador');
  const nowIso = new Date().toISOString();

  // Create deleted record with audit metadata for worker history
  const deletedRecord: GuardDiscount = {
    ...removedDisc,
    status: 'ELIMINADO',
    deletedAt: nowIso,
    deletedBy: currentUser.name,
    deletionReason: deletionReason,
  };

  // Remove from active discounts list
  employee.discounts.splice(discountIndex, 1);

  // Restituir stock de inventario si el descuento eliminado era de uniformes
  if (removedDisc.discountType === 'UNIFORME' && db.securityConfig?.inventoryItems) {
    if (Array.isArray(removedDisc.uniformItemDetails) && removedDisc.uniformItemDetails.length > 0) {
      for (const detail of removedDisc.uniformItemDetails) {
        const item = db.securityConfig.inventoryItems.find((i: any) => i.id === detail.id || i.name.toLowerCase() === (detail.name || '').toLowerCase());
        if (item) {
          item.stock += (Number(detail.quantity) || 1);
        }
      }
    } else if (removedDisc.uniformQuantities && typeof removedDisc.uniformQuantities === 'object') {
      for (const [invId, qty] of Object.entries(removedDisc.uniformQuantities)) {
        const item = db.securityConfig.inventoryItems.find((i: any) => i.id === invId);
        if (item) {
          item.stock += (Number(qty) || 1);
        }
      }
    } else if (Array.isArray(removedDisc.uniformItemIds) && removedDisc.uniformItemIds.length > 0) {
      for (const invId of removedDisc.uniformItemIds) {
        const item = db.securityConfig.inventoryItems.find((i: any) => i.id === invId);
        if (item) {
          item.stock += 1;
        }
      }
    } else if (Array.isArray(removedDisc.uniformItems) && removedDisc.uniformItems.length > 0) {
      for (const uStr of removedDisc.uniformItems) {
        const item = db.securityConfig.inventoryItems.find((i: any) => uStr.toLowerCase().includes(i.name.toLowerCase()));
        if (item) {
          item.stock += 1;
        }
      }
    }
  }

  // Update in or prepend to discountHistory so it appears in worker's permanent history
  const histIdx = employee.discountHistory.findIndex((d: any) => d.id === req.params.discountId);
  if (histIdx >= 0) {
    employee.discountHistory[histIdx] = deletedRecord;
  } else {
    employee.discountHistory.unshift(deletedRecord);
  }

  employee.updatedAt = nowIso;
  employee.lastModifiedBy = currentUser.name;
  employee.lastModifiedById = currentUser.id;

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: nowIso,
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'EDITAR_EMPLEADO',
    entityType: 'EMPLEADO',
    entityId: employee.id,
    entityName: employee.name,
    summary: `Descuento de Q${removedDisc.amount.toFixed(2)} (${removedDisc.reason}) ELIMINADO/ANULADO del guardia ${employee.name} por ${currentUser.name}. Motivo: ${deletionReason}`,
    changes: [{
      field: 'discount_deleted',
      label: 'Descuento Eliminado',
      oldValue: `Q${removedDisc.amount.toFixed(2)} (${removedDisc.reason})`,
      newValue: `ELIMINADO (${deletionReason})`,
    }],
    isCritical: true,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.json({
    success: true,
    employee,
    deletedDiscount: deletedRecord,
    inventoryItems: db.securityConfig.inventoryItems,
    securityConfig: db.securityConfig,
  });
});

app.post('/api/employees/:id/documents/:docType', (req, res) => {
  const db = readDatabase();
  const employee = db.employees.find((e: any) => e.id === req.params.id);
  if (!employee) return res.status(404).json({ error: 'Colaborador no encontrado.' });

  const { fileContent, otherName } = req.body; // Expecting base64 string
  if (!employee.documents) employee.documents = {};
  
  if (req.params.docType === 'others') {
    if (!employee.documents.others) employee.documents.others = [];
    employee.documents.others.push({ name: otherName, url: fileContent });
  } else {
    employee.documents[req.params.docType] = fileContent;
  }
  
  employee.updatedAt = new Date().toISOString();
  writeDatabase(db);
  res.json({ success: true, documents: employee.documents });
});

app.delete('/api/employees/:id/documents/:docType/:index?', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede eliminar documentos.' });
  }

  const employee = db.employees.find((e: any) => e.id === req.params.id);
  if (!employee || !employee.documents) return res.status(404).json({ error: 'Colaborador o documentos no encontrados.' });

  const { docType, index } = req.params;
  
  if (docType === 'others') {
    if (index !== undefined && employee.documents.others) {
      employee.documents.others.splice(parseInt(index), 1);
    }
  } else {
    delete employee.documents[docType];
  }
  
  employee.updatedAt = new Date().toISOString();
  writeDatabase(db);
  res.json({ success: true, documents: employee.documents });
});

// ==========================================
// PAGOS DE QUINCENA / BANCOS DE GUATEMALA
// ==========================================
// Helper for Quetzales amount in words for receipts
function integerToSpanishWords(n: number): string {
  const units = ['CERO', 'UN', 'DOS', 'TRES', 'CUATRO', 'CINCO', 'SEIS', 'SIETE', 'OCHO', 'NUEVE', 'DIEZ',
    'ONCE', 'DOCE', 'TRECE', 'CATORCE', 'QUINCE', 'DIECISÉIS', 'DIECISIETE', 'DIECIOCHO', 'DIECINUEVE',
    'VEINTE', 'VEINTIÚN', 'VEINTIDÓS', 'VEINTITRÉS', 'VEINTICUATRO', 'VEINTICINCO', 'VEINTISÉIS',
    'VEINTISIETE', 'VEINTIOCHO', 'VEINTINUEVE'];
  const tens = ['', '', '', 'TREINTA', 'CUARENTA', 'CINCUENTA', 'SESENTA', 'SETENTA', 'OCHENTA', 'NOVENTA'];
  const hundreds = ['', 'CIENTO', 'DOSCIENTOS', 'TRESCIENTOS', 'CUATROCIENTOS', 'QUINIENTOS', 'SEISCIENTOS',
    'SETECIENTOS', 'OCHOCIENTOS', 'NOVECIENTOS'];

  const below1000 = (x: number): string => {
    if (x === 0) return '';
    if (x === 100) return 'CIEN';
    const h = Math.floor(x / 100);
    const r = x % 100;
    const parts: string[] = [];
    if (h > 0) parts.push(hundreds[h]);
    if (r > 0) {
      if (r < 30) parts.push(units[r]);
      else {
        const t = Math.floor(r / 10);
        const u = r % 10;
        parts.push(u === 0 ? tens[t] : `${tens[t]} Y ${units[u]}`);
      }
    }
    return parts.join(' ');
  };

  if (n === 0) return 'CERO';
  const millions = Math.floor(n / 1_000_000);
  const thousands = Math.floor((n % 1_000_000) / 1000);
  const rest = n % 1000;
  const parts: string[] = [];
  if (millions > 0) parts.push(millions === 1 ? 'UN MILLÓN' : `${below1000(millions)} MILLONES`);
  if (thousands > 0) parts.push(thousands === 1 ? 'MIL' : `${below1000(thousands)} MIL`);
  if (rest > 0) parts.push(below1000(rest));
  return parts.join(' ');
}

function numberToWordsGTQ(num: number): string {
  const safe = Number.isFinite(num) && num > 0 ? num : 0;
  let integerPart = Math.floor(safe);
  let cents = Math.round((safe - integerPart) * 100);
  if (cents === 100) {
    integerPart += 1;
    cents = 0;
  }
  const centsStr = String(cents).padStart(2, '0') + '/100';
  const currency = integerPart === 1 ? 'QUETZAL' : 'QUETZALES';
  const connector = integerPart >= 1_000_000 && integerPart % 1_000_000 === 0 ? ' DE' : '';
  return `${integerToSpanishWords(integerPart)}${connector} ${currency} CON ${centsStr}`;
}

// ==========================================
// PAGOS DE QUINCENA / BANCOS DE GUATEMALA / RECIBOS
// ==========================================
app.get('/api/payments', (req, res) => {
  const db = readDatabase();
  res.json(db.payments || []);
});

app.post('/api/payments', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede procesar y registrar pagos de guardias.' });
  }

  const {
    employeeId,
    period,
    year,
    month,
    calculatedAmount,
    paidAmount,
    paymentMethod,
    bankName,
    referenceNumber,
    notes,
    notifyGuard,
    specificDate,
    cancelDiscountIds, // Array of discount IDs to mark as CANCELADO
  } = req.body;

  const employee = db.employees.find((e: Employee) => e.id === employeeId);
  if (!employee) {
    return res.status(404).json({ error: 'Guardia no encontrado.' });
  }

  if (!db.payments) {
    db.payments = [];
  }

  let periodLabel = '1ra Quincena';
  if (period === '2DA_QUINCENA') periodLabel = '2da Quincena';
  else if (period === 'MES_COMPLETO') periodLabel = 'Mes Completo';
  else if (period === 'DIA_ESPECIFICO') periodLabel = `Día Específico (${specificDate || 'Fecha'})`;

  const finalPaidAmount = Number(paidAmount) || Number(calculatedAmount) || 0;

  // Mark specified discounts as CANCELADO if requested
  if (Array.isArray(cancelDiscountIds) && cancelDiscountIds.length > 0 && employee.discounts) {
    employee.discounts = employee.discounts.map(d => {
      if (cancelDiscountIds.includes(d.id)) {
        const updatedD = { ...d, status: 'CANCELADO' as const };
        if (!employee.discountHistory) employee.discountHistory = [];
        employee.discountHistory.unshift(updatedD);
        return updatedD;
      }
      return d;
    });
    // Remove canceled from active pending discounts
    employee.discounts = employee.discounts.filter(d => d.status !== 'CANCELADO');
    employee.updatedAt = new Date().toISOString();
    employee.lastModifiedBy = currentUser.name;
  }

  const newPayment = {
    id: `pay-${Date.now()}`,
    employeeId,
    employeeName: employee.name,
    period: period || '1RA_QUINCENA',
    specificDate: specificDate || undefined,
    year: Number(year) || new Date().getFullYear(),
    month: Number(month) || (new Date().getMonth() + 1),
    calculatedAmount: Number(calculatedAmount) || 0,
    paidAmount: finalPaidAmount,
    paymentMethod: paymentMethod || 'TRANSFERENCIA',
    bankName: bankName || 'Banco Industrial (BI)',
    referenceNumber: referenceNumber ? String(referenceNumber).trim() : '',
    status: 'PAGADO' as const,
    paymentDate: new Date().toISOString().slice(0, 10),
    notes: notes ? String(notes).trim() : '',
    notifiedGuard: !!notifyGuard,
  };

  db.payments.unshift(newPayment);

  // Automatically generate a Payment Receipt
  const newReceipt: PaymentReceipt = {
    id: `rcpt-${Date.now()}`,
    employeeId,
    employeeName: employee.name,
    employeeDpi: employee.dpi || 'N/A',
    amount: finalPaidAmount,
    amountInWords: numberToWordsGTQ(finalPaidAmount),
    concept: notes ? notes : `PAGO DE ${periodLabel.toUpperCase()} - ${month}/${year}`,
    period: periodLabel,
    day: new Date().getDate(),
    month: Number(month) || (new Date().getMonth() + 1),
    year: Number(year) || new Date().getFullYear(),
    paymentMethod: paymentMethod || 'EFECTIVO',
    referenceNumber: referenceNumber || '',
    observations: notes || `Pago registrado por ${currentUser.name}`,
    issuedBy: currentUser.name,
    createdAt: new Date().toISOString(),
  };

  if (!db.receipts) db.receipts = [];
  db.receipts.unshift(newReceipt);

  // Notificar al guardia si tiene cuenta
  if (notifyGuard) {
    const paymentNotif: RealtimeNotification = {
      id: `notif-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: `Pago Realizado: ${periodLabel}`,
      message: `Hola ${employee.name}, se ha realizado el pago de tu ${periodLabel} por valor de Q${finalPaidAmount.toFixed(2)} mediante ${newPayment.paymentMethod === 'TRANSFERENCIA' ? 'Transferencia Bancaria' : newPayment.paymentMethod === 'CHEQUE' ? 'Cheque' : 'Efectivo'} en ${newPayment.bankName}${newPayment.referenceNumber ? ` (Ref: ${newPayment.referenceNumber})` : ''}.`,
      type: 'salary',
      actorName: currentUser.name,
      read: false,
      linkTab: 'payments',
    };
    db.notifications.unshift(paymentNotif);
  }

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'EDITAR_EMPLEADO',
    entityType: 'EMPLEADO',
    entityId: employee.id,
    entityName: employee.name,
    summary: `Pago de ${periodLabel} registrado para ${employee.name}: Q${finalPaidAmount.toFixed(2)} (${newPayment.paymentMethod} - ${newPayment.bankName})`,
    changes: [{ field: 'payment', label: `Pago ${periodLabel}`, oldValue: null, newValue: `Q${finalPaidAmount.toFixed(2)}` }],
    isCritical: true,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.status(201).json({ payment: newPayment, receipt: newReceipt });
});

// Receipts Management Routes
app.get('/api/receipts', (req, res) => {
  const db = readDatabase();
  res.json(db.receipts || []);
});

app.post('/api/receipts', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede crear recibos.' });
  }
  const { employeeId, employeeName, amount, concept, period, paymentMethod, referenceNumber, observations, day, month, year } = req.body;
  const emp = db.employees.find(e => e.id === employeeId);
  const finalAmount = Number(amount) || 0;
  const newReceipt: PaymentReceipt = {
    id: `rcpt-${Date.now()}`,
    employeeId: employeeId || emp?.id || 'emp-unknown',
    employeeName: employeeName || emp?.name || 'Colaborador',
    employeeDpi: emp?.dpi || 'N/A',
    amount: finalAmount,
    amountInWords: numberToWordsGTQ(finalAmount),
    concept: concept || 'PAGO DE SERVICIOS DE SEGURIDAD',
    period: period || 'MENSUAL',
    day: Number(day) || new Date().getDate(),
    month: Number(month) || (new Date().getMonth() + 1),
    year: Number(year) || new Date().getFullYear(),
    paymentMethod: paymentMethod || 'EFECTIVO',
    referenceNumber: referenceNumber || '',
    observations: observations || '',
    issuedBy: currentUser.name,
    createdAt: new Date().toISOString(),
  };
  if (!db.receipts) db.receipts = [];
  db.receipts.unshift(newReceipt);
  writeDatabase(db);
  res.status(201).json(newReceipt);
});

app.delete('/api/receipts/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede eliminar recibos.' });
  }
  const idx = (db.receipts || []).findIndex(r => r.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Recibo no encontrado.' });
  }
  db.receipts.splice(idx, 1);
  writeDatabase(db);
  res.json({ success: true });
});

// ==========================================
// MOTOR DE CÁLCULO DE PLANILLAS Y DESCUENTOS PROGRAMADOS
// ==========================================
app.get('/api/payroll/history', (req, res) => {
  const db = readDatabase();
  res.json(db.payrollHistory || []);
});

app.post('/api/payroll/calculate', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN' && currentUser.role !== 'GUEST') {
    return res.status(403).json({ error: 'No tienes autorización para calcular planillas.' });
  }

  const body = req.body || {};
  const target = parseQuincenaRef(
    body.year ?? body.anio ?? new Date().getFullYear(),
    body.month ?? body.mes ?? new Date().getMonth() + 1,
    body.tipo_quincena ?? body.period ?? 1
  );
  if (!target) {
    return res.status(400).json({ error: 'Quincena inválida: indica año, mes y quincena (1ra o 2da).' });
  }
  const companyId: string | undefined = body.companyId && body.companyId !== 'all' ? String(body.companyId) : undefined;

  // Lo ya guardado para esta quincena es un registro fijo: se lee tal cual, nunca se recalcula.
  const savedRecords = findSavedPayrolls(db, target);
  const savedByEmployee = new Map<string, any>();
  for (const rec of savedRecords) {
    for (const row of rec.rows || []) savedByEmployee.set(row.employeeId, { row, rec });
  }

  const employees = db.employees.filter((e: Employee) => e.status === 'ACTIVO' && (!companyId || e.companyId === companyId));
  const rows: any[] = [];
  let pendingCount = 0;
  for (const emp of employees) {
    const saved = savedByEmployee.get(emp.id);
    if (saved) {
      rows.push({ ...saved.row, saved: true });
    } else {
      pendingCount++;
      rows.push({ ...computeEmployeePayrollRow(db, emp, target), saved: false });
    }
  }
  // Colaboradores que ya estaban en la planilla guardada pero hoy no aparecen (p. ej. dados de baja luego).
  for (const [empId, saved] of savedByEmployee) {
    if (rows.some(r => r.employeeId === empId)) continue;
    if (companyId && saved.row.companyId !== companyId) continue;
    rows.push({ ...saved.row, saved: true });
  }

  const totalSaved = rows.length > 0 && pendingCount === 0;
  res.json({
    anio: target.year,
    mes: MONTH_NAMES_ES[target.month - 1],
    mesNumero: target.month,
    quincena: target.quincena,
    tipo_quincena: target.quincena === 1 ? '1RA_QUINCENA' : '2DA_QUINCENA',
    periodKey: quincenaKey(target),
    periodLabel: quincenaLabel(target),
    saved: totalSaved,
    partiallySaved: savedByEmployee.size > 0 && !totalSaved,
    records: savedRecords.map((r: any) => ({ id: r.id, companyId: r.companyId, fecha_creacion: r.fecha_creacion, savedBy: r.savedBy })),
    rows,
  });
});

app.post('/api/payroll/save', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el Administrador puede guardar y congelar el historial de planillas.' });
  }

  const body = req.body || {};
  const target = parseQuincenaRef(body.anio ?? body.year, body.mes ?? body.month, body.tipo_quincena ?? body.period);
  if (!target) {
    return res.status(400).json({ error: 'Datos de planilla incompletos: indica año, mes y quincena.' });
  }
  const companyId: string | undefined = body.companyId && body.companyId !== 'all' ? String(body.companyId) : undefined;
  const periodKey = quincenaKey(target);

  // Estado por colaborador que envía el cliente (p. ej. "PAGADO"); lo demás se calcula aquí, no se confía en el cliente.
  const clientStatus = new Map<string, string>();
  for (const r of Array.isArray(body.rows) ? body.rows : []) {
    if (r && r.employeeId && r.status) clientStatus.set(r.employeeId, String(r.status));
  }

  // Cada colaborador se guarda una sola vez por quincena: guardar de nuevo no duplica ni corre cuotas.
  const alreadySaved = new Set<string>();
  for (const rec of findSavedPayrolls(db, target)) {
    for (const row of rec.rows || []) alreadySaved.add(row.employeeId);
  }
  const employees = db.employees.filter((e: Employee) =>
    e.status === 'ACTIVO' && (!companyId || e.companyId === companyId) && !alreadySaved.has(e.id)
  );
  if (employees.length === 0) {
    return res.status(409).json({
      error: `La ${quincenaLabel(target)} ya está guardada. El registro es fijo; para corregirla reabre la quincena en el Centro de Nómina.`,
    });
  }

  const rows = employees.map((emp: Employee) => {
    const row: any = computeEmployeePayrollRow(db, emp, target);
    const status = clientStatus.get(emp.id);
    if (status) row.status = status;
    return row;
  });

  if (!db.payrollHistory) db.payrollHistory = [];
  const payrollRecord = {
    id: `pay-hist-${Date.now()}`,
    anio: target.year,
    mes: MONTH_NAMES_ES[target.month - 1],
    mesNumero: target.month,
    quincena: target.quincena,
    tipo_quincena: target.quincena === 1 ? '1RA_QUINCENA' : '2DA_QUINCENA',
    periodKey,
    companyId: companyId || 'all',
    fecha_creacion: new Date().toISOString(),
    savedBy: currentUser.name,
    rows,
    totalPayrollAmount: round2(rows.reduce((acc: number, r: any) => acc + (r.netAmount || 0), 0)),
  };
  db.payrollHistory.unshift(payrollRecord);

  // Registrar la quincena cobrada en cada descuento (conjunto, sin duplicar) y cerrar los que ya completaron sus cuotas.
  for (const row of rows) {
    const emp = db.employees.find((e: Employee) => e.id === row.employeeId);
    if (!emp) continue;
    for (const applied of row.appliedDiscounts) {
      const disc = (emp.discounts || []).find(d => d.id === applied.id);
      if (!disc) continue;
      disc.paidPeriods = Array.from(new Set([...(disc.paidPeriods || []).map(normalizePeriodKey), periodKey]));
      refreshDiscountState(emp, disc);
    }
  }

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'CREAR_EMPRESA',
    entityType: 'EMPRESA',
    entityId: payrollRecord.id,
    entityName: `Planilla ${quincenaLabel(target)}`,
    summary: `Planilla de la ${quincenaLabel(target)} guardada como registro fijo por ${currentUser.name}. Cuotas de descuentos registradas; descuentos completados marcados como finalizados.`,
    changes: [{ field: 'payroll', label: 'Planilla Quincenal', oldValue: null, newValue: `${quincenaLabel(target)} (Q${payrollRecord.totalPayrollAmount.toFixed(2)})` }],
    isCritical: true,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.status(201).json({ success: true, payrollRecord });
});

// Reabrir una quincena guardada (p. ej. si se aplicó en la quincena equivocada): libera sus cuotas de descuentos.
app.delete('/api/payroll/history/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el Administrador puede reabrir una planilla guardada.' });
  }
  const idx = (db.payrollHistory || []).findIndex((h: any) => h.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Planilla guardada no encontrada.' });
  }
  const record = db.payrollHistory[idx];
  releasePayrollRecord(db, record);
  db.payrollHistory.splice(idx, 1);

  const q = payrollRecordQuincena(record);
  const label = q ? quincenaLabel(q) : `${record.tipo_quincena} ${record.mes} ${record.anio}`;
  db.auditLogs.unshift({
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'EDITAR_EMPRESA',
    entityType: 'EMPRESA',
    entityId: record.id,
    entityName: `Planilla ${label}`,
    summary: `Planilla de la ${label} reabierta por ${currentUser.name}. Las cuotas de descuentos de esa quincena quedaron liberadas.`,
    changes: [{ field: 'payroll', label: 'Planilla Quincenal', oldValue: `Guardada (Q${Number(record.totalPayrollAmount || 0).toFixed(2)})`, newValue: 'Reabierta' }],
    isCritical: true,
  });
  writeDatabase(db);
  res.json({ success: true });
});

// Custom Banks Management
app.post('/api/security/banks', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede agregar bancos.' });
  }
  const { bankName } = req.body;
  if (!bankName || !bankName.trim()) {
    return res.status(400).json({ error: 'Nombre de banco requerido.' });
  }
  if (!db.securityConfig.customBanks) {
    db.securityConfig.customBanks = [];
  }
  const cleanName = bankName.trim();
  if (!db.securityConfig.customBanks.includes(cleanName)) {
    db.securityConfig.customBanks.push(cleanName);
  }
  writeDatabase(db);
  res.json({ success: true, customBanks: db.securityConfig.customBanks });
});

// Data Backup Export & Year Purge
app.get('/api/data/export', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede exportar los datos.' });
  }
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename=guardia-real-backup-${new Date().toISOString().slice(0,10)}.json`);
  res.send(JSON.stringify(db, null, 2));
});

app.delete('/api/data/year/:year', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede borrar datos por año.' });
  }
  const targetYear = Number(req.params.year);
  if (!targetYear || isNaN(targetYear)) {
    return res.status(400).json({ error: 'Año inválido.' });
  }

  if (db.guardCheckins) {
    db.guardCheckins = db.guardCheckins.filter(c => new Date(c.timestamp).getFullYear() !== targetYear);
  }
  if (db.payments) {
    db.payments = db.payments.filter(p => p.year !== targetYear);
  }
  if (db.receipts) {
    db.receipts = db.receipts.filter(r => r.year !== targetYear);
  }
  if (db.auditLogs) {
    db.auditLogs = db.auditLogs.filter(l => new Date(l.timestamp).getFullYear() !== targetYear);
  }

  writeDatabase(db);
  res.json({ success: true, message: `Datos del año ${targetYear} eliminados correctamente.` });
});

// ==========================================
// GUARD QR CHECK-IN ATTENDANCE ROUTES
// ==========================================
app.get('/api/guard-checkins', (req, res) => {
  const db = readDatabase();
  res.json(db.guardCheckins || []);
});

app.post('/api/guard-checkins', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  const { type, checkpointCode, checkpointName, companyId, location, notes, delayReason, googleMapsUrl } = req.body;

  if (!type || !checkpointCode) {
    return res.status(400).json({ error: 'Tipo (ENTRADA/SALIDA) y código QR son obligatorios.' });
  }

  const comp = db.companies.find(c => c.id === companyId);
  const matchedCheckpoint = db.securityConfig?.checkpoints?.find(
    cp => cp.code === String(checkpointCode) || cp.name === checkpointName
  );

  const finalGoogleMapsUrl = googleMapsUrl || matchedCheckpoint?.googleMapsUrl || (location?.latitude && location?.longitude ? `https://maps.google.com/?q=${location.latitude},${location.longitude}` : undefined);
  const finalCheckpointName = checkpointName || matchedCheckpoint?.name || (comp ? `Punto de Control - ${comp.name}` : 'Puesto de Garita');

  const newCheckin: GuardCheckin = {
    id: `chk-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    guardId: currentUser.id,
    guardName: currentUser.name,
    employeeId: currentUser.employeeId,
    guardPinCode: currentUser.pinCode,
    type: type === 'SALIDA' ? 'SALIDA' : (type === 'REPORTE_UBICACION' ? 'REPORTE_UBICACION' : 'ENTRADA'),
    timestamp: new Date().toISOString(),
    checkpointCode: String(checkpointCode),
    checkpointName: finalCheckpointName,
    companyId: comp?.id || matchedCheckpoint?.companyId,
    companyName: comp?.name || matchedCheckpoint?.companyName,
    googleMapsUrl: finalGoogleMapsUrl,
    location: location || {
      latitude: null,
      longitude: null,
      accuracy: null,
      addressText: 'Ubicación sin GPS reportado',
    },
    notes: notes || '',
    delayReason: delayReason?.trim() || undefined,
    isOfflineSynced: false,
  };

  if (!db.guardCheckins) db.guardCheckins = [];
  db.guardCheckins.unshift(newCheckin);

  // Audit log entry
  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: newCheckin.timestamp,
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'MARCAJE_GUARDIA',
    entityType: 'MARCAJE_GUARDIA',
    entityId: newCheckin.id,
    entityName: `${newCheckin.type} - ${newCheckin.guardName}`,
    companyId: comp?.id,
    companyName: comp?.name,
    summary: `Marcaje de ${newCheckin.type} por guardia ${newCheckin.guardName} en ${newCheckin.checkpointName}${newCheckin.delayReason ? ` (Comentario de retraso: ${newCheckin.delayReason})` : ''}`,
    changes: [
      { field: 'type', label: 'Tipo de Marcaje', oldValue: null, newValue: newCheckin.type },
      { field: 'timestamp', label: 'Hora y Fecha', oldValue: null, newValue: newCheckin.timestamp },
      { field: 'location', label: 'Coordenadas GPS', oldValue: null, newValue: newCheckin.location.latitude ? `${newCheckin.location.latitude.toFixed(4)}, ${newCheckin.location.longitude?.toFixed(4)}` : 'N/A' },
      { field: 'delayReason', label: 'Justificación / Retraso', oldValue: null, newValue: newCheckin.delayReason || 'Sin retraso reportado' },
    ],
    isCritical: !!newCheckin.delayReason,
  };
  db.auditLogs.unshift(logEntry);

  // Real-time alert to Admin
  const notif: RealtimeNotification = {
    id: `notif-${Date.now()}`,
    timestamp: newCheckin.timestamp,
    title: `Marcaje de Guardia: ${newCheckin.type}${newCheckin.delayReason ? ' (Con Retraso)' : ''}`,
    message: `${newCheckin.guardName} registró ${newCheckin.type} en ${newCheckin.checkpointName} a las ${new Date(newCheckin.timestamp).toLocaleTimeString('es-GT')}.${newCheckin.delayReason ? ` Motivo: "${newCheckin.delayReason}"` : ''}`,
    type: 'guard',
    actorName: newCheckin.guardName,
    read: false,
    linkTab: 'guard',
  };
  db.notifications.unshift(notif);

  writeDatabase(db);
  res.status(201).json(newCheckin);
});

// Offline check-ins batch sync (Guard marcajes sin wifi)
app.post('/api/guard-checkins/sync-batch', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  const { checkins } = req.body;

  if (!Array.isArray(checkins) || checkins.length === 0) {
    return res.status(400).json({ error: 'Se esperaba un arreglo de marcajes para sincronizar.' });
  }

  const syncedRecords: GuardCheckin[] = [];
  if (!db.guardCheckins) db.guardCheckins = [];

  for (const item of checkins) {
    const matchedCheckpoint = db.securityConfig?.checkpoints?.find(
      cp => cp.code === String(item.checkpointCode) || cp.name === item.checkpointName
    );

    const checkinRecord: GuardCheckin = {
      id: item.id || `chk-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      guardId: currentUser.id || item.guardId || 'user-guard-1',
      guardName: currentUser.name || item.guardName || 'Guardia de Seguridad',
      employeeId: currentUser.employeeId || item.employeeId,
      guardPinCode: currentUser.pinCode || item.guardPinCode,
      type: item.type === 'SALIDA' ? 'SALIDA' : (item.type === 'REPORTE_UBICACION' ? 'REPORTE_UBICACION' : 'ENTRADA'),
      timestamp: item.timestamp || new Date().toISOString(), // Preserva la hora exacta offline
      checkpointCode: String(item.checkpointCode || 'QR-PUESTO-LOCAL'),
      checkpointName: item.checkpointName || matchedCheckpoint?.name || 'Punto de Control',
      companyId: item.companyId || matchedCheckpoint?.companyId,
      companyName: item.companyName || matchedCheckpoint?.companyName,
      googleMapsUrl: item.googleMapsUrl || matchedCheckpoint?.googleMapsUrl,
      location: item.location || {
        latitude: null,
        longitude: null,
        accuracy: null,
        addressText: 'Marcaje offline sincronizado',
      },
      notes: item.notes || 'Marcaje registrado en modo sin conexión',
      delayReason: item.delayReason?.trim() || undefined,
      isOfflineSynced: true,
    };

    // Avoid duplicate sync by ID
    const exists = db.guardCheckins.some(g => g.id === checkinRecord.id);
    if (!exists) {
      db.guardCheckins.unshift(checkinRecord);
      syncedRecords.push(checkinRecord);
    }
  }

  if (syncedRecords.length > 0) {
    const logEntry: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      action: 'MARCAJE_GUARDIA',
      entityType: 'MARCAJE_GUARDIA',
      entityId: `batch-${Date.now()}`,
      entityName: `${syncedRecords.length} Marcajes Offline Sincronizados`,
      summary: `Se subieron ${syncedRecords.length} marcajes capturados sin conexión a internet por ${currentUser.name}.`,
      changes: [
        { field: 'count', label: 'Cantidad Sincronizada', oldValue: 0, newValue: syncedRecords.length },
      ],
      isCritical: false,
    };
    db.auditLogs.unshift(logEntry);

    const notif: RealtimeNotification = {
      id: `notif-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Marcajes Offline Sincronizados con Éxito',
      message: `${currentUser.name} subió ${syncedRecords.length} marcaje(s) registrados previamente sin señal.`,
      type: 'guard',
      actorName: currentUser.name,
      read: false,
      linkTab: 'guard',
    };
    db.notifications.unshift(notif);

    writeDatabase(db);
  }

  res.json({ success: true, count: syncedRecords.length, synced: syncedRecords });
});

// ==========================================
// SYSTEM SECURITY CONFIG & ACCESS CODES (ADMIN ONLY)
// ==========================================
app.get('/api/security-config', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  res.json({
    adminAccessCode: currentUser.role === 'ADMIN' ? db.securityConfig.adminAccessCode : '••••••••',
    guardAccessCode: currentUser.role === 'ADMIN' ? db.securityConfig.guardAccessCode : '••••••••',
    guestAccessCode: currentUser.role === 'ADMIN' ? db.securityConfig.guestAccessCode : '••••••••',
    guardWallpaperUrl: db.securityConfig.guardWallpaperUrl,
    guardBaseSalary: db.securityConfig.guardBaseSalary ?? 4200,
    igssPercentage: db.securityConfig.igssPercentage ?? 4.83,
    checkpoints: db.securityConfig.checkpoints || [],
  });
});

app.put('/api/security-config', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador principal puede modificar los códigos de acceso, sueldo de guardias y porcentaje de IGSS.' });
  }

  const { 
    adminAccessCode, 
    guardAccessCode, 
    guestAccessCode, 
    guardWallpaperUrl, 
    guardBaseSalary, 
    igssPercentage, 
    checkpoints,
    uniformPrices,
    inventoryItems,
    applySalaryToAllGuards 
  } = req.body;

  const oldConfig = { ...db.securityConfig };
  const changes = [];

  if (adminAccessCode && adminAccessCode.trim() !== oldConfig.adminAccessCode) {
    const trimmedCode = adminAccessCode.trim();
    changes.push({ field: 'adminAccessCode', label: 'Código Administrador', oldValue: '••••', newValue: 'Actualizado' });
    db.securityConfig.adminAccessCode = trimmedCode;
    // Sincronizar clave de acceso a usuarios administradores para inicio de sesión inmediato
    for (const u of db.users) {
      if (u.role === 'ADMIN' || u.id === 'user-admin' || u.username === 'eleiva') {
        u.personalAccessCode = trimmedCode;
        u.pinCode = trimmedCode;
      }
    }
  }
  if (guardAccessCode && guardAccessCode.trim() !== oldConfig.guardAccessCode) {
    changes.push({ field: 'guardAccessCode', label: 'Código Guardia', oldValue: '••••', newValue: 'Actualizado' });
    db.securityConfig.guardAccessCode = guardAccessCode.trim();
  }
  if (guestAccessCode && guestAccessCode.trim() !== oldConfig.guestAccessCode) {
    changes.push({ field: 'guestAccessCode', label: 'Código Invitado', oldValue: '••••', newValue: 'Actualizado' });
    db.securityConfig.guestAccessCode = guestAccessCode.trim();
  }
  if (guardWallpaperUrl !== undefined && guardWallpaperUrl !== oldConfig.guardWallpaperUrl) {
    changes.push({ field: 'guardWallpaperUrl', label: 'Fondo Pantalla Guardias', oldValue: 'Anterior', newValue: 'Nuevo fondo asignado' });
    db.securityConfig.guardWallpaperUrl = guardWallpaperUrl;
  }
  if (uniformPrices && typeof uniformPrices === 'object') {
    db.securityConfig.uniformPrices = {
      gorra: Number(uniformPrices.gorra) || 60,
      pantalon: Number(uniformPrices.pantalon) || 180,
      botas: Number(uniformPrices.botas) || 250,
      camisaCafe: Number(uniformPrices.camisaCafe) || 120,
      playeraPolo: Number(uniformPrices.playeraPolo) || 90,
    };
    changes.push({ field: 'uniformPrices', label: 'Precios de Uniforme', oldValue: 'Anterior', newValue: 'Actualizados' });
  }
  if (Array.isArray(inventoryItems)) {
    db.securityConfig.inventoryItems = inventoryItems;
    // Sincronizar precios a uniformPrices si coinciden
    for (const item of inventoryItems) {
      const lower = (item.name || '').toLowerCase();
      if (lower.includes('gorra')) db.securityConfig.uniformPrices.gorra = Number(item.price) || db.securityConfig.uniformPrices.gorra;
      else if (lower.includes('pantalon') || lower.includes('pantalón')) db.securityConfig.uniformPrices.pantalon = Number(item.price) || db.securityConfig.uniformPrices.pantalon;
      else if (lower.includes('bota')) db.securityConfig.uniformPrices.botas = Number(item.price) || db.securityConfig.uniformPrices.botas;
      else if (lower.includes('camisa')) db.securityConfig.uniformPrices.camisaCafe = Number(item.price) || db.securityConfig.uniformPrices.camisaCafe;
      else if (lower.includes('polo') || lower.includes('playera')) db.securityConfig.uniformPrices.playeraPolo = Number(item.price) || db.securityConfig.uniformPrices.playeraPolo;
    }
    changes.push({ field: 'inventoryItems', label: 'Inventario de Accesorios y Precios', oldValue: 'Anterior', newValue: `${inventoryItems.length} artículos sincronizados` });
  }
  if (guardBaseSalary !== undefined && Number(guardBaseSalary) !== oldConfig.guardBaseSalary) {
    const newSalary = Number(guardBaseSalary) || 4200;
    changes.push({ field: 'guardBaseSalary', label: 'Sueldo Base Guardias', oldValue: `Q${oldConfig.guardBaseSalary || 4200}`, newValue: `Q${newSalary}` });
    db.securityConfig.guardBaseSalary = newSalary;

    if (applySalaryToAllGuards) {
      let countUpdated = 0;
      for (const emp of db.employees) {
        if (emp.position.toLowerCase().includes('guardia') || emp.position.toLowerCase().includes('seguridad')) {
          emp.monthlySalary = newSalary;
          emp.updatedAt = new Date().toISOString();
          emp.lastModifiedBy = currentUser.name;
          countUpdated++;
        }
      }
      changes.push({ field: 'guardsUpdated', label: 'Colaboradores Actualizados', oldValue: 0, newValue: countUpdated });
    }
  }
  if (igssPercentage !== undefined && Number(igssPercentage) !== oldConfig.igssPercentage) {
    const newIgss = Number(igssPercentage) || 4.83;
    changes.push({ field: 'igssPercentage', label: 'Porcentaje Retención IGSS', oldValue: `${oldConfig.igssPercentage || 4.83}%`, newValue: `${newIgss}%` });
    db.securityConfig.igssPercentage = newIgss;
  }
  if (Array.isArray(checkpoints)) {
    db.securityConfig.checkpoints = checkpoints;
  }

  if (changes.length > 0) {
    const logEntry: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      action: 'CAMBIO_CODIGOS_SEGURIDAD',
      entityType: 'SEGURIDAD',
      entityId: 'security-config',
      entityName: 'Ajustes Salariales & Seguridad',
      summary: `El Administrador Principal actualizó los parámetros de seguridad, sueldo de guardias o porcentaje de IGSS.`,
      changes,
      isCritical: true,
    };
    db.auditLogs.unshift(logEntry);

    const notif: RealtimeNotification = {
      id: `notif-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Ajustes Salariales & Seguridad Actualizados',
      message: `${currentUser.name} actualizó los sueldos de guardias, IGSS o códigos de acceso.`,
      type: 'salary',
      actorName: currentUser.name,
      read: false,
      linkTab: 'permissions',
    };
    db.notifications.unshift(notif);
  }

  writeDatabase(db);
  res.json(db.securityConfig);
});

// User Personal Wallpaper (Except Guards)
app.post('/api/users/personal-wallpaper', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role === 'GUARD') {
    return res.status(403).json({ error: 'Los guardias de seguridad utilizan el fondo corporativo oficial establecido por el Administrador Principal.' });
  }

  const { wallpaperUrl } = req.body;
  const user = db.users.find(u => u.id === currentUser.id);
  if (!user) {
    return res.status(404).json({ error: 'Usuario no encontrado.' });
  }

  user.personalWallpaperUrl = wallpaperUrl?.trim() || undefined;
  writeDatabase(db);
  res.json({ success: true, personalWallpaperUrl: user.personalWallpaperUrl });
});

// Checkpoint Stores Management with Google Maps Links
app.post('/api/checkpoints', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador principal puede configurar tiendas y enlaces de Google Maps.' });
  }

  const { name, companyId, googleMapsUrl, address } = req.body;
  if (!name || !googleMapsUrl) {
    return res.status(400).json({ error: 'Nombre de la tienda y enlace de Google Maps son obligatorios.' });
  }

  const comp = db.companies.find(c => c.id === companyId);
  const newCheckpoint: StoreCheckpoint = {
    id: `chkpoint-${Date.now()}`,
    name: name.trim(),
    companyId: comp?.id,
    companyName: comp?.name,
    googleMapsUrl: googleMapsUrl.trim(),
    address: address?.trim() || comp?.address || 'Guatemala',
    code: `QR-TIENDA-${(comp?.name || name).toUpperCase().replace(/[^A-Z0-9]/g, '')}-${Date.now().toString().slice(-4)}`,
    createdAt: new Date().toISOString(),
  };

  if (!db.securityConfig.checkpoints) db.securityConfig.checkpoints = [];
  db.securityConfig.checkpoints.push(newCheckpoint);

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'CREAR_TIENDA_CHECKPOINT',
    entityType: 'TIENDA_CHECKPOINT',
    entityId: newCheckpoint.id,
    entityName: newCheckpoint.name,
    companyId: comp?.id,
    companyName: comp?.name,
    summary: `Nueva tienda para escaneo QR creada: ${newCheckpoint.name} con enlace a Google Maps`,
    changes: [
      { field: 'name', label: 'Nombre Tienda', oldValue: null, newValue: newCheckpoint.name },
      { field: 'googleMapsUrl', label: 'Enlace Google Maps', oldValue: null, newValue: newCheckpoint.googleMapsUrl },
    ],
    isCritical: false,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.status(201).json(newCheckpoint);
});

app.delete('/api/checkpoints/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede eliminar tiendas.' });
  }

  const index = db.securityConfig.checkpoints.findIndex(c => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Tienda o punto de control no encontrado.' });
  }

  db.securityConfig.checkpoints.splice(index, 1);
  writeDatabase(db);
  res.json({ success: true });
});

// ==========================================
// AUTHENTICATION & LOGIN (GOOGLE, USERNAME/PASS & ROLE CODES)
// ==========================================
app.post('/api/auth/verify-code', (req, res) => {
  const db = readDatabase();
  const { code, username, password } = req.body;

  // 1. Direct login by username and password (e.g. Usuario: eleiva, Contraseña: 2004)
  if (username && password) {
    const cleanUser = String(username).trim().toLowerCase();
    const cleanPass = String(password).trim();

    const currentAdminCode = (db.securityConfig?.adminAccessCode || '2004').trim();
    const adminUser = db.users.find(u => u.username === 'eleiva' || u.role === 'ADMIN' || u.id === 'user-admin') || db.users[0];

    // Check main admin eleiva / admin
    const isAdminAccount = cleanUser === 'eleiva' || cleanUser === 'michbaquiaxgt@gmail.com' || cleanUser === 'admin';
    const isAdminPassMatch = cleanPass === currentAdminCode || cleanPass === (adminUser?.personalAccessCode?.trim() || currentAdminCode);

    if (isAdminAccount && isAdminPassMatch) {
      adminUser.role = 'ADMIN';
      adminUser.username = 'eleiva';
      adminUser.name = 'E. Leiva (Administrador Principal)';
      return res.json({
        success: true,
        role: 'ADMIN',
        user: { ...adminUser, loginMethod: 'DIRECT' },
        message: '¡Bienvenido Administrador Principal E. Leiva! Acceso total al sistema concedido.',
      });
    }

    // Check other registered users with matching username and personalAccessCode
    const matchedUser = db.users.find(u => 
      (u.username && u.username.toLowerCase() === cleanUser) ||
      (u.email && u.email.toLowerCase() === cleanUser)
    );

    if (matchedUser && matchedUser.personalAccessCode && matchedUser.personalAccessCode === cleanPass) {
      return res.json({
        success: true,
        role: matchedUser.role,
        user: { ...matchedUser, loginMethod: 'DIRECT' },
        message: `¡Bienvenido ${matchedUser.name}! Acceso como ${matchedUser.role} concedido.`,
      });
    }

    return res.status(401).json({
      error: 'Usuario o contraseña incorrectos. Si cambiaste la clave recientemente, asegúrate de ingresar la nueva clave asignada.',
    });
  }

  // 2. Code / PIN based login
  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'Debes proporcionar un código de acceso o tus credenciales.' });
  }

  const cleanCode = code.trim();
  const { adminAccessCode, guardAccessCode, guestAccessCode } = db.securityConfig;
  const currentAdminCode = (adminAccessCode || '2004').trim();

  // 2a. Admin PIN (Validación estricta del PIN actual; si se cambió el PIN, el anterior queda eliminado)
  if (cleanCode.toUpperCase() === currentAdminCode.toUpperCase()) {
    const adminUser = db.users.find(u => u.username === 'eleiva' || u.role === 'ADMIN' || u.id === 'user-admin') || db.users[0];
    adminUser.role = 'ADMIN';
    adminUser.username = 'eleiva';
    adminUser.name = 'E. Leiva (Administrador Principal)';
    adminUser.personalAccessCode = currentAdminCode;
    adminUser.pinCode = currentAdminCode;
    return res.json({
      success: true,
      role: 'ADMIN',
      user: { ...adminUser, loginMethod: 'ACCESS_CODE' },
      message: 'Acceso de Administrador Principal E. Leiva concedido.',
    });
  }

  // 2b. Check registered users' personalAccessCode assigned by admin
  const userWithPersonalCode = db.users.find(u => u.personalAccessCode && u.personalAccessCode.trim() === cleanCode);
  if (userWithPersonalCode) {
    return res.json({
      success: true,
      role: userWithPersonalCode.role,
      user: { ...userWithPersonalCode, loginMethod: 'ACCESS_CODE' },
      message: `¡Bienvenido ${userWithPersonalCode.name}! Acceso con tu clave de usuario concedido.`,
    });
  }

  // 2c. Worker/Guard Unique PIN Recognition (VINCULACIÓN DIRECTA AL HISTORIAL DEL TRABAJADOR)
  const matchedEmployee = findEmployeeByPin(db.employees, cleanCode);
  if (matchedEmployee) {
    const comp = db.companies.find(c => c.id === matchedEmployee.companyId);
    const guardUser: AppUser = {
      id: `guard-${matchedEmployee.id}`,
      name: matchedEmployee.name,
      email: matchedEmployee.email || `${matchedEmployee.id}@guardiareal.gt`,
      role: 'GUARD',
      stationName: `${matchedEmployee.position} - ${comp?.name || 'Garita Central'}`,
      employeeId: matchedEmployee.id,
      pinCode: matchedEmployee.pinCode,
      permissions: {
        canViewCompanies: false, // Oculto para guardias por solicitud
        canViewEmployees: false, // Oculto para guardias por solicitud
        canViewSalaries: false,
        canViewAuditLog: false,
        canScanQR: true,
        canEditEmployees: false,
        canCreateEmployees: false,
        canDeleteEmployees: false,
        canManageCompanies: false,
        canExportExcel: false,
        canModifySalaries: false,
      },
      createdAt: matchedEmployee.createdAt,
      loginMethod: 'ACCESS_CODE',
    };
    return res.json({
      success: true,
      role: 'GUARD',
      user: guardUser,
      employee: matchedEmployee,
      message: `¡Trabajador guardia reconocido! Bienvenido ${matchedEmployee.name}. Tus marcajes se registrarán en tu historial laboral.`,
    });
  }

  // 2d. General Guard Access Code fallback
  if (guardAccessCode && cleanCode.toUpperCase() === guardAccessCode.toUpperCase()) {
    const guardUser = db.users.find(u => u.role === 'GUARD') || {
      id: 'user-guard-1',
      name: 'Pedro Macario (Guardia de Seguridad)',
      email: 'pedro.guardia@seguridadgt.com',
      role: 'GUARD',
      stationName: 'Puesto Principal - Fermac',
      permissions: {
        canViewCompanies: false,
        canViewEmployees: false,
        canViewSalaries: false,
        canViewAuditLog: false,
        canScanQR: true,
        canEditEmployees: false,
        canCreateEmployees: false,
        canDeleteEmployees: false,
        canManageCompanies: false,
        canExportExcel: false,
        canModifySalaries: false,
      },
      createdAt: '2026-02-10T07:00:00Z',
    };
    return res.json({
      success: true,
      role: 'GUARD',
      user: { ...guardUser, loginMethod: 'ACCESS_CODE' },
      message: 'Acceso de Guardia de Seguridad concedido (Terminal de Escaneo).',
    });
  }

  // 2e. Guest Access Code
  if (guestAccessCode && cleanCode.toUpperCase() === guestAccessCode.toUpperCase()) {
    const guestUser = db.users.find(u => u.role === 'GUEST') || db.users[1];
    return res.json({
      success: true,
      role: 'GUEST',
      user: { ...guestUser, loginMethod: 'ACCESS_CODE' },
      message: 'Acceso de Usuario Invitado concedido.',
    });
  }

  return res.status(401).json({
    error: 'Código de acceso o clave no encontrada. Si eres guardia, solicita tu PIN único al Administrador.',
  });
});

app.post('/api/auth/google-login', (req, res) => {
  const db = readDatabase();
  const { email, name, avatarUrl, pinCode } = req.body;

  if (!email) {
    return res.status(400).json({ error: 'Correo de Google es requerido.' });
  }

  const cleanEmail = email.trim().toLowerCase();

  // If email is eleiva or michbaquiaxgt@gmail.com and PIN is 2004 or admin code, grant ADMIN
  if (cleanEmail === 'michbaquiaxgt@gmail.com' || cleanEmail.includes('eleiva')) {
    const cleanPin = pinCode ? String(pinCode).trim() : '';
    if (cleanPin === '2004' || (db.securityConfig?.adminAccessCode && cleanPin.toUpperCase() === db.securityConfig.adminAccessCode.toUpperCase())) {
      let matchedUser = db.users.find(u => (u.email || '').toLowerCase() === cleanEmail) || db.users.find(u => u.role === 'ADMIN') || db.users[0];
      matchedUser.role = 'ADMIN';
      matchedUser.username = 'eleiva';
      matchedUser.personalAccessCode = '2004';
      matchedUser.name = 'E. Leiva (Administrador Principal)';
      matchedUser.avatarUrl = avatarUrl || matchedUser.avatarUrl;
      matchedUser.loginMethod = 'GOOGLE';
      writeDatabase(db);
      return res.json({ success: true, user: matchedUser, role: 'ADMIN', message: '¡Bienvenido Administrador Principal E. Leiva!' });
    }
  }

  // ACCESO BLOQUEADO SI NO SE TIENE PIN DE ACCESO PERSONAL
  if (!pinCode || !String(pinCode).trim()) {
    return res.status(401).json({
      error: 'Acceso bloqueado: Es estrictamente obligatorio ingresar tu PIN de acceso personal asignado por el Administrador General (eleiva) para ingresar al sistema.'
    });
  }

  const cleanPin = String(pinCode).trim();

  // 1. PIN Coincide con Administrador General (2004)
  if (cleanPin === '2004' || (db.securityConfig?.adminAccessCode && cleanPin.toUpperCase() === db.securityConfig.adminAccessCode.toUpperCase())) {
    let adminUser = db.users.find(u => u.role === 'ADMIN') || db.users[0];
    adminUser.email = cleanEmail;
    adminUser.avatarUrl = avatarUrl || adminUser.avatarUrl;
    adminUser.loginMethod = 'GOOGLE';
    writeDatabase(db);
    return res.json({
      success: true,
      user: adminUser,
      role: 'ADMIN',
      message: '¡Acceso concedido como Administrador Principal!',
    });
  }

  // 2. PIN Coincide con Trabajador Guardia en db.employees
  const matchedEmployee = findEmployeeByPin(db.employees, cleanPin);
  if (matchedEmployee) {
    const comp = db.companies.find(c => c.id === matchedEmployee.companyId);
    let guardUser = db.users.find(u => u.employeeId === matchedEmployee.id || (u.pinCode && u.pinCode.trim() === cleanPin));
    
    if (!guardUser) {
      guardUser = {
        id: `guard-${matchedEmployee.id}`,
        name: matchedEmployee.name,
        email: cleanEmail,
        avatarUrl,
        role: 'GUARD',
        stationName: `${matchedEmployee.position} - ${comp?.name || 'Garita Central'}`,
        employeeId: matchedEmployee.id,
        pinCode: matchedEmployee.pinCode,
        permissions: {
          canViewCompanies: false, // Oculto para guardias
          canViewEmployees: false, // Oculto para guardias
          canViewSalaries: false,
          canViewAuditLog: false,
          canScanQR: true,
          canEditEmployees: false,
          canCreateEmployees: false,
          canDeleteEmployees: false,
          canManageCompanies: false,
          canExportExcel: false,
          canModifySalaries: false,
        },
        createdAt: matchedEmployee.createdAt,
        loginMethod: 'GOOGLE',
      };
      db.users.push(guardUser);
    } else {
      guardUser.email = cleanEmail;
      guardUser.name = matchedEmployee.name;
      guardUser.avatarUrl = avatarUrl || guardUser.avatarUrl;
      guardUser.loginMethod = 'GOOGLE';
    }

    if (!matchedEmployee.email || matchedEmployee.email.includes('@guardiareal.gt')) {
      matchedEmployee.email = cleanEmail;
      matchedEmployee.updatedAt = new Date().toISOString();
    }

    writeDatabase(db);
    return res.json({
      success: true,
      user: guardUser,
      role: 'GUARD',
      employee: matchedEmployee,
      message: `¡Identidad validada! Sesión de guardia iniciada como ${matchedEmployee.name} (${guardUser.stationName}). Historial vinculado a tu expediente.`,
    });
  }

  // 3. PIN Coincide con usuario registrado en db.users (personalAccessCode o pinCode)
  let matchedUser = db.users.find(u => 
    (u.personalAccessCode && u.personalAccessCode.trim() === cleanPin) || 
    (u.pinCode && u.pinCode.trim() === cleanPin)
  );

  if (matchedUser) {
    matchedUser.email = cleanEmail;
    matchedUser.name = name ? name.trim() : matchedUser.name;
    matchedUser.avatarUrl = avatarUrl || matchedUser.avatarUrl;
    matchedUser.loginMethod = 'GOOGLE';

    const logEntry: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: matchedUser.id,
      userName: matchedUser.name,
      userRole: matchedUser.role,
      action: 'LOGIN',
      entityType: 'USUARIO_ACCESO',
      entityId: matchedUser.id,
      entityName: matchedUser.name,
      summary: `Inicio de sesión con Google y PIN verificado: ${matchedUser.name} (${matchedUser.role})`,
      changes: [{ field: 'loginMethod', label: 'Método', oldValue: null, newValue: 'Google + PIN' }],
      isCritical: false,
    };
    db.auditLogs.unshift(logEntry);

    writeDatabase(db);
    return res.json({
      success: true,
      user: matchedUser,
      role: matchedUser.role,
      message: `¡Bienvenido ${matchedUser.name}! Acceso verificado según tu PIN personal asignado (${matchedUser.role === 'ADMIN' ? 'Administrador' : (matchedUser.role === 'GUARD' ? 'Guardia' : 'Usuario Invitado')}).`
    });
  }

  // 4. PIN Coincide con código general de rol de guardia o invitado
  if (db.securityConfig?.guardAccessCode && cleanPin.toUpperCase() === db.securityConfig.guardAccessCode.toUpperCase()) {
    const newGuardUser: AppUser = {
      id: `user-guard-${Date.now()}`,
      name: name ? name.trim() : cleanEmail.split('@')[0],
      email: cleanEmail,
      role: 'GUARD',
      stationName: 'Garita de Acceso Principal',
      personalAccessCode: cleanPin,
      pinCode: cleanPin,
      avatarUrl,
      permissions: {
        canViewCompanies: false,
        canViewEmployees: false,
        canViewSalaries: false,
        canViewAuditLog: false,
        canScanQR: true,
        canEditEmployees: false,
        canCreateEmployees: false,
        canDeleteEmployees: false,
        canManageCompanies: false,
        canExportExcel: false,
        canModifySalaries: false,
      },
      createdAt: new Date().toISOString(),
      loginMethod: 'GOOGLE',
    };
    db.users.push(newGuardUser);
    writeDatabase(db);
    return res.json({
      success: true,
      user: newGuardUser,
      role: 'GUARD',
      message: `¡Acceso concedido como Guardia de Seguridad (${newGuardUser.name})!`
    });
  }

  if (db.securityConfig?.guestAccessCode && cleanPin.toUpperCase() === db.securityConfig.guestAccessCode.toUpperCase()) {
    const newGuestUser: AppUser = {
      id: `user-guest-${Date.now()}`,
      name: name ? name.trim() : cleanEmail.split('@')[0],
      email: cleanEmail,
      role: 'GUEST',
      personalAccessCode: cleanPin,
      avatarUrl,
      permissions: {
        canViewCompanies: true,
        canViewEmployees: true,
        canViewSalaries: false,
        canViewAuditLog: false,
        canScanQR: false,
        canEditEmployees: true,
        canCreateEmployees: false,
        canDeleteEmployees: false,
        canManageCompanies: false,
        canExportExcel: false,
        canModifySalaries: false,
      },
      createdAt: new Date().toISOString(),
      loginMethod: 'GOOGLE',
    };
    db.users.push(newGuestUser);
    writeDatabase(db);
    return res.json({
      success: true,
      user: newGuestUser,
      role: 'GUEST',
      message: `¡Acceso concedido como Usuario Invitado (${newGuestUser.name})!`
    });
  }

  // 5. SI EL PIN NO COINCIDE CON NINGÚN REGISTRO: DENEGAR ACCESO
  return res.status(401).json({
    error: 'PIN de acceso no reconocido o no autorizado. Debes ingresar el PIN personal válido proporcionado por el Administrador General (eleiva) para que el sistema asigne tu rol correspondiente.'
  });
});

// ==========================================
// REGISTRO Y VINCULACIÓN DE CUENTA DE GUARDIA (CON GOOGLE/DATOS + PIN OBLIGATORIO)
// ==========================================
app.post('/api/auth/register-guard-account', (req, res) => {
  const db = readDatabase();
  const { email, name, lastName, phone, pinCode } = req.body;

  if (!email || !name || !pinCode) {
    return res.status(400).json({ error: 'Correo, nombre y PIN brindado por el Administrador son obligatorios.' });
  }

  const cleanPin = String(pinCode).trim();
  const cleanEmail = String(email).trim().toLowerCase();
  const fullName = `${name.trim()} ${lastName ? lastName.trim() : ''}`.trim();

  // Buscar el guardia creado en el sistema por el administrador con dicho PIN
  const matchedEmployee = db.employees.find((e: Employee) => e.pinCode && e.pinCode.trim() === cleanPin);
  if (!matchedEmployee) {
    return res.status(401).json({
      error: 'El PIN ingresado no coincide con ningún guardia de seguridad creado en el sistema por el Administrador. Solicita al Administrador que dé de alta tu puesto de guardia primero.',
    });
  }

  const comp = db.companies.find((c: Company) => c.id === matchedEmployee.companyId);

  // Actualizar la ficha del trabajador oficial con los datos del guardia
  matchedEmployee.name = fullName || matchedEmployee.name;
  matchedEmployee.email = cleanEmail;
  if (phone) matchedEmployee.phone = String(phone).trim();
  matchedEmployee.updatedAt = new Date().toISOString();

  // Buscar o crear el usuario de la app para este guardia
  let guardUser = db.users.find((u: AppUser) => u.employeeId === matchedEmployee.id || (u.pinCode && u.pinCode.trim() === cleanPin));

  if (!guardUser) {
    guardUser = {
      id: `user-guard-${Date.now()}`,
      name: matchedEmployee.name,
      email: cleanEmail,
      phone: phone ? String(phone).trim() : matchedEmployee.phone,
      lastName: lastName ? lastName.trim() : undefined,
      role: 'GUARD',
      stationName: `${matchedEmployee.position} - ${comp?.name || 'Garita'}`,
      assignedStoreId: matchedEmployee.companyId,
      assignedStoreName: comp?.name,
      employeeId: matchedEmployee.id,
      pinCode: matchedEmployee.pinCode,
      personalAccessCode: matchedEmployee.pinCode,
      permissions: {
        canViewCompanies: false,
        canViewEmployees: false,
        canViewSalaries: false,
        canViewAuditLog: false,
        canScanQR: true,
        canEditEmployees: false,
        canCreateEmployees: false,
        canDeleteEmployees: false,
        canManageCompanies: false,
        canExportExcel: false,
        canModifySalaries: false,
      },
      createdAt: new Date().toISOString(),
      loginMethod: 'GOOGLE',
    };
    db.users.push(guardUser);
  } else {
    guardUser.name = matchedEmployee.name;
    guardUser.email = cleanEmail;
    if (phone) guardUser.phone = String(phone).trim();
    if (lastName) guardUser.lastName = lastName.trim();
    guardUser.loginMethod = 'GOOGLE';
  }

  // Notificar al administrador principal que el guardia vinculó su cuenta
  const notif: RealtimeNotification = {
    id: `notif-${Date.now()}`,
    timestamp: new Date().toISOString(),
    title: 'Nueva Cuenta de Guardia Enlazada',
    message: `${guardUser.name} enlazó exitosamente su cuenta al puesto de guardia ${matchedEmployee.position} (${comp?.name || 'Garita Central'}).`,
    type: 'guard',
    actorName: guardUser.name,
    read: false,
    linkTab: 'permissions',
  };
  db.notifications.unshift(notif);

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: guardUser.id,
    userName: guardUser.name,
    userRole: 'GUARD',
    action: 'MARCAJE_GUARDIA',
    entityType: 'USUARIO_PERMISOS',
    entityId: guardUser.id,
    entityName: guardUser.name,
    summary: `El guardia ${guardUser.name} creó su cuenta enlazándose a la tienda ${comp?.name || 'Garita'} usando el PIN provisto por el admin.`,
    changes: [{ field: 'status', label: 'Cuenta Enlazada', oldValue: null, newValue: 'Enlazado a Ficha Oficial' }],
    isCritical: false,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.json({
    success: true,
    user: guardUser,
    employee: matchedEmployee,
    message: `¡Cuenta creada exitosamente! Bienvenido ${guardUser.name}. Tu cuenta ha sido enlazada a tu puesto oficial de guardia en ${comp?.name || 'Garita Central'}.`,
  });
});

// ==========================================
// INICIO DE SESIÓN UNIFICADO (UN SOLO APARTADO)
// ==========================================
app.post('/api/auth/unified-login', (req, res) => {
  const db = readDatabase();
  const { account, passwordOrPin } = req.body;

  if (!account || !passwordOrPin) {
    return res.status(400).json({ error: 'Ingresa tu usuario o correo y tu contraseña o PIN.' });
  }

  const cleanAccount = String(account).trim().toLowerCase();
  const cleanPass = String(passwordOrPin).trim();

  // 1. Acceso de Administrador General (eleiva / michbaquiaxgt@gmail.com / admin)
  const currentAdminCode = (db.securityConfig?.adminAccessCode || '2004').trim();
  let adminUser = db.users.find((u: AppUser) => u.role === 'ADMIN' || u.id === 'user-admin' || u.username === 'eleiva') || db.users[0];
  const isAdminMatch = (cleanAccount === 'eleiva' || cleanAccount === 'michbaquiaxgt@gmail.com' || cleanAccount === 'admin') &&
    (cleanPass === currentAdminCode || cleanPass === (adminUser?.personalAccessCode?.trim() || currentAdminCode));

  if (isAdminMatch) {
    return res.json({
      success: true,
      user: adminUser,
      role: 'ADMIN',
      message: '¡Bienvenido Administrador Principal E. Leiva!',
    });
  }

  // 2. Buscar en usuarios registrados (por email, username o nombre + PIN/clave)
  const matchedUser = db.users.find((u: AppUser) => {
    const matchAcc = (u.email && u.email.toLowerCase() === cleanAccount) ||
                     (u.username && u.username.toLowerCase() === cleanAccount) ||
                     (u.name && u.name.toLowerCase() === cleanAccount);
    const matchPin = (u.personalAccessCode && u.personalAccessCode.trim() === cleanPass) ||
                     (u.pinCode && u.pinCode.trim() === cleanPass);
    return matchAcc && matchPin;
  });

  if (matchedUser) {
    return res.json({
      success: true,
      user: matchedUser,
      role: matchedUser.role,
      message: `¡Sesión iniciada con éxito! Bienvenido ${matchedUser.name}.`,
    });
  }

  // 3. Buscar en colaboradores guardias creados por admin si el PIN coincide
  const matchedEmployee = db.employees.find((e: Employee) => {
    const pinMatches = e.pinCode && e.pinCode.trim() === cleanPass;
    const accMatches = (e.email && e.email.toLowerCase() === cleanAccount) ||
                       (e.name && e.name.toLowerCase().includes(cleanAccount)) ||
                       cleanAccount === 'guardia' || cleanAccount.includes('guardia');
    return pinMatches && accMatches;
  });

  if (matchedEmployee) {
    const comp = db.companies.find((c: Company) => c.id === matchedEmployee.companyId);
    let guardUser = db.users.find((u: AppUser) => u.employeeId === matchedEmployee.id);
    if (!guardUser) {
      guardUser = {
        id: `guard-${matchedEmployee.id}`,
        name: matchedEmployee.name,
        email: matchedEmployee.email || `${matchedEmployee.id}@guardiareal.gt`,
        role: 'GUARD',
        stationName: `${matchedEmployee.position} - ${comp?.name || 'Garita Central'}`,
        employeeId: matchedEmployee.id,
        pinCode: matchedEmployee.pinCode,
        permissions: {
          canViewCompanies: false,
          canViewEmployees: false,
          canViewSalaries: false,
          canViewAuditLog: false,
          canScanQR: true,
          canEditEmployees: false,
          canCreateEmployees: false,
          canDeleteEmployees: false,
          canManageCompanies: false,
          canExportExcel: false,
          canModifySalaries: false,
        },
        createdAt: matchedEmployee.createdAt,
        loginMethod: 'DIRECT',
      };
      db.users.push(guardUser);
      writeDatabase(db);
    }

    return res.json({
      success: true,
      user: guardUser,
      role: 'GUARD',
      message: `¡Bienvenido Guardia ${matchedEmployee.name}!`,
    });
  }

  // 4. Credenciales incorrectas
  return res.status(401).json({
    error: 'Credenciales o PIN no reconocidos. Verifica tus datos o ingresa con el PIN brindado por el Administrador.',
  });
});

// ==========================================
// CREAR USUARIO INVITADO DIRECTO (SIN CREAR CUENTA)
// ==========================================
app.post('/api/users/create-guest', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);

  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede crear usuarios invitados.' });
  }

  const { name, pinCode, permissions } = req.body;
  if (!name || !pinCode) {
    return res.status(400).json({ error: 'Nombre de invitado y PIN (contraseña) son requeridos.' });
  }

  const cleanPin = String(pinCode).trim();
  const usernameClean = name.trim().toLowerCase().replace(/\s+/g, '.');

  const newGuest: AppUser = {
    id: `guest-${Date.now()}`,
    name: name.trim(),
    username: usernameClean,
    email: `${usernameClean}@invitado.gt`,
    role: 'GUEST',
    personalAccessCode: cleanPin,
    pinCode: cleanPin,
    permissions: permissions || {
      canViewCompanies: true,
      canViewEmployees: true,
      canViewSalaries: false,
      canViewAuditLog: false,
      canScanQR: false,
      canEditEmployees: true,
      canCreateEmployees: false,
      canDeleteEmployees: false,
      canManageCompanies: false,
      canExportExcel: false,
      canModifySalaries: false,
    },
    createdAt: new Date().toISOString(),
    loginMethod: 'DIRECT',
  };

  db.users.push(newGuest);

  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'CAMBIO_PERMISOS',
    entityType: 'USUARIO_PERMISOS',
    entityId: newGuest.id,
    entityName: newGuest.name,
    summary: `Usuario Invitado creado por el administrador: ${newGuest.name} con PIN de acceso directo.`,
    changes: [{ field: 'role', label: 'Rol', oldValue: null, newValue: 'GUEST' }],
    isCritical: true,
  };
  db.auditLogs.unshift(logEntry);

  writeDatabase(db);
  res.status(201).json(newGuest);
});

// Notifications
app.get('/api/notifications', (req, res) => {
  const db = readDatabase();
  res.json(db.notifications);
});

app.post('/api/notifications/mark-all-read', (req, res) => {
  const db = readDatabase();
  db.notifications.forEach((n: RealtimeNotification) => { n.read = true; });
  writeDatabase(db);
  res.json({ success: true });
});

// ==========================================
// BACKUP & DATA MAINTENANCE ENDPOINTS
// ==========================================
app.get('/api/export-backup', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede exportar el respaldo completo de la aplicación.' });
  }
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename=guardia_real_backup_${new Date().toISOString().slice(0, 10)}.json`);
  res.json(db);
});

app.post('/api/import-backup', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede importar un respaldo del sistema.' });
  }

  const { adminAccessCode, backupData } = req.body;
  if (!adminAccessCode || String(adminAccessCode).trim() !== String(db.securityConfig.adminAccessCode)) {
    return res.status(401).json({ error: 'PIN de Administrador incorrecto. Operación cancelada.' });
  }

  if (!backupData || typeof backupData !== 'object' || (!backupData.companies && !backupData.employees)) {
    return res.status(400).json({ error: 'El archivo de respaldo seleccionado no tiene un formato válido.' });
  }

  writeDatabase(backupData);

  const freshDb = readDatabase();
  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'IMPORTAR_DATOS',
    entityType: 'SISTEMA_IMPORT',
    entityId: 'backup-json',
    entityName: 'Restauración por Respaldo JSON',
    summary: `El administrador ${currentUser.name} importó un respaldo completo de la aplicación desde un archivo JSON.`,
    changes: [{ field: 'database', label: 'Estado del Sistema', oldValue: 'Datos Anteriores', newValue: 'Restaurado desde Respaldo' }],
    isCritical: true,
  };
  if (!freshDb.auditLogs) freshDb.auditLogs = [];
  freshDb.auditLogs.unshift(logEntry);
  writeDatabase(freshDb);

  res.json({ success: true, message: 'Respaldo importado y restaurado con éxito.' });
});


app.post('/api/reset-data', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Solo el administrador puede restablecer o borrar los datos almacenados.' });
  }

  const { adminAccessCode } = req.body;
  if (!adminAccessCode || String(adminAccessCode).trim() !== String(db.securityConfig.adminAccessCode)) {
    return res.status(401).json({ error: 'PIN de Administrador incorrecto. Operación cancelada.' });
  }

  // Reset database to initial defaultData state
  writeDatabase(defaultData);

  const freshDb = readDatabase();
  const logEntry: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    userId: currentUser.id,
    userName: currentUser.name,
    userRole: currentUser.role,
    action: 'ELIMINAR_DATOS',
    entityType: 'SISTEMA_RESET',
    entityId: 'all-data',
    entityName: 'Restauración de Fábrica',
    summary: `El administrador ${currentUser.name} ejecutó el borrado y restablecimiento total de los datos de la aplicación.`,
    changes: [{ field: 'database', label: 'Estado del Sistema', oldValue: 'Datos Previos', newValue: 'Restaurado a Fábrica (Default)' }],
    isCritical: true,
  };
  freshDb.auditLogs.unshift(logEntry);
  writeDatabase(freshDb);

  res.json({ success: true, message: 'Todos los datos de la aplicación han sido borrados y restablecidos con éxito.' });
});

// ==========================================
// UNIFORM INVENTORY MANAGEMENT ENDPOINTS (ADMIN ONLY FOR ADD/EDIT/DELETE)
// ==========================================
app.get('/api/security/inventory', (req, res) => {
  const db = readDatabase();
  res.json(db.securityConfig?.inventoryItems || []);
});

app.post('/api/security/inventory', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN' && currentUser.role !== 'GUEST') {
    return res.status(403).json({ error: 'No tienes autorización para agregar artículos al inventario.' });
  }

  const { name, stock, price, description, category } = req.body;
  if (!name || stock === undefined || price === undefined) {
    return res.status(400).json({ error: 'Nombre, stock y precio son obligatorios.' });
  }

  if (!db.securityConfig.inventoryItems) {
    db.securityConfig.inventoryItems = [];
  }

  const newItem = {
    id: `inv-${Date.now()}`,
    name: name.trim(),
    stock: Number(stock) || 0,
    price: Number(price) || 0,
    description: description ? description.trim() : '',
    category: category || 'Uniforme',
  };

  db.securityConfig.inventoryItems.push(newItem);

  // Sincronizar con uniformPrices si coincide
  const lower = newItem.name.toLowerCase();
  if (lower.includes('gorra')) db.securityConfig.uniformPrices.gorra = newItem.price;
  else if (lower.includes('pantalon') || lower.includes('pantalón')) db.securityConfig.uniformPrices.pantalon = newItem.price;
  else if (lower.includes('bota')) db.securityConfig.uniformPrices.botas = newItem.price;
  else if (lower.includes('camisa')) db.securityConfig.uniformPrices.camisaCafe = newItem.price;
  else if (lower.includes('polo') || lower.includes('playera')) db.securityConfig.uniformPrices.playeraPolo = newItem.price;

  writeDatabase(db);
  res.status(201).json({
    ...newItem,
    item: newItem,
    inventoryItems: db.securityConfig.inventoryItems,
    uniformPrices: db.securityConfig.uniformPrices,
    securityConfig: db.securityConfig,
  });
});

app.put('/api/security/inventory/bulk', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN' && currentUser.role !== 'GUEST') {
    return res.status(403).json({ error: 'No tienes autorización para modificar los precios e inventario.' });
  }

  const { items } = req.body;
  if (!Array.isArray(items)) {
    return res.status(400).json({ error: 'Se requiere una lista de artículos válida.' });
  }

  if (!db.securityConfig.inventoryItems) {
    db.securityConfig.inventoryItems = [];
  }

  for (const updatedItem of items) {
    const idx = db.securityConfig.inventoryItems.findIndex(i => i.id === updatedItem.id);
    if (idx !== -1) {
      db.securityConfig.inventoryItems[idx] = {
        ...db.securityConfig.inventoryItems[idx],
        name: updatedItem.name !== undefined ? updatedItem.name.trim() : db.securityConfig.inventoryItems[idx].name,
        stock: updatedItem.stock !== undefined ? Number(updatedItem.stock) : db.securityConfig.inventoryItems[idx].stock,
        price: updatedItem.price !== undefined ? Number(updatedItem.price) : db.securityConfig.inventoryItems[idx].price,
        description: updatedItem.description !== undefined ? updatedItem.description.trim() : db.securityConfig.inventoryItems[idx].description,
        category: updatedItem.category !== undefined ? updatedItem.category : db.securityConfig.inventoryItems[idx].category,
      };

      const lower = (db.securityConfig.inventoryItems[idx].name || '').toLowerCase();
      if (lower.includes('gorra')) db.securityConfig.uniformPrices.gorra = db.securityConfig.inventoryItems[idx].price;
      else if (lower.includes('pantalon') || lower.includes('pantalón')) db.securityConfig.uniformPrices.pantalon = db.securityConfig.inventoryItems[idx].price;
      else if (lower.includes('bota')) db.securityConfig.uniformPrices.botas = db.securityConfig.inventoryItems[idx].price;
      else if (lower.includes('camisa')) db.securityConfig.uniformPrices.camisaCafe = db.securityConfig.inventoryItems[idx].price;
      else if (lower.includes('polo') || lower.includes('playera')) db.securityConfig.uniformPrices.playeraPolo = db.securityConfig.inventoryItems[idx].price;
    }
  }

  writeDatabase(db);
  res.json({
    success: true,
    items: db.securityConfig.inventoryItems,
    inventoryItems: db.securityConfig.inventoryItems,
    uniformPrices: db.securityConfig.uniformPrices,
    securityConfig: db.securityConfig,
  });
});

app.put('/api/security/inventory/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN' && currentUser.role !== 'GUEST') {
    return res.status(403).json({ error: 'No tienes autorización para modificar el inventario.' });
  }

  if (!db.securityConfig.inventoryItems) {
    db.securityConfig.inventoryItems = [];
  }

  const idx = db.securityConfig.inventoryItems.findIndex(i => i.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Artículo de inventario no encontrado.' });
  }

  const { name, stock, price, description, category } = req.body;
  const item = db.securityConfig.inventoryItems[idx];
  db.securityConfig.inventoryItems[idx] = {
    ...item,
    name: name !== undefined ? name.trim() : item.name,
    stock: stock !== undefined ? Number(stock) : item.stock,
    price: price !== undefined ? Number(price) : item.price,
    description: description !== undefined ? description.trim() : item.description,
    category: category !== undefined ? category : item.category,
  };

  const lower = (db.securityConfig.inventoryItems[idx].name || '').toLowerCase();
  if (lower.includes('gorra')) db.securityConfig.uniformPrices.gorra = db.securityConfig.inventoryItems[idx].price;
  else if (lower.includes('pantalon') || lower.includes('pantalón')) db.securityConfig.uniformPrices.pantalon = db.securityConfig.inventoryItems[idx].price;
  else if (lower.includes('bota')) db.securityConfig.uniformPrices.botas = db.securityConfig.inventoryItems[idx].price;
  else if (lower.includes('camisa')) db.securityConfig.uniformPrices.camisaCafe = db.securityConfig.inventoryItems[idx].price;
  else if (lower.includes('polo') || lower.includes('playera')) db.securityConfig.uniformPrices.playeraPolo = db.securityConfig.inventoryItems[idx].price;

  writeDatabase(db);
  res.json({
    ...db.securityConfig.inventoryItems[idx],
    item: db.securityConfig.inventoryItems[idx],
    inventoryItems: db.securityConfig.inventoryItems,
    uniformPrices: db.securityConfig.uniformPrices,
    securityConfig: db.securityConfig,
  });
});

app.delete('/api/security/inventory/:id', (req, res) => {
  const db = readDatabase();
  const currentUser = getUserFromHeader(req, db);
  if (currentUser.role !== 'ADMIN' && currentUser.role !== 'GUEST') {
    return res.status(403).json({ error: 'No tienes autorización para eliminar artículos del inventario.' });
  }

  if (!db.securityConfig.inventoryItems) {
    db.securityConfig.inventoryItems = [];
  }

  const idx = db.securityConfig.inventoryItems.findIndex(i => i.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Artículo no encontrado.' });
  }

  const removed = db.securityConfig.inventoryItems.splice(idx, 1)[0];
  writeDatabase(db);
  res.json({
    success: true,
    removed,
    inventoryItems: db.securityConfig.inventoryItems,
    uniformPrices: db.securityConfig.uniformPrices,
    securityConfig: db.securityConfig,
  });
});

// Vite Middleware Integration
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static('dist'));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve('dist/index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running smoothly on http://0.0.0.0:${PORT}`);
  });
}

startServer();
