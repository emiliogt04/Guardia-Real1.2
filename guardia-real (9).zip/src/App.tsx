/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { MetricsOverview } from './components/MetricsOverview';
import { CompaniesView } from './components/CompaniesView';
import { EmployeesView } from './components/EmployeesView';
import { AuditAndReportsView } from './components/AuditAndReportsView';
import { PermissionsManagementView } from './components/PermissionsManagementView';
import { GuardAttendanceView } from './components/GuardAttendanceView';
import { SettingsView } from './components/SettingsView';
import { InventoryView } from './components/InventoryView';
import { PayrollCenter } from './components/PayrollCenter';
import { RealtimeToast } from './components/RealtimeToast';
import { ThemeSelectorModal } from './components/ThemeSelectorModal';
import { AuthModal } from './components/AuthModal';
import { 
  Company, 
  Employee, 
  AuditLog, 
  AppUser, 
  RealtimeNotification, 
  UserPermissions, 
  GuardCheckin,
  SystemSecurityConfig,
  AppThemeSettings,
  GuardPayment,
  PaymentReceipt
} from './types';
import { generateExcelReport } from './utils/excelExport';
import { AlertCircle, RefreshCw, Smartphone, ShieldCheck, Palette } from 'lucide-react';

export default function App() {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [users, setUsers] = useState<AppUser[]>([]);
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);
  const [notifications, setNotifications] = useState<RealtimeNotification[]>([]);
  const [guardCheckins, setGuardCheckins] = useState<GuardCheckin[]>([]);
  const [payments, setPayments] = useState<GuardPayment[]>([]);
  const [receipts, setReceipts] = useState<PaymentReceipt[]>([]);
  const [securityConfig, setSecurityConfig] = useState<SystemSecurityConfig | null>(null);
  
  const [activeTab, setActiveTab] = useState<'companies' | 'employees' | 'audit' | 'guard' | 'permissions' | 'settings' | 'inventory' | 'payroll'>('companies');
  const [selectedCompanyFilter, setSelectedCompanyFilter] = useState<string>('all');
  
  const [activeToast, setActiveToast] = useState<RealtimeNotification | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [apiError, setApiError] = useState<string | null>(null);

  // Modals state
  const [isThemeModalOpen, setIsThemeModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Theme state
  const [themeSettings, setThemeSettings] = useState<AppThemeSettings>(() => {
    try {
      const saved = localStorage.getItem('guardia_real_theme');
      return saved ? JSON.parse(saved) : { mode: 'liquid-glass-dark', crystalColor: 'cyan' };
    } catch {
      return { mode: 'liquid-glass-dark', crystalColor: 'cyan' };
    }
  });

  // Apply theme dynamically to document root
  useEffect(() => {
    try {
      localStorage.setItem('guardia_real_theme', JSON.stringify(themeSettings));
    } catch (e) {
      console.warn('Error saving theme:', e);
    }
    const root = document.documentElement;
    root.classList.remove('theme-glass-light', 'theme-glass-light-blue', 'theme-glass-dark');
    root.classList.add(themeSettings.mode);

    if (themeSettings.mode === 'liquid-glass-dark') {
      root.setAttribute('data-crystal', themeSettings.crystalColor);
    } else {
      root.removeAttribute('data-crystal');
    }
  }, [themeSettings]);

  // Screen size detection & orientation tracker (identifies mobile, tablet, desktop, portrait/landscape)
  const [screenSize, setScreenSize] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 1200,
    height: typeof window !== 'undefined' ? window.innerHeight : 800,
    device: 'desktop' as 'mobile' | 'tablet' | 'desktop',
    isPortrait: true,
  });

  useEffect(() => {
    const handleResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const device = w < 640 ? 'mobile' : (w < 1024 ? 'tablet' : 'desktop');
      const isPortrait = h >= w;
      setScreenSize({ width: w, height: h, device, isPortrait });
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  // Tab permission evaluation helper
  const isTabAllowed = useCallback((tab: string, user: AppUser | null): boolean => {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    if (tab === 'companies') return user.permissions?.canViewCompanies !== false;
    if (tab === 'employees') return user.permissions?.canViewEmployees !== false;
    if (tab === 'audit') return user.role !== 'GUARD' && !!user.permissions?.canViewAuditLog && user.permissions?.canViewSalaries !== false;
    if (tab === 'guard') return user.role === 'GUARD' || !!user.permissions?.canScanQR;
    if (tab === 'inventory') return user.role === 'GUEST' || user.role === 'GUARD'; 
    if (tab === 'permissions') return false; // Solo Administrador
    if (tab === 'settings') return true;
    return false;
  }, []);

  const getFirstAllowedTab = useCallback((user: AppUser | null): 'companies' | 'employees' | 'audit' | 'guard' | 'permissions' | 'settings' | 'inventory' => {
    if (!user) return 'companies';
    if (user.role === 'ADMIN') return 'companies';
    if (user.role === 'GUARD') return 'guard';
    if (user.permissions?.canViewCompanies !== false) return 'companies';
    if (user.permissions?.canViewEmployees !== false) return 'employees';
    if (user.permissions?.canScanQR) return 'guard';
    return 'employees';
  }, []);

  // Load initial data from secure API
  const fetchAllData = useCallback(async () => {
    try {
      setIsLoading(true);
      setApiError(null);
      const res = await fetch('/api/bootstrap');
      if (!res.ok) {
        throw new Error(`Error en servidor: ${res.statusText}`);
      }
      const data = await res.json();
      setCompanies(data.companies || []);
      setEmployees(data.employees || []);
      setAuditLogs(data.auditLogs || []);
      setUsers(data.users || []);
      setNotifications(data.notifications || []);
      setGuardCheckins(data.guardCheckins || []);
      setPayments(data.payments || []);
      setReceipts(data.receipts || []);
      setSecurityConfig(data.securityConfig || null);

      // Set initial user (restore only if active session exists in localStorage, otherwise all sessions closed)
      const savedUserId = typeof window !== 'undefined' ? localStorage.getItem('guardia_real_session_user_id') : null;
      if (savedUserId && data.users) {
        const found = data.users.find((u: AppUser) => u.id === savedUserId);
        setCurrentUser(found || null);
      } else {
        setCurrentUser(null);
      }
    } catch (err: any) {
      console.error('Error fetching bootstrap data:', err);
      setApiError('No se pudo conectar a la API segura. Asegúrate de que el servidor esté activo.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  // If currentUser permissions change or tab gets revoked, automatically switch to allowed tab
  useEffect(() => {
    if (currentUser && !isTabAllowed(activeTab, currentUser)) {
      setActiveTab(getFirstAllowedTab(currentUser));
    }
  }, [currentUser, activeTab, isTabAllowed, getFirstAllowedTab]);

  // Headers helper with user authentication simulation
  const getAuthHeaders = useCallback(() => {
    return {
      'Content-Type': 'application/json',
      'x-user-id': currentUser?.id || 'user-admin',
      'x-user-role': currentUser?.role || 'ADMIN',
    };
  }, [currentUser]);

  // ==========================================
  // COMPANY OPERATIONS
  // ==========================================
  const handleSaveCompany = async (companyData: Partial<Company>, isEdit: boolean) => {
    const url = isEdit ? `/api/companies/${companyData.id}` : '/api/companies';
    const method = isEdit ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: getAuthHeaders(),
      body: JSON.stringify(companyData),
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al guardar la empresa');
    }

    await fetchAllData();

    if (!isEdit) {
      setActiveToast({
        id: `toast-${Date.now()}`,
        timestamp: new Date().toISOString(),
        title: 'Empresa Registrada',
        message: `La empresa ${result.name} fue guardada exitosamente en el sistema.`,
        type: 'company',
        actorName: currentUser?.name || 'Administrador',
        read: false,
        linkTab: 'companies',
      });
    }
  };

  const handleDeleteCompany = async (companyId: string) => {
    const res = await fetch(`/api/companies/${companyId}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });

    const result = await res.json();
    if (!res.ok) {
      alert(result.error || 'Error al eliminar la empresa');
      return;
    }

    await fetchAllData();
  };

  // ==========================================
  // EMPLOYEE OPERATIONS
  // ==========================================
  const handleSaveEmployee = async (employeeData: Partial<Employee>, isEdit: boolean) => {
    const url = isEdit ? `/api/employees/${employeeData.id}` : '/api/employees';
    const method = isEdit ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: getAuthHeaders(),
      body: JSON.stringify(employeeData),
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al guardar el colaborador');
    }

    await fetchAllData();

    if (isEdit) {
      const prevEmp = employees.find(e => e.id === employeeData.id);
      const isSalaryChanged = prevEmp && prevEmp.monthlySalary !== employeeData.monthlySalary;
      const isBaja = employeeData.endDate && (!prevEmp || !prevEmp.endDate);

      if (isSalaryChanged || isBaja) {
        setActiveToast({
          id: `toast-${Date.now()}`,
          timestamp: new Date().toISOString(),
          title: isSalaryChanged ? 'Alerta: Salario Modificado' : 'Alerta: Baja de Colaborador',
          message: `${currentUser?.name} actualizó los datos clave de ${result.name}.`,
          type: isSalaryChanged ? 'salary' : 'status',
          actorName: currentUser?.name || 'Usuario',
          read: false,
          linkTab: 'audit',
        });
      }
    } else {
      setActiveToast({
        id: `toast-${Date.now()}`,
        timestamp: new Date().toISOString(),
        title: 'Nuevo Colaborador Registrado',
        message: `${result.name} fue dado de alta en la nómina.`,
        type: 'info',
        actorName: currentUser?.name || 'Usuario',
        read: false,
        linkTab: 'employees',
      });
    }
  };

  const handleDeleteEmployee = async (employeeId: string) => {
    const res = await fetch(`/api/employees/${employeeId}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });

    const result = await res.json();
    if (!res.ok) {
      alert(result.error || 'Error al eliminar el colaborador');
      return;
    }

    await fetchAllData();
  };

  const handleAddDiscount = async (employeeId: string, data: { 
    amount: number; 
    reason: string; 
    description?: string; 
    period?: '1RA_QUINCENA' | '2DA_QUINCENA' | 'MENSUAL';
    discountType?: 'ANTICIPO' | 'UNIFORME' | 'OTRO';
    installments?: number;
    installmentAmount?: number;
    date?: string;
    startYear?: number;
    startMonth?: number;
    startQuincena?: 1 | 2;
    uniformItems?: string[];
    uniformItemIds?: string[];
    uniformQuantities?: Record<string, number>;
    uniformItemDetails?: { id: string; name: string; quantity: number; unitPrice: number; subtotal: number }[];
  }) => {
    const res = await fetch(`/api/employees/${employeeId}/discounts`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al aplicar descuento');
    }
    await fetchAllData();
  };

  const handleUpdateDiscountStart = async (
    employeeId: string,
    discountId: string,
    data: { startYear: number; startMonth: number; startQuincena: 1 | 2; installments?: number }
  ) => {
    const res = await fetch(`/api/employees/${employeeId}/discounts/${discountId}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al editar el descuento');
    }
    await fetchAllData();
  };

  const handleDeleteDiscount = async (employeeId: string, discountId: string, reason?: string) => {
    const res = await fetch(`/api/employees/${employeeId}/discounts/${discountId}?reason=${encodeURIComponent(reason || '')}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
      body: JSON.stringify({ reason }),
    });
    const result = await res.json();
    if (!res.ok) {
      alert(result.error || 'Error al eliminar descuento');
      return;
    }
    await fetchAllData();
  };

  const handleDeleteUser = async (userId: string) => {
    const res = await fetch(`/api/users/${userId}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    const result = await res.json();
    if (!res.ok) {
      alert(result.error || 'Error al eliminar usuario');
      return;
    }
    await fetchAllData();
  };

  const handleRecordPayment = async (paymentData: any) => {
    const res = await fetch('/api/payments', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(paymentData),
    });
    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al registrar pago');
    }
    await fetchAllData();
    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Pago Registrado',
      message: `Se registró con éxito el pago quincenal para ${paymentData.employeeName || 'el trabajador'}.`,
      type: 'salary',
      actorName: currentUser?.name || 'Administrador',
      read: false,
      linkTab: 'employees',
    });
  };

  // ==========================================
  // GUARD CHECKIN OPERATIONS
  // ==========================================
  const handleRecordCheckin = async (checkinData: Partial<GuardCheckin>) => {
    const res = await fetch('/api/guard-checkins', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(checkinData),
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al registrar marcaje de guardia');
    }

    await fetchAllData();

    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: `Marcaje ${result.type} Registrado`,
      message: `${result.guardName} registró su ${result.type} en ${result.checkpointName}.`,
      type: 'guard',
      actorName: result.guardName,
      read: false,
      linkTab: 'guard',
    });
  };

  const handleBatchSyncOfflineCheckins = async (checkins: GuardCheckin[]) => {
    const res = await fetch('/api/guard-checkins/sync-batch', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ checkins }),
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al sincronizar marcajes offline');
    }

    await fetchAllData();

    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Marcajes Sincronizados',
      message: `Se subieron con éxito ${result.count} marcaje(s) capturados sin conexión.`,
      type: 'guard',
      actorName: currentUser?.name || 'Guardia',
      read: false,
      linkTab: 'guard',
    });
  };

  // ==========================================
  // SECURITY CONFIG & CHECKPOINTS OPERATIONS
  // ==========================================
  const handleUpdateSecurityConfig = async (configUpdate: Partial<SystemSecurityConfig>) => {
    const res = await fetch('/api/security-config', {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(configUpdate),
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al actualizar configuración de seguridad');
    }

    setSecurityConfig(result);
    await fetchAllData();

    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Ajustes de Seguridad Guardados',
      message: 'Los códigos de acceso o fondo de guardias fueron actualizados exitosamente.',
      type: 'security',
      actorName: currentUser?.name || 'Administrador',
      read: false,
      linkTab: 'permissions',
    });
  };

  const handleAddCheckpoint = async (data: { name: string; companyId?: string; googleMapsUrl: string; address: string }) => {
    const res = await fetch('/api/checkpoints', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al registrar tienda');
    }

    await fetchAllData();

    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Tienda QR Creada',
      message: `Se generó el punto de escaneo para ${result.name} con enlace a Google Maps.`,
      type: 'guard',
      actorName: currentUser?.name || 'Administrador',
      read: false,
      linkTab: 'guard',
    });
  };

  const handleDeleteReceipt = async (receiptId: string) => {
    const res = await fetch(`/api/receipts/${receiptId}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error || 'Error al eliminar recibo');
    }
    setReceipts(prev => prev.filter(r => r.id !== receiptId));
  };

  const handleAddCustomBank = async (bankName: string) => {
    const res = await fetch('/api/security/banks', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ bankName }),
    });
    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error || 'Error al agregar banco');
    }
    const data = await res.json();
    setSecurityConfig(prev => prev ? { ...prev, customBanks: data.customBanks } : prev);
  };

  const handleDeleteCheckpoint = async (checkpointId: string) => {
    const res = await fetch(`/api/checkpoints/${checkpointId}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });

    const result = await res.json();
    if (!res.ok) {
      alert(result.error || 'Error al eliminar tienda.');
      return;
    }

    await fetchAllData();
  };

  // ==========================================
  // PERMISSIONS & USER OPERATIONS
  // ==========================================
  const handleUpdatePermissions = async (userId: string, permissions: UserPermissions) => {
    const res = await fetch(`/api/users/${userId}/permissions`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ permissions }),
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al actualizar permisos');
    }

    await fetchAllData();

    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Permisos de Acceso Actualizados',
      message: `Se reconfiguraron los privilegios del usuario ${result.name}.`,
      type: 'permission',
      actorName: currentUser?.name || 'Administrador',
      read: false,
      linkTab: 'permissions',
    });
  };

  const handleCreateUser = async (userData: {
    name: string;
    email: string;
    role: 'ADMIN' | 'GUEST' | 'GUARD';
    permissions: UserPermissions;
    stationName?: string;
    companyId?: string;
    pinCode?: string;
  }) => {
    const res = await fetch('/api/users', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(userData),
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al crear usuario');
    }

    await fetchAllData();

    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Usuario & PIN Creados',
      message: `Se registró a ${result.name} (${result.role === 'GUARD' ? 'Guardia Asignado a Tienda' : 'Usuario Invitado'}) con su PIN personal.`,
      type: 'permission',
      actorName: currentUser?.name || 'Administrador',
      read: false,
      linkTab: 'permissions',
    });
  };

  const handleUpdateUserRoleAndCode = async (
    userId: string, 
    data: { role: 'ADMIN' | 'GUEST' | 'GUARD'; personalAccessCode?: string; username?: string; permissions?: UserPermissions }
  ) => {
    const res = await fetch(`/api/users/${userId}/role-and-code`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(result.error || 'Error al actualizar rol y clave del usuario');
    }

    await fetchAllData();

    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Clave & Rol Asignados',
      message: `Se asignó el rol ${result.role} y clave de acceso para ${result.name}.`,
      type: 'permission',
      actorName: currentUser?.name || 'Administrador',
      read: false,
      linkTab: 'permissions',
    });
  };

  const handleSwitchUser = (user: AppUser) => {
    setCurrentUser(user);
    try {
      localStorage.setItem('guardia_real_session_user_id', user.id);
    } catch (e) {
      console.warn('Error saving session:', e);
    }
    if (!isTabAllowed(activeTab, user)) {
      setActiveTab(getFirstAllowedTab(user));
    }
    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Sesión Activa',
      message: `Operando como: ${user.name} (${user.role === 'ADMIN' ? 'Administrador Principal' : (user.role === 'GUARD' ? 'Guardia QR' : 'Invitado')})`,
      type: 'info',
      actorName: user.name,
      read: false,
    });
  };

  const handleLoginSuccess = (user: AppUser) => {
    handleSwitchUser(user);
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    try {
      localStorage.removeItem('guardia_real_session_user_id');
    } catch (e) {
      console.warn('Error clearing session:', e);
    }
    setActiveToast({
      id: `toast-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Sesión Cerrada',
      message: 'Has cerrado sesión del sistema Guardia Real.',
      type: 'info',
      actorName: 'Sistema',
      read: false,
    });
  };

  const handleMarkNotificationsRead = async () => {
    try {
      await fetch('/api/notifications/mark-all-read', { method: 'POST' });
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (err) {
      console.error('Error marking notifications:', err);
    }
  };

  // Quick export Excel trigger
  const handleQuickExport = () => {
    if (!currentUser) return;
    const canExport = currentUser.role === 'ADMIN' || (currentUser.role !== 'GUARD' && currentUser.permissions.canExportExcel && currentUser.permissions.canViewSalaries !== false);
    if (!canExport) {
      alert('Tu rol de invitado no cuenta con autorización para descargar el reporte Excel.');
      return;
    }

    const now = new Date();
    generateExcelReport(employees, auditLogs, companies, {
      periodType: '1RA_QUINCENA',
      year: now.getFullYear(),
      month: now.getMonth() + 1,
      generatedBy: `${currentUser.name} (${currentUser.role})`,
    });
  };

  const canExport = !!currentUser && (currentUser.role === 'ADMIN' || (currentUser.role !== 'GUARD' && currentUser.permissions.canExportExcel && currentUser.permissions.canViewSalaries !== false));

  // User personal wallpaper handler (for Admin & Guests, blocked for Guards)
  const handleUpdatePersonalWallpaper = async (wallpaperUrl?: string) => {
    if (!currentUser || currentUser.role === 'GUARD') return;
    try {
      const res = await fetch('/api/users/personal-wallpaper', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ wallpaperUrl }),
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(prev => prev ? { ...prev, personalWallpaperUrl: data.personalWallpaperUrl } : null);
        setUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, personalWallpaperUrl: data.personalWallpaperUrl } : u));
      }
    } catch (e) {
      console.warn('Error updating personal wallpaper:', e);
    }
  };

  const activeWallpaper = currentUser?.role === 'GUARD'
    ? securityConfig?.guardWallpaperUrl
    : (themeSettings.customWallpaperUrl || currentUser?.personalWallpaperUrl);

  const effectiveWallpaper = activeWallpaper || 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1920&q=80';

  const backgroundStyle: React.CSSProperties = {
    backgroundImage: `url(${effectiveWallpaper})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed',
  };

  const isGuardMobileLandscape = currentUser?.role === 'GUARD' && (screenSize.device === 'mobile' || screenSize.width < 800) && !screenSize.isPortrait;

  if (isLoading && !currentUser) {
    return (
      <div className={`min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden ${themeSettings.mode}`}>
        <div className="liquid-glow top-1/4 left-1/3 w-96 h-96 bg-cyan-500/20"></div>
        <div className="w-12 h-12 border-3 border-cyan-500/20 border-t-cyan-400 rounded-full animate-spin mb-4 shadow-[0_0_20px_rgba(6,182,212,0.4)]" />
        <h2 className="text-base font-bold tracking-tight text-white">Cargando sistema Guardia Real...</h2>
        <p className="text-xs text-slate-400 mt-1">Conectando base de datos empresarial y configuración de acceso</p>
      </div>
    );
  }

  return (
    <div 
      className={`min-h-screen flex flex-col relative overflow-x-hidden selection:bg-cyan-500 selection:text-slate-950 ${themeSettings.mode}`}
      data-crystal={themeSettings.mode === 'liquid-glass-dark' ? themeSettings.crystalColor : undefined}
      style={backgroundStyle}
    >
      
      {/* CAPA DE CRISTAL TRANSPARENTE POR ENCIMA DEL TEMA Y FONDO SELECCIONADO */}
      <div className="fixed inset-0 pointer-events-none z-0 backdrop-blur-[1.5px] bg-black/25" />
      <div className="fixed inset-0 pointer-events-none z-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/[0.05] via-transparent to-black/35" />

      {/* MOBILE ORIENTATION ENFORCER FOR GUARDS (PORTRAIT/VERTICAL ONLY) */}
      {isGuardMobileLandscape && (
        <div className="fixed inset-0 z-50 bg-[#070a12]/95 backdrop-blur-2xl flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
          <div className="w-16 h-16 rounded-3xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/40 mb-4 animate-bounce">
            <Smartphone className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-black text-white uppercase tracking-wider mb-2">
            Orientación Vertical Requerida
          </h2>
          <p className="text-xs text-slate-300 max-w-xs leading-relaxed mb-4">
            Para la seguridad del escaneo de códigos QR y control de asistencia, la terminal de guardia solo funciona con el teléfono en posición vertical.
          </p>
          <span className="text-[11px] font-mono px-3 py-1 rounded-full bg-cyan-400/10 text-cyan-300 border border-cyan-400/30">
            Gira tu dispositivo verticalmente
          </span>
        </div>
      )}
      
      {/* Ambient Liquid Glow Orbs for Glass Reflection */}
      <div className="liquid-glow -top-32 -left-32 w-[550px] h-[550px] bg-cyan-600/15 pointer-events-none"></div>
      <div className="liquid-glow top-1/3 -right-32 w-[600px] h-[600px] bg-blue-600/10 pointer-events-none"></div>
      <div className="liquid-glow -bottom-32 left-1/4 w-[650px] h-[650px] bg-emerald-600/10 pointer-events-none"></div>

      {/* Navigation Header */}
      {currentUser && (
        <Navbar
          activeTab={activeTab}
          setActiveTab={(tab: string) => setActiveTab(tab as any)}
          currentUser={currentUser}
          users={users}
          onSwitchUser={handleSwitchUser}
          notifications={notifications}
          onMarkNotificationsRead={handleMarkNotificationsRead}
          onQuickExport={handleQuickExport}
          canExport={canExport}
          onOpenThemeModal={() => setIsThemeModalOpen(true)}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 relative z-10 flex flex-col">
        
        {/* Pantalla Obligatoria de Inicio de Sesión cuando no hay usuario activo */}
        {!currentUser && (
          <div className="flex-1 flex flex-col items-center justify-center py-6 sm:py-10 animate-in fade-in zoom-in-95 my-auto">
            <div className="text-center mb-6 max-w-md">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-xs font-bold mb-3 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                <ShieldCheck className="w-4 h-4 text-cyan-400" />
                <span>Acceso Seguro Requerido</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight uppercase">
                GUARDIA REAL
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Control de Asistencia QR Satelital & Nómina Empresarial GT
              </p>
            </div>

            <AuthModal
              isOpen={true}
              isEmbedded={true}
              onLoginSuccess={handleLoginSuccess}
              securityConfig={securityConfig}
              users={users}
            />

            <div className="mt-6 flex items-center justify-center">
              <button
                type="button"
                onClick={() => setIsThemeModalOpen(true)}
                className="px-4 py-2 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-300 flex items-center gap-2 transition-all shadow-md"
              >
                <Palette className="w-4 h-4 text-cyan-400" />
                <span>Personalizar Tema Visual / Fondo</span>
              </button>
            </div>
          </div>
        )}
        
        {/* Error Notification if any */}
        {apiError && (
          <div className="mb-6 p-4 liquid-glass-elevated border-rose-500/30 rounded-2xl text-xs text-rose-300 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{apiError}</span>
            </div>
            <button
              onClick={fetchAllData}
              className="flex items-center gap-1 font-semibold text-rose-300 hover:text-rose-100 underline"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Reintentar
            </button>
          </div>
        )}

        {/* Global KPI Metrics strip in liquid glass (Oculto para Guardias) */}
        {currentUser && currentUser.role !== 'GUARD' && (
          <MetricsOverview
            companies={companies}
            employees={employees}
            auditLogs={auditLogs}
            currentUser={currentUser}
            guardCheckins={guardCheckins}
          />
        )}

        {/* Tab 1: Companies View (24 empresas) */}
        {activeTab === 'companies' && currentUser && isTabAllowed('companies', currentUser) && (
          <CompaniesView
            companies={companies}
            employees={employees}
            currentUser={currentUser}
            onSaveCompany={handleSaveCompany}
            onDeleteCompany={handleDeleteCompany}
            onSelectCompanyForEmployees={(compId: string) => {
              setSelectedCompanyFilter(compId);
              setActiveTab('employees');
            }}
          />
        )}

        {/* Tab 2: Employees View */}
        {activeTab === 'employees' && currentUser && isTabAllowed('employees', currentUser) && (
          <EmployeesView
            employees={employees}
            companies={companies}
            auditLogs={auditLogs}
            currentUser={currentUser}
            selectedCompanyFilter={selectedCompanyFilter}
            setSelectedCompanyFilter={setSelectedCompanyFilter}
            onSaveEmployee={handleSaveEmployee}
            onDeleteEmployee={handleDeleteEmployee}
            onViewAudit={(empId?: string) => {
              setActiveTab('audit');
            }}
            guardCheckins={guardCheckins}
            onAddDiscount={handleAddDiscount}
            onDeleteDiscount={handleDeleteDiscount}
            onUpdateDiscountStart={handleUpdateDiscountStart}
            securityConfig={securityConfig}
            payments={payments}
            receipts={receipts}
            onRecordPayment={handleRecordPayment}
            onAddBank={handleAddCustomBank}
            onDeleteReceipt={handleDeleteReceipt}
          />
        )}

        {/* Tab 3: Payroll Quincenal Generator & Audit Log */}
        {activeTab === 'audit' && currentUser && isTabAllowed('audit', currentUser) && (
          <AuditAndReportsView
            auditLogs={auditLogs}
            employees={employees}
            companies={companies}
            users={users}
            currentUser={currentUser}
          />
        )}

        {/* Tab 4: Guard Attendance QR Scanner & Checkpoint Log */}
        {activeTab === 'guard' && currentUser && isTabAllowed('guard', currentUser) && (
          <GuardAttendanceView
            currentUser={currentUser}
            companies={companies}
            guardCheckins={guardCheckins}
            securityConfig={securityConfig}
            onRecordCheckin={handleRecordCheckin}
            onBatchSyncOfflineCheckins={handleBatchSyncOfflineCheckins}
            onUpdateSecurityConfig={handleUpdateSecurityConfig}
            onAddCheckpoint={handleAddCheckpoint}
            onDeleteCheckpoint={handleDeleteCheckpoint}
          />
        )}

        {/* Tab 5: RBAC & Permissions Control */}
        {activeTab === 'permissions' && currentUser && currentUser.role === 'ADMIN' && (
          <PermissionsManagementView
            users={users}
            currentUser={currentUser}
            securityConfig={securityConfig}
            onUpdatePermissions={handleUpdatePermissions}
            onCreateUser={handleCreateUser}
            onUpdateSecurityConfig={handleUpdateSecurityConfig}
            onUpdateUserRoleAndCode={handleUpdateUserRoleAndCode}
            onDeleteUser={handleDeleteUser}
          />
        )}

        {/* Tab 6: Configuraciones & Control de Permisos (Exclusivo Administrador) */}
        {activeTab === 'settings' && currentUser && currentUser.role === 'ADMIN' && (
          <SettingsView
            currentUser={currentUser}
            securityConfig={securityConfig}
            onUpdateSecurityConfig={handleUpdateSecurityConfig}
            users={users}
            onUpdatePermissions={handleUpdatePermissions}
            onUpdateUserRoleAndCode={handleUpdateUserRoleAndCode}
            onCreateUser={handleCreateUser}
            onDeleteUser={handleDeleteUser}
          />
        )}

        {/* Tab 7: Inventario y Stock */}
        {activeTab === 'inventory' && currentUser && isTabAllowed('inventory', currentUser) && (
          <InventoryView
            currentUser={currentUser}
            securityConfig={securityConfig}
            onUpdateSecurityConfig={handleUpdateSecurityConfig}
          />
        )}

        {activeTab === 'payroll' && currentUser && currentUser.role === 'ADMIN' && (
          <PayrollCenter
            employees={employees}
            companies={companies}
            securityConfig={securityConfig}
            getAuthHeaders={getAuthHeaders}
            onSavePayroll={async (data) => {
              const res = await fetch('/api/payroll/save', {
                method: 'POST',
                headers: getAuthHeaders(),
                body: JSON.stringify(data),
              });
              if (!res.ok) {
                const err = await res.json().catch(() => ({}));
                throw new Error(err.error || 'Error al guardar planilla');
              }
              await fetchAllData();
            }}
          />
        )}

      </main>

      {/* Real-time Floating Toast Alert */}
      <RealtimeToast
        notification={activeToast}
        onClose={() => setActiveToast(null)}
        onClickNotification={(tab: string) => setActiveTab(tab as any)}
      />

      {/* Theme Selector Modal (Liquid Glass Claro, Claro Azul, Oscuro con Cristal) */}
      <ThemeSelectorModal
        isOpen={isThemeModalOpen}
        onClose={() => setIsThemeModalOpen(false)}
        currentUser={currentUser}
        themeSettings={themeSettings}
        onSelectTheme={setThemeSettings}
        onUpdatePersonalWallpaper={handleUpdatePersonalWallpaper}
      />

      {/* Auth Modal (Inicio de sesión con Google & Código de Acceso PIN) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        securityConfig={securityConfig}
        users={users}
      />

      {/* Footer in Liquid Glass */}
      <footer className="border-t border-white/10 bg-[#090d16]/80 backdrop-blur-xl py-5 mt-16 text-center text-xs text-slate-400 relative z-10">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-white">Guardia Real 1.1</span>
            <span className="text-slate-500">·</span>
            <span className="text-cyan-400">Control de Asistencia QR Satelital & Nómina GT</span>
          </div>
          <span className="text-slate-400">
            Compatible con Android y iPhone · Soporte Online & Offline (Con o sin WiFi)
          </span>
        </div>
      </footer>

    </div>
  );
}
