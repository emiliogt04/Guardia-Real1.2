export type Role = 'ADMIN' | 'GUEST' | 'GUARD';

export interface UserPermissions {
  // Permisos de visualización de pestañas y confidencialidad
  canViewCompanies: boolean;      // Pestaña Empresas
  canViewEmployees: boolean;      // Pestaña Trabajadores
  canViewSalaries: boolean;       // Ver salarios, quincenas y descuentos (CRÍTICO: false para Guardias)
  canViewAuditLog: boolean;       // Pestaña Planilla & Auditoría
  canScanQR: boolean;             // Pestaña Guardias & QR

  // Permisos de gestión y edición
  canEditEmployees: boolean;      // Editar colaboradores (por defecto true para invitados)
  canCreateEmployees: boolean;    // Permiso para dar de alta nuevos
  canDeleteEmployees: boolean;    // Permiso para eliminar
  canModifySalaries: boolean;     // Modificar salarios mensuales
  canManageCompanies: boolean;    // Crear / Editar empresas
  canExportExcel: boolean;        // Descargar reportes Excel
}

export interface AppUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  avatarUrl?: string;
  permissions: UserPermissions;
  createdAt: string;
  stationName?: string;          // Para guardias: puesto asignado / garita
  assignedStoreId?: string;      // Tienda oficial asignada
  assignedStoreName?: string;    // Nombre de la tienda oficial del guardia
  personalWallpaperUrl?: string; // Fondo de pantalla personal (todos excepto guardias)
  loginMethod?: 'GOOGLE' | 'ACCESS_CODE' | 'DIRECT';
  username?: string;            // Nombre de usuario para login directo (ej. eleiva)
  personalAccessCode?: string;  // Clave de acceso individual editable por admin
  employeeId?: string;          // ID del colaborador registrado
  pinCode?: string;             // Código PIN único de 4-6 dígitos del colaborador
  phone?: string;               // Teléfono registrado del usuario
  lastName?: string;            // Apellido
  companyId?: string;           // Empresa asignada
  companyName?: string;         // Nombre de la empresa asignada
}

export interface Company {
  id: string;
  name: string;
  nit: string;               // Identificador fiscal / tributario
  industry: string;          // Giro comercial / rubro
  address: string;
  phone: string;
  email?: string;
  employeeCount?: number;
  totalPayroll?: number;
  createdAt: string;
  updatedAt: string;
}

export type EmployeeStatus = 'ACTIVO' | 'DE_BAJA';

export interface GuardDiscount {
  id: string;
  amount: number;       // Cantidad a descontar en Quetzales (Q)
  reason: string;       // Motivo del descuento (ej. Falta, uniforme, sanción, daño, anticipo)
  description?: string; // Descripción detallada del descuento
  period?: '1RA_QUINCENA' | '2DA_QUINCENA' | 'MENSUAL'; // Período al que afecta
  date: string;         // Fecha en que se aplicó (YYYY-MM-DD)
  appliedBy: string;    // Nombre de quien aplicó el descuento (Admin)
  discountType?: 'ANTICIPO' | 'UNIFORME' | 'OTRO'; // Tipo de descuento
  installments?: number; // Fraccionamiento en quincenas (hasta 7)
  installmentAmount?: number; // Monto por quincena
  uniformItems?: string[]; // Ej. ['Gorra (Q. 60)', 'Botas (Q. 250)']
  uniformItemIds?: string[];
  uniformQuantities?: Record<string, number>;
  uniformItemDetails?: { id: string; name: string; quantity: number; unitPrice: number; subtotal: number }[];
  status?: 'PENDIENTE' | 'CANCELADO' | 'ACTIVO' | 'FINALIZADO' | 'ELIMINADO'; // Estado del descuento (activo, finalizado, cancelado, eliminado)
  startYear?: number;          // Quincena de inicio: año
  startMonth?: number;         // Quincena de inicio: mes (1-12)
  startQuincena?: 1 | 2;       // Quincena de inicio: 1 = primera, 2 = segunda
  paidPeriods?: string[];      // Quincenas guardadas en planilla donde ya se cobró (clave "AAAA-MM-Q1|Q2")
  installmentsPaid?: number;   // Cuotas cobradas (= cantidad de quincenas guardadas en paidPeriods)
  finalizedAt?: string;        // Fecha en que se cobró la última cuota
  deletedAt?: string;
  deletedBy?: string;
  deletionReason?: string;
}

export const GUATEMALA_BANKS = [
  'Banco de Desarrollo Rural, S. A. (Banrural)',
  'Banco G&T Continental, S. A.',
  'Banco Agromercantil de Guatemala, S. A. (BAM)',
  'Banco de América Central, S. A. (BAC Credomatic)',
  'Banco Promerica, S. A.',
  'Banco de los Trabajadores (Bantrab)',
  'El Crédito Hipotecario Nacional de Guatemala (CHN)',
  'Banco Ficohsa Guatemala, S. A.',
  'Banco Internacional, S. A.',
  'Banco Cuscatlán Guatemala, S. A.',
  'Banco Azteca de Guatemala, S. A.',
  'Banco de Antigua, S. A.',
  'Vivibanco, S. A.',
  'Citibank, N.A., Sucursal Guatemala',
  'Banco Inmobiliario, S. A.',
  'Banco INV, S. A.',
  'Banco Credicorp, S. A.',
  'Banco Nexa, S. A.',
  'Banco Multimoney, S. A.',
  'En efectivo',
] as const;

export type GuatemalaBankName = typeof GUATEMALA_BANKS[number] | string;

export interface GuardPayment {
  id: string;
  employeeId: string;
  employeeName: string;
  period: '1RA_QUINCENA' | '2DA_QUINCENA' | 'MENSUAL' | 'MES_COMPLETO' | 'DIA_ESPECIFICO';
  specificDate?: string; // YYYY-MM-DD si es pago de un día en específico
  year: number;
  month: number;
  calculatedAmount: number;
  paidAmount: number;
  paymentMethod: 'TRANSFERENCIA' | 'CHEQUE' | 'EFECTIVO';
  bankName: string;
  referenceNumber?: string;
  status: 'PAGADO' | 'PENDIENTE';
  paymentDate: string;
  notes?: string;
  notifiedGuard: boolean;
}

export interface PaymentReceipt {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeDpi?: string;
  amount: number;
  amountInWords: string; // Ej. "CINCUENTA CON 00/100"
  concept: string;       // Ej. "HORAS EXTRAS LICORERA" o "PAGO 1RA QUINCENA OCTUBRE 2026"
  period?: string;
  day: number;
  month: number;
  year: number;
  paymentMethod: 'TRANSFERENCIA' | 'CHEQUE' | 'EFECTIVO';
  referenceNumber?: string;
  observations?: string;
  issuedBy: string;
  createdAt: string;
}

export interface Employee {
  id: string;
  companyId: string;
  name: string;
  dpi: string;               // Documento Personal de Identificación (Guatemala 13 dígitos)
  position: string;          // Puesto / Cargo (Guardia de Seguridad)
  monthlySalary: number;     // Salario mensual (GTQ - Q)
  appliesIGSS: boolean;      // ¿Se le calcula retención IGSS laboral 4.83%?
  startDate: string;         // YYYY-MM-DD
  endDate: string | null;    // YYYY-MM-DD si fue dado de baja
  status: EmployeeStatus;
  phone?: string;
  email?: string;
  pinCode?: string;          // Código PIN único de acceso (editable solo por Administrador)
  discounts?: GuardDiscount[]; // Descuentos aplicados al guardia con motivo
  discountHistory?: GuardDiscount[]; // Historial completo de descuentos incluyendo los eliminados/anulados
  bankName?: string;         // Banco para el pago
  paymentMethodPreference?: 'TRANSFERENCIA' | 'CHEQUE' | 'EFECTIVO';
  bankAccountNumber?: string; // Número de cuenta o cheque
  createdAt: string;
  updatedAt: string;
  lastModifiedBy: string;    // Nombre del usuario que realizó el último cambio
  lastModifiedById?: string;
  documents?: {
    personalInfo?: string; // URL or base64
    resignationForm?: string;
    fingerprints?: string;
    contract?: string;
    others?: { name: string; url: string }[];
  };
}

export interface AuditChangeItem {
  field: string;
  label: string;
  oldValue: any;
  newValue: any;
}

export interface AuditLog {
  id: string;
  timestamp: string;         // ISO string
  userId: string;
  userName: string;
  userRole: Role;
  action: 
    | 'CREAR_EMPRESA'
    | 'EDITAR_EMPRESA'
    | 'ELIMINAR_EMPRESA'
    | 'CREAR_EMPLEADO'
    | 'EDITAR_EMPLEADO'
    | 'BAJA_EMPLEADO'
    | 'REACTIVAR_EMPLEADO'
    | 'ELIMINAR_EMPLEADO'
    | 'CAMBIO_PERMISOS'
    | 'MARCAJE_GUARDIA'
    | 'CAMBIO_CODIGOS_SEGURIDAD'
    | 'CAMBIO_FONDO_GUARDIAS'
    | 'CREAR_TIENDA_CHECKPOINT'
    | 'ACTUALIZAR_SUELDO_GUARDIAS'
    | 'ACTUALIZAR_IGSS_GLOBAL'
    | 'LOGIN'
    | 'ELIMINAR_DATOS'
    | 'IMPORTAR_DATOS';
  entityType: 'EMPRESA' | 'EMPLEADO' | 'USUARIO_PERMISOS' | 'MARCAJE_GUARDIA' | 'SEGURIDAD' | 'TIENDA_CHECKPOINT' | 'USUARIO_ACCESO' | 'SISTEMA_RESET' | 'SISTEMA_IMPORT';
  entityId: string;
  entityName: string;
  companyId?: string;
  companyName?: string;
  summary: string;
  changes: AuditChangeItem[];
  isCritical: boolean;
}

export interface GuardLocation {
  latitude: number | null;
  longitude: number | null;
  accuracy: number | null;
  addressText: string;
}

export interface StoreCheckpoint {
  id: string;
  name: string;              // Nombre de la tienda / garita
  companyId?: string;
  companyName?: string;
  googleMapsUrl: string;     // Enlace de Google Maps configurado por el admin
  address: string;
  code: string;              // Código QR identificador (ej. QR-TIENDA-FERMAC-01)
  createdAt: string;
}

export interface GuardCheckin {
  id: string;
  guardId: string;
  guardName: string;
  employeeId?: string;       // ID oficial del trabajador/colaborador
  guardPinCode?: string;     // PIN utilizado por el guardia
  type: 'ENTRADA' | 'SALIDA' | 'REPORTE_UBICACION';
  timestamp: string;         // ISO string de marcaje
  checkpointCode: string;    // Contenido del QR escaneado
  checkpointName: string;    // Nombre de la tienda / puesto
  companyId?: string;
  companyName?: string;
  googleMapsUrl?: string;    // Enlace de Google Maps de la tienda
  location: GuardLocation;
  notes?: string;
  delayReason?: string;      // Comentario de retraso / justificación del guardia
  isOfflineSynced?: boolean; // Verdadero si fue registrado sin wifi y subido después
}

export interface GuardShiftRecord {
  id: string;
  guardId: string;
  guardName: string;
  employeeId?: string;       // ID oficial del colaborador
  guardPinCode?: string;     // PIN único
  dateStr: string;           // YYYY-MM-DD
  entrada?: GuardCheckin;
  salida?: GuardCheckin;
  hoursWorkedFormatted?: string;
  storeName: string;
  googleMapsUrl?: string;
  status: 'COMPLETO' | 'EN_TURNO' | 'SOLO_SALIDA';
  delayReason?: string;
  isOfflineSynced?: boolean;
}

export interface UniformInventoryItem {
  id: string;
  name: string;
  stock: number;
  price: number;
  description?: string;
  category?: string;
}

export interface UniformPrices {
  gorra: number;
  pantalon: number;
  botas: number;
  camisaCafe: number;
  playeraPolo: number;
}

export interface SystemSecurityConfig {
  adminAccessCode: string;   // Código editable para Administrador
  guardAccessCode: string;   // Código editable para Guardia
  guestAccessCode: string;   // Código editable para Invitado
  guardWallpaperUrl: string; // Fondo de pantalla general exclusivo para los guardias
  guardBaseSalary: number;   // Sueldo asignado por el admin para todos los guardias en general (ej. Q4,200)
  igssPercentage: number;    // Porcentaje de retención laboral de IGSS (ej. 4.83%)
  checkpoints: StoreCheckpoint[]; // Tiendas configuradas con enlaces de Google Maps
  uniformPrices: UniformPrices; // Precios de accesorios de uniforme
  customBanks?: string[];    // Bancos personalizados agregados por el administrador
  inventoryItems?: UniformInventoryItem[]; // Inventario de accesorios de uniforme
}

export interface RealtimeNotification {
  id: string;
  timestamp: string;
  title: string;
  message: string;
  type: 'salary' | 'status' | 'permission' | 'company' | 'guard' | 'security' | 'info';
  actorName: string;
  read: boolean;
  linkTab?: string;
}

export interface DateRangeFilter {
  startDate: string;
  endDate: string;
  companyId: string;
  userId: string;
  actionType: string;
}

// Temas Liquid Glass (Liquid Glass Claro, Liquid Glass Claro Cristal Azul, o Liquid Glass Oscuro con Color de Cristal)
export type AppThemeMode = 'liquid-glass-light' | 'liquid-glass-light-blue' | 'liquid-glass-dark';
export type CrystalColor = 'cyan' | 'blue' | 'emerald' | 'purple' | 'amber' | 'rose';

export interface AppThemeSettings {
  mode: AppThemeMode;
  crystalColor: CrystalColor;
  customWallpaperUrl?: string; // Fondo personalizado para Administradores e Invitados
}
