import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  QrCode, 
  Camera, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  ShieldCheck, 
  Building2, 
  ExternalLink, 
  AlertTriangle,
  Sparkles,
  Smartphone,
  Plus,
  Wifi,
  WifiOff,
  RefreshCw,
  Image as ImageIcon,
  Check,
  Layers,
  Trash2,
  DollarSign,
  Percent,
  RotateCcw,
  Store,
  Upload,
  Navigation,
  LocateFixed,
  Send,
  Compass
} from 'lucide-react';
import QRCode from 'qrcode';
import jsQR from 'jsqr';
import { AppUser, Company, GuardCheckin, StoreCheckpoint, SystemSecurityConfig } from '../types';
import { formatDateTime, formatDate, formatCurrencyGTQ } from '../utils/formatters';

interface GuardAttendanceViewProps {
  currentUser: AppUser;
  companies: Company[];
  guardCheckins: GuardCheckin[];
  securityConfig: SystemSecurityConfig | null;
  onRecordCheckin: (checkinData: Partial<GuardCheckin>) => Promise<void>;
  onBatchSyncOfflineCheckins: (checkins: GuardCheckin[]) => Promise<void>;
  onUpdateSecurityConfig: (updated: Partial<SystemSecurityConfig> & { applySalaryToAllGuards?: boolean }) => Promise<void>;
  onAddCheckpoint: (data: { name: string; companyId?: string; googleMapsUrl: string; address: string }) => Promise<void>;
  onDeleteCheckpoint: (checkpointId: string) => Promise<void>;
}

export const GuardAttendanceView: React.FC<GuardAttendanceViewProps> = ({
  currentUser,
  companies,
  guardCheckins,
  securityConfig,
  onRecordCheckin,
  onBatchSyncOfflineCheckins,
  onUpdateSecurityConfig,
  onAddCheckpoint,
  onDeleteCheckpoint,
}) => {
  const isGuard = currentUser.role === 'GUARD' || currentUser.role !== 'ADMIN';
  const isAdmin = currentUser.role === 'ADMIN';

  // Admin sub-navigation tabs
  const [adminTab, setAdminTab] = useState<'SHIFTS' | 'SALARY_IGSS' | 'QR_MANAGER' | 'CHECKINS' | 'WALLPAPER'>('SHIFTS');

  // Guard Scanning, Shift & Location Report State
  const [checkinType, setCheckinType] = useState<'ENTRADA' | 'SALIDA' | 'REPORTE_UBICACION'>('ENTRADA');
  const [delayReason, setDelayReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastCheckinResult, setLastCheckinResult] = useState<GuardCheckin | null>(null);

  // Mobile Orientation check for Guards (Only allow Portrait on mobile devices)
  const [isMobileLandscape, setIsMobileLandscape] = useState(false);

  useEffect(() => {
    const checkOrientation = () => {
      const isMobile = window.innerWidth <= 900 || /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      const isLandscape = window.innerWidth > window.innerHeight;
      setIsMobileLandscape(isMobile && isLandscape);
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);

    // Attempt to lock portrait on Android if supported
    if (isGuard && 'screen' in window && (screen as any).orientation?.lock) {
      (screen as any).orientation.lock('portrait').catch(() => {});
    }

    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, [isGuard]);

  // Network & Offline Queue State
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [offlineQueue, setOfflineQueue] = useState<GuardCheckin[]>(() => {
    try {
      const saved = localStorage.getItem('guard_offline_checkins_queue');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  // GPS State
  const [gpsLocation, setGpsLocation] = useState<{
    latitude: number | null;
    longitude: number | null;
    accuracy: number | null;
    addressText: string;
    loading: boolean;
  }>({
    latitude: null,
    longitude: null,
    accuracy: null,
    addressText: 'Detectando ubicación satelital...',
    loading: true,
  });

  // Admin QR Generator & Store Checkpoint State
  const checkpointsList = securityConfig?.checkpoints || [];
  const [selectedCheckpointId, setSelectedCheckpointId] = useState<string>(
    checkpointsList[0]?.id || ''
  );
  const [generatedQRUrl, setGeneratedQRUrl] = useState<string>('');

  // New Checkpoint Modal State for Admin
  const [isNewStoreModalOpen, setIsNewStoreModalOpen] = useState(false);
  const [newStoreData, setNewStoreData] = useState({
    name: '',
    companyId: companies[0]?.id || '',
    googleMapsUrl: '',
    address: '',
  });

  // Admin Salary & IGSS State
  const [adminGuardSalary, setAdminGuardSalary] = useState<number>(securityConfig?.guardBaseSalary || 4200);
  const [adminIgssPercentage, setAdminIgssPercentage] = useState<number>(securityConfig?.igssPercentage || 4.83);
  const [applySalaryToEmployees, setApplySalaryToEmployees] = useState(true);
  const [salarySaveSuccess, setSalarySaveSuccess] = useState(false);

  // Wallpaper Setting State for Admin
  const [wallpaperUrlInput, setWallpaperUrlInput] = useState<string>(
    securityConfig?.guardWallpaperUrl || ''
  );
  const [wallpaperSuccess, setWallpaperSuccess] = useState<boolean>(false);
  const wallpaperFileInputRef = useRef<HTMLInputElement | null>(null);

  const handleWallpaperGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Por favor selecciona una imagen válida desde tu galería (JPG, PNG, WEBP).');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      alert('La imagen seleccionada supera los 15MB. Elige una imagen más liviana.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setWallpaperUrlInput(result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Real-time digital clock for guards
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Sync state if securityConfig changes
  useEffect(() => {
    if (securityConfig) {
      if (securityConfig.guardWallpaperUrl) {
        setWallpaperUrlInput(securityConfig.guardWallpaperUrl);
      }
      if (securityConfig.guardBaseSalary) {
        setAdminGuardSalary(securityConfig.guardBaseSalary);
      }
      if (securityConfig.igssPercentage) {
        setAdminIgssPercentage(securityConfig.igssPercentage);
      }
      if (securityConfig.checkpoints?.length && !selectedCheckpointId) {
        setSelectedCheckpointId(securityConfig.checkpoints[0].id);
      }
    }
  }, [securityConfig, selectedCheckpointId]);

  // Online / Offline listener
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      triggerAutoSync();
    };
    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Periodic check every 15s to auto-upload any queued records
    const interval = setInterval(() => {
      if (navigator.onLine && offlineQueue.length > 0) {
        triggerAutoSync();
      }
    }, 15000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [offlineQueue]);

  // Save offline queue to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('guard_offline_checkins_queue', JSON.stringify(offlineQueue));
    } catch (e) {
      console.warn('Error saving offline queue:', e);
    }
  }, [offlineQueue]);

  // GPS detection helper
  const refreshGpsLocation = () => {
    if (navigator.geolocation) {
      setGpsLocation(prev => ({ ...prev, loading: true }));
      navigator.geolocation.getCurrentPosition(
        pos => {
          setGpsLocation({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: Math.round(pos.coords.accuracy),
            addressText: `GPS: ${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)} (±${Math.round(pos.coords.accuracy)}m)`,
            loading: false,
          });
        },
        err => {
          console.warn('Geolocation warning:', err.message);
          setGpsLocation({
            latitude: 14.8348,
            longitude: -91.5181,
            accuracy: 15,
            addressText: 'Zona 1, Quetzaltenango (Puesto Verificado)',
            loading: false,
          });
        },
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
      );
    } else {
      setGpsLocation({
        latitude: 14.8348,
        longitude: -91.5181,
        accuracy: null,
        addressText: 'Zona 1, Quetzaltenango',
        loading: false,
      });
    }
  };

  useEffect(() => {
    refreshGpsLocation();
  }, []);

  // Admin QR Code generator for selected store checkpoint
  useEffect(() => {
    const checkpoint = checkpointsList.find(c => c.id === selectedCheckpointId) || checkpointsList[0];
    if (!checkpoint) return;

    const payload = JSON.stringify({
      code: checkpoint.code,
      station: checkpoint.name,
      companyId: checkpoint.companyId,
      companyName: checkpoint.companyName,
      googleMapsUrl: checkpoint.googleMapsUrl,
      address: checkpoint.address,
      generatedAt: new Date().toISOString(),
    });

    QRCode.toDataURL(payload, {
      width: 320,
      margin: 2,
      color: {
        dark: '#070a12',
        light: '#ffffff',
      },
    })
      .then(url => setGeneratedQRUrl(url))
      .catch(err => console.error('Error generating QR:', err));
  }, [selectedCheckpointId, checkpointsList]);

  // Trigger auto sync of queued offline check-ins
  const triggerAutoSync = async () => {
    if (offlineQueue.length === 0 || !navigator.onLine) return;
    try {
      setIsSyncing(true);
      await onBatchSyncOfflineCheckins(offlineQueue);
      setSyncFeedback(`¡${offlineQueue.length} marcajes sincronizados con el servidor del Administrador Principal!`);
      setOfflineQueue([]);
      setTimeout(() => setSyncFeedback(null), 4000);
    } catch (err: any) {
      console.error('Error syncing batch:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  // Marcaje oficial directo en punto asignado
  const handleDirectStationCheckin = () => {
    const cp = checkpointsList.find(c => c.id === selectedCheckpointId) || checkpointsList[0] || {
      code: 'QR-TIENDA-FERMAC-01',
      name: currentUser.stationName || 'Tienda Central Fermac Zona 1',
      companyId: 'comp-1',
      companyName: 'Fermac',
      googleMapsUrl: 'https://maps.google.com/?q=14.8348,-91.5181',
      address: 'Zona 1, Quetzaltenango',
    };

    // QR scanning functionality removed
  };

  // Marcaje de Entrada, Salida o Ubicación directo usando GPS del dispositivo
  const handleGuardGenericCheckin = async () => {
    try {
      setIsSubmitting(true);

      // Obtener coordenadas en vivo de máxima precisión
      let currentLat = gpsLocation.latitude;
      let currentLng = gpsLocation.longitude;
      let currentAcc = gpsLocation.accuracy;
      let currentAddr = gpsLocation.addressText;

      if (navigator.geolocation) {
        try {
          const freshPos = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, {
              enableHighAccuracy: true,
              timeout: 6000,
              maximumAge: 0,
            });
          });
          currentLat = freshPos.coords.latitude;
          currentLng = freshPos.coords.longitude;
          currentAcc = Math.round(freshPos.coords.accuracy);
          currentAddr = `GPS: ${currentLat.toFixed(5)}, ${currentLng.toFixed(5)} (±${currentAcc}m)`;
        } catch { /* Usar ubicación previa */ }
      }

      const googleMapsUrl = currentLat && currentLng 
        ? `https://maps.google.com/?q=${currentLat},${currentLng}`
        : 'https://maps.google.com/?q=14.8348,-91.5181';

      const checkinPayload: Partial<GuardCheckin> = {
        type: checkinType,
        checkpointCode: 'GPS-DISPOSITIVO-MOVIL',
        checkpointName: currentUser.stationName || 'Tienda Asignada',
        companyId: currentUser.companyId,
        companyName: currentUser.companyName,
        googleMapsUrl,
        delayReason: delayReason.trim() ? delayReason.trim() : undefined,
        location: {
          latitude: currentLat,
          longitude: currentLng,
          accuracy: currentAcc,
          addressText: currentAddr,
        },
        notes: `Marcaje ${checkinType} registrado por ${currentUser.name} vía GPS.`,
      };

      // Si offline, poner en cola
      if (!navigator.onLine) {
        const offlineRecord: GuardCheckin = {
          id: `chk-offline-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          guardId: currentUser.id,
          guardName: currentUser.name,
          employeeId: currentUser.employeeId,
          guardPinCode: currentUser.pinCode,
          type: checkinType,
          timestamp: new Date().toISOString(),
          checkpointCode: 'GPS-DISPOSITIVO-MOVIL',
          checkpointName: checkinPayload.checkpointName!,
          companyId: currentUser.companyId,
          companyName: currentUser.companyName,
          googleMapsUrl,
          delayReason: delayReason.trim() ? delayReason.trim() : undefined,
          location: checkinPayload.location!,
          notes: checkinPayload.notes!,
          isOfflineSynced: false,
        };

        setOfflineQueue(prev => [offlineRecord, ...prev]);
        setLastCheckinResult(offlineRecord);
        setDelayReason('');
        return;
      }

      // Si online, registrar
      await onRecordCheckin(checkinPayload);
      setLastCheckinResult({
        id: `chk-${Date.now()}`,
        guardId: currentUser.id,
        guardName: currentUser.name,
        employeeId: currentUser.employeeId,
        guardPinCode: currentUser.pinCode,
        type: checkinType,
        timestamp: new Date().toISOString(),
        checkpointCode: 'GPS-DISPOSITIVO-MOVIL',
        checkpointName: checkinPayload.checkpointName!,
        companyId: currentUser.companyId,
        companyName: currentUser.companyName,
        googleMapsUrl,
        delayReason: delayReason.trim() ? delayReason.trim() : undefined,
        location: checkinPayload.location!,
        notes: checkinPayload.notes!,
      });

      setDelayReason('');
    } catch (err: any) {
      alert(err.message || 'Error al registrar el marcaje.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Group checkins into Shifts for Admin (Pairing Entrada & Salida)
  const pairedShifts = useMemo(() => {
    const shifts: {
      id: string;
      guardName: string;
      guardId: string;
      dateStr: string;
      entrada?: GuardCheckin;
      salida?: GuardCheckin;
      hoursWorked: string;
      storeName: string;
      googleMapsUrl?: string;
      delayReason?: string;
      status: 'EN_TURNO' | 'COMPLETO';
      isOfflineSynced?: boolean;
    }[] = [];

    // Group by guard and date
    const grouped: { [key: string]: GuardCheckin[] } = {};
    for (const c of guardCheckins) {
      const date = c.timestamp.slice(0, 10);
      const key = `${c.guardId}_${date}`;
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(c);
    }

    for (const key in grouped) {
      const records = grouped[key].sort(
        (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );
      const entrada = records.find(r => r.type === 'ENTRADA');
      const salida = records.slice().reverse().find(r => r.type === 'SALIDA');
      const guardName = records[0].guardName;
      const guardId = records[0].guardId;
      const dateStr = records[0].timestamp.slice(0, 10);
      const storeName = entrada?.checkpointName || salida?.checkpointName || 'Garita';
      const googleMapsUrl = entrada?.googleMapsUrl || salida?.googleMapsUrl;
      const delayReason = entrada?.delayReason || salida?.delayReason;
      const isOfflineSynced = records.some(r => r.isOfflineSynced);

      let hoursWorked = '—';
      let status: 'EN_TURNO' | 'COMPLETO' = 'EN_TURNO';

      if (entrada && salida && new Date(salida.timestamp).getTime() > new Date(entrada.timestamp).getTime()) {
        const diffMs = new Date(salida.timestamp).getTime() - new Date(entrada.timestamp).getTime();
        const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
        const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        hoursWorked = `${diffHrs}h ${diffMins}m`;
        status = 'COMPLETO';
      } else if (entrada && !salida) {
        status = 'EN_TURNO';
      }

      shifts.push({
        id: `shift-${key}`,
        guardName,
        guardId,
        dateStr,
        entrada,
        salida,
        hoursWorked,
        storeName,
        googleMapsUrl,
        delayReason,
        status,
        isOfflineSynced,
      });
    }

    return shifts.sort((a, b) => b.dateStr.localeCompare(a.dateStr));
  }, [guardCheckins]);

  // Wallpaper save handler
  const handleSaveWallpaper = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!wallpaperUrlInput.trim()) return;

    try {
      await onUpdateSecurityConfig({ guardWallpaperUrl: wallpaperUrlInput.trim() });
      setWallpaperSuccess(true);
      setTimeout(() => setWallpaperSuccess(false), 3000);
    } catch (err: any) {
      alert(err.message || 'Error al guardar fondo de pantalla.');
    }
  };

  // Salary & IGSS save handler
  const handleSaveSalaryAndIgss = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onUpdateSecurityConfig({
        guardBaseSalary: Number(adminGuardSalary) || 4200,
        igssPercentage: Number(adminIgssPercentage) || 4.83,
        applySalaryToAllGuards: applySalaryToEmployees,
      });
      setSalarySaveSuccess(true);
      setTimeout(() => setSalarySaveSuccess(false), 3500);
    } catch (err: any) {
      alert(err.message || 'Error al guardar parámetros salariales.');
    }
  };

  // Add store checkpoint handler
  const handleCreateStore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStoreData.name.trim() || !newStoreData.googleMapsUrl.trim()) return;

    try {
      await onAddCheckpoint({
        name: newStoreData.name.trim(),
        companyId: newStoreData.companyId || undefined,
        googleMapsUrl: newStoreData.googleMapsUrl.trim(),
        address: newStoreData.address.trim() || 'Guatemala',
      });
      setIsNewStoreModalOpen(false);
      setNewStoreData({
        name: '',
        companyId: companies[0]?.id || '',
        googleMapsUrl: '',
        address: '',
      });
    } catch (err: any) {
      alert(err.message || 'Error al agregar tienda.');
    }
  };

  // Guard background style
  const guardBgStyle = isGuard && securityConfig?.guardWallpaperUrl ? {
    backgroundImage: `linear-gradient(to bottom, rgba(7, 10, 18, 0.85), rgba(7, 10, 18, 0.95)), url(${securityConfig.guardWallpaperUrl})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed',
  } : {};

  // Net salary calculation preview
  const previewIgssDiscount = (adminGuardSalary * (adminIgssPercentage / 100));
  const previewEstimatedNet = adminGuardSalary - previewIgssDiscount + 250; // + Bonificación Ley Q250

  return (
    <div className="space-y-6" style={guardBgStyle}>
      
      {/* MOBILE ORIENTATION ENFORCER FOR GUARDS (VERTICAL ONLY) */}
      {isGuard && isMobileLandscape && (
        <div className="fixed inset-0 z-50 bg-[#070a12]/95 backdrop-blur-2xl flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
          <div className="w-16 h-16 rounded-3xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/40 mb-4 animate-bounce">
            <Smartphone className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-black text-white uppercase tracking-wider mb-2">
            Orientación Vertical Requerida
          </h2>
          <p className="text-xs text-slate-300 max-w-xs leading-relaxed mb-4">
            Para la seguridad del escaneo de códigos QR y control de asistencia, la terminal de guardia solo funciona con el teléfono en posición vertical.
          </p>
          <span className="text-[11px] font-mono px-3 py-1 rounded-full bg-cyan-400/10 text-cyan-300 border border-cyan-400/30">
            Gira tu dispositivo verticalmente
          </span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <ShieldCheck className="w-6 h-6 text-cyan-400" />
            <span>{isGuard ? 'Terminal de Guardia: Marcaje de Turno' : 'Control de Guardias: Entradas, Salidas & Tiendas QR'}</span>
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">
            {isGuard 
              ? 'Escaneo oficial por cámara de código QR de la tienda. Los datos se sincronizan con la cuenta del Administrador General.'
              : 'Supervisión de horas de entrada y salida, sueldos de guardias, porcentaje de IGSS y tiendas en Google Maps.'}
          </p>
        </div>

        {/* Live Clock & Network Badge */}
        <div className="flex items-center gap-2">
          {/* Online/Offline Badge */}
          <div className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 text-xs font-semibold ${
            isOnline 
              ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300' 
              : 'bg-amber-500/20 border-amber-500/40 text-amber-300'
          }`}>
            {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5 animate-pulse" />}
            <span>{isOnline ? 'En Línea (Sincronizado)' : 'Sin Internet (Offline)'}</span>
          </div>

          <div className="liquid-glass px-3 py-1.5 rounded-xl border border-white/10 flex items-center gap-2 text-xs">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            <span className="text-slate-200 font-mono tabular-nums font-bold">
              {currentTime.toLocaleTimeString('es-GT', { hour12: true })}
            </span>
          </div>
        </div>
      </div>

      {/* Offline Pending Sync Banner */}
      {offlineQueue.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-[0_0_20px_rgba(245,158,11,0.2)]">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <p className="font-bold text-xs text-white">
                Tienes {offlineQueue.length} marcaje(s) almacenados localmente en modo sin conexión
              </p>
              <p className="text-[11px] text-amber-200/80">
                La hora original de escaneo está resguardada. Al detectar conexión a internet se subirán automáticamente a la cuenta del Administrador General.
              </p>
            </div>
          </div>
          {isOnline && (
            <button
              onClick={triggerAutoSync}
              disabled={isSyncing}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-all flex items-center gap-1.5 shrink-0 shadow-md"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Subiendo...' : 'Sincronizar al Servidor'}</span>
            </button>
          )}
        </div>
      )}

      {syncFeedback && (
        <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{syncFeedback}</span>
        </div>
      )}

      {/* ======================================================== */}
      {/* 1. GUARD VIEW: ONLY ENTRADA/SALIDA, TIENDA & CAMARA      */}
      {/* (NO MANUAL INPUT, NO QR VIEWER, NO HISTORY)              */}
      {/* ======================================================== */}
      {isGuard && (
        <div className="max-w-md mx-auto space-y-4">
          <div className="liquid-glass rounded-3xl p-5 sm:p-6 border border-white/15 space-y-4 shadow-2xl relative overflow-hidden backdrop-blur-3xl">
            
            {/* Header info */}
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                  Terminal de Guardia
                </h3>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                {currentUser.name}
              </span>
            </div>

            {/* TIENDA A LA QUE PERTENECE EL GUARDIA (REQUESTED) */}
            <div className="p-3.5 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 space-y-1">
              <div className="flex items-center gap-2 text-cyan-300">
                <Store className="w-4 h-4 text-cyan-400 shrink-0" />
                <span className="text-[11px] font-bold uppercase tracking-wider">
                  Tienda Asignada:
                </span>
              </div>
              <p className="text-sm font-bold text-white pl-6">
                {currentUser.stationName || 'Garita Central Fermac - Zona 1 Xela'}
              </p>
              <p className="text-[10px] text-slate-400 pl-6">
                Tu asistencia queda registrada bajo esta sucursal oficial.
              </p>
            </div>

            {/* Selector de Tipo de Marcaje */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2">
                Selecciona Tipo de Marcaje:
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setCheckinType('ENTRADA')}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                    checkinType === 'ENTRADA'
                      ? 'bg-emerald-500/25 border-emerald-400 text-emerald-300 shadow-[0_0_25px_rgba(16,185,129,0.35)] scale-[1.02]'
                      : 'bg-black/40 border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-xs font-black uppercase tracking-wider">ENTRADA</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCheckinType('SALIDA')}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                    checkinType === 'SALIDA'
                      ? 'bg-rose-500/25 border-rose-400 text-rose-300 shadow-[0_0_25px_rgba(244,63,94,0.35)] scale-[1.02]'
                      : 'bg-black/40 border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-xs font-black uppercase tracking-wider">SALIDA</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setCheckinType('REPORTE_UBICACION');
                    refreshGpsLocation();
                  }}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                    checkinType === 'REPORTE_UBICACION'
                      ? 'bg-cyan-500/25 border-cyan-400 text-cyan-300 shadow-[0_0_25px_rgba(6,182,212,0.35)] scale-[1.02]'
                      : 'bg-black/40 border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-xs font-black uppercase tracking-wider">UBICACIÓN</span>
                </button>
              </div>
            </div>

            {/* Marcaje de Asistencia (Entrada/Salida/Ubicación) */}
            <div className="space-y-3.5 p-4 rounded-2xl bg-white/5 border border-white/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-cyan-300">
                  <Navigation className="w-4 h-4 text-cyan-400 animate-pulse" />
                  <span className="text-xs font-bold uppercase tracking-wider">
                    Ubicación Actual
                  </span>
                </div>
                <button
                  type="button"
                  onClick={refreshGpsLocation}
                  disabled={gpsLocation.loading}
                  className="px-2.5 py-1 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 text-[10px] font-bold border border-cyan-500/30 flex items-center gap-1 transition-all"
                >
                  <RefreshCw className={`w-3 h-3 ${gpsLocation.loading ? 'animate-spin' : ''}`} />
                  <span>{gpsLocation.loading ? 'Detectando...' : 'Actualizar GPS'}</span>
                </button>
              </div>

              {/* Tarjeta de Coordenadas y Precisión */}
              <div className="p-3 bg-black/50 rounded-xl border border-white/10 space-y-1.5 font-mono">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Coordenadas:</span>
                  <span className="text-white font-bold tabular-nums">
                    {gpsLocation.latitude !== null && gpsLocation.longitude !== null
                      ? `${gpsLocation.latitude.toFixed(5)}, ${gpsLocation.longitude.toFixed(5)}`
                      : 'Buscando satélites...'}
                  </span>
                </div>
                <div className="pt-1.5 border-t border-white/5 text-[10px] text-slate-400 truncate">
                  {gpsLocation.addressText}
                </div>
              </div>

              {/* Comentario / Observación */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Comentario / Novedad (Opcional):
                </label>
                <input
                  type="text"
                  placeholder="Ej. Entrada a tiempo, tráfico pesado..."
                  value={delayReason}
                  onChange={e => setDelayReason(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                />
              </div>

              {/* Acción principal: Marcar ENTRADA, SALIDA o UBICACIÓN con GPS */}
              <div className="pt-1">
                <button
                  type="button"
                  onClick={handleGuardGenericCheckin}
                  disabled={isSubmitting || gpsLocation.loading}
                  className="w-full py-4 px-4 rounded-2xl font-black text-sm text-slate-950 bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 transition-all shadow-[0_0_25px_rgba(6,182,212,0.45)] flex items-center justify-center gap-2.5 active:scale-95 disabled:opacity-50 cursor-pointer"
                >
                  <LocateFixed className="w-5 h-5 text-slate-950 animate-pulse" />
                  <span>MARCAR {checkinType === 'ENTRADA' ? 'ENTRADA' : checkinType === 'SALIDA' ? 'SALIDA' : 'UBICACIÓN'} AHORA</span>
                </button>
              </div>
            </div>

            {/* Success Feedback Banner */}
            {lastCheckinResult && (
              <div className="p-4 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl text-xs text-emerald-300 space-y-1.5 animate-in fade-in shadow-lg">
                <div className="flex items-center gap-2 font-bold text-white text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>
                    {lastCheckinResult.type === 'REPORTE_UBICACION'
                      ? '¡Reporte de Ubicación GPS Registrado con Éxito!'
                      : `¡Marcaje de ${lastCheckinResult.type} Registrado!`}
                  </span>
                </div>
                <p className="text-slate-200 text-xs">
                  Hora: <strong>{new Date(lastCheckinResult.timestamp).toLocaleTimeString('es-GT', { hour12: true })}</strong> · Puesto: <strong>{lastCheckinResult.checkpointName}</strong>
                </p>
                {lastCheckinResult.location && lastCheckinResult.location.latitude && (
                  <p className="text-[11px] text-cyan-300 font-mono flex items-center gap-1.5">
                    <Navigation className="w-3 h-3 text-cyan-400" />
                    <span>GPS: {lastCheckinResult.location.latitude.toFixed(5)}, {lastCheckinResult.location.longitude?.toFixed(5)}</span>
                    {lastCheckinResult.googleMapsUrl && (
                      <a
                        href={lastCheckinResult.googleMapsUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="underline text-cyan-400 hover:text-cyan-200 font-bold ml-1"
                      >
                        (Ver en Google Maps)
                      </a>
                    )}
                  </p>
                )}
                {lastCheckinResult.delayReason && (
                  <p className="text-amber-300 text-[11px] font-medium">
                    Observación/Motivo: "{lastCheckinResult.delayReason}"
                  </p>
                )}
                {!isOnline && (
                  <p className="text-[10px] text-amber-300 font-bold pt-1 border-t border-amber-500/30">
                    Guardado en memoria de tu dispositivo. Se sincronizará con la cuenta del Administrador General al recuperar internet.
                  </p>
                )}
              </div>
            )}

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. ADMIN VIEW: SHIFTS, SALARIES/IGSS, QR & WALLPAPERS    */}
      {/* ======================================================== */}
      {isAdmin && (
        <div className="space-y-6">
          
          {/* Subtabs for Admin */}
          <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-black/40 border border-white/10 max-w-4xl">
            <button
              onClick={() => setAdminTab('SHIFTS')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                adminTab === 'SHIFTS'
                  ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>Horas de Entrada y Salida</span>
            </button>

            <button
              onClick={() => setAdminTab('SALARY_IGSS')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                adminTab === 'SALARY_IGSS'
                  ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Sueldo Guardias & IGSS</span>
            </button>

            <button
              onClick={() => setAdminTab('QR_MANAGER')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                adminTab === 'QR_MANAGER'
                  ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <QrCode className="w-4 h-4 text-cyan-400" />
              <span>Tiendas con Google Maps & QR</span>
            </button>

            <button
              onClick={() => setAdminTab('CHECKINS')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                adminTab === 'CHECKINS'
                  ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Bitácora Individual ({guardCheckins.length})</span>
            </button>

            <button
              onClick={() => setAdminTab('WALLPAPER')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                adminTab === 'WALLPAPER'
                  ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ImageIcon className="w-4 h-4 text-cyan-400" />
              <span>Fondo de Guardias</span>
            </button>
          </div>

          {/* TAB 1: PAIRING OF ENTRADA & SALIDA (TURNOS DE GUARDIAS) */}
          {adminTab === 'SHIFTS' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-bold text-white">
                    Registro de Entradas y Salidas de Guardias (Almacenamiento Central)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Visualiza la hora exacta de entrada, salida, duración de turno, tienda asignada y sincronización de datos offline.
                  </p>
                </div>
              </div>

              {pairedShifts.length === 0 ? (
                <div className="liquid-glass rounded-3xl p-8 text-center text-xs text-slate-400 border border-white/10">
                  No hay turnos registrados aún. Cuando los guardias escaneen el código QR de entrada o salida, aparecerán reflejados aquí.
                </div>
              ) : (
                <div className="liquid-glass rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-black/60 text-slate-300 text-[11px] font-bold uppercase tracking-wider border-b border-white/10">
                        <tr>
                          <th className="py-3.5 px-4">Guardia</th>
                          <th className="py-3.5 px-4">Fecha</th>
                          <th className="py-3.5 px-4">Hora de Entrada</th>
                          <th className="py-3.5 px-4">Hora de Salida</th>
                          <th className="py-3.5 px-4">Tiempo en Turno</th>
                          <th className="py-3.5 px-4">Tienda / Puesto</th>
                          <th className="py-3.5 px-4">Retraso / Justificación</th>
                          <th className="py-3.5 px-4">Estado Sincronización</th>
                          <th className="py-3.5 px-4">Google Maps</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {pairedShifts.map(shift => {
                          const hasMapsUrl = !!shift.googleMapsUrl;
                          return (
                            <tr key={shift.id} className="hover:bg-white/5 transition-colors">
                              
                              {/* Guardia */}
                              <td className="py-3.5 px-4 font-semibold text-white">
                                <div className="flex items-center gap-2">
                                  <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-300 font-bold flex items-center justify-center text-xs border border-emerald-500/30">
                                    G
                                  </div>
                                  <div>
                                    <span>{shift.guardName}</span>
                                    <span className="block text-[10px] text-slate-400 font-mono">
                                      {shift.guardId}
                                    </span>
                                  </div>
                                </div>
                              </td>

                              {/* Fecha */}
                              <td className="py-3.5 px-4 text-slate-300 font-medium">
                                {formatDate(shift.dateStr)}
                              </td>

                              {/* Hora Entrada */}
                              <td className="py-3.5 px-4">
                                {shift.entrada ? (
                                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-mono tabular-nums font-bold">
                                    <span>{new Date(shift.entrada.timestamp).toLocaleTimeString('es-GT', { hour12: true })}</span>
                                  </div>
                                ) : (
                                  <span className="text-slate-500 italic">No registrada</span>
                                )}
                              </td>

                              {/* Hora Salida */}
                              <td className="py-3.5 px-4">
                                {shift.salida ? (
                                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-rose-500/20 border border-rose-500/30 text-rose-300 font-mono tabular-nums font-bold">
                                    <span>{new Date(shift.salida.timestamp).toLocaleTimeString('es-GT', { hour12: true })}</span>
                                  </div>
                                ) : (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-[10px] font-semibold animate-pulse">
                                    En Turno Activo
                                  </span>
                                )}
                              </td>

                              {/* Horas trabajadas */}
                              <td className="py-3.5 px-4 font-mono font-bold text-cyan-300 tabular-nums">
                                {shift.hoursWorked}
                              </td>

                              {/* Tienda */}
                              <td className="py-3.5 px-4 text-slate-200">
                                {shift.storeName}
                              </td>

                              {/* Comentario Retraso */}
                              <td className="py-3.5 px-4">
                                {shift.delayReason ? (
                                  <span className="inline-flex items-center gap-1 text-[11px] text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-lg font-medium">
                                    <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
                                    <span>{shift.delayReason}</span>
                                  </span>
                                ) : (
                                  <span className="text-slate-500 text-[11px]">A tiempo</span>
                                )}
                              </td>

                              {/* Estado Sincronización */}
                              <td className="py-3.5 px-4">
                                {shift.isOfflineSynced ? (
                                  <span className="text-[10px] font-semibold text-sky-300 bg-sky-500/20 border border-sky-500/30 px-2 py-0.5 rounded-full flex items-center gap-1 w-fit">
                                    ☁️ Subido desde Offline
                                  </span>
                                ) : (
                                  <span className="text-[10px] text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 w-fit block">
                                    🟢 Directo en Línea
                                  </span>
                                )}
                              </td>

                              {/* Google Maps link */}
                              <td className="py-3.5 px-4">
                                {hasMapsUrl ? (
                                  <a
                                    href={shift.googleMapsUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-semibold text-[11px] transition-colors"
                                  >
                                    <span>Ver Tienda</span>
                                    <ExternalLink className="w-3 h-3" />
                                  </a>
                                ) : (
                                  <span className="text-slate-600">—</span>
                                )}
                              </td>

                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SUELDO BASE DE GUARDIAS & PORCENTAJE DE IGSS (REQUESTED) */}
          {adminTab === 'SALARY_IGSS' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              <div className="lg:col-span-7 space-y-4">
                <div className="liquid-glass rounded-3xl p-6 border border-white/10 space-y-5">
                  <div className="flex items-center justify-between border-b border-white/10 pb-3">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-emerald-400" />
                      <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                        Configuración de Sueldo para Todos los Guardias & IGSS
                      </h3>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Administrador Principal
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-snug">
                    Como Administrador Principal, puedes definir aquí el sueldo mensual asignado para todos los guardias de seguridad en general, así como el porcentaje legal de retención de IGSS (por defecto 4.83%).
                  </p>

                  {salarySaveSuccess && (
                    <div className="p-3.5 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl text-xs text-emerald-300 flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>¡Sueldo general de guardias y porcentaje de IGSS actualizados exitosamente!</span>
                    </div>
                  )}

                  <form onSubmit={handleSaveSalaryAndIgss} className="space-y-4 text-xs">
                    
                    {/* Sueldo Base General */}
                    <div>
                      <label className="block font-bold text-slate-200 mb-1">
                        Sueldo Base Mensual para Guardias (Quetzales - GTQ):
                      </label>
                      <div className="relative">
                        <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-400">Q</span>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          required
                          value={adminGuardSalary}
                          onChange={e => setAdminGuardSalary(Number(e.target.value))}
                          className="w-full pl-8 pr-4 py-2.5 rounded-xl liquid-glass-input text-sm font-mono font-bold text-emerald-300"
                        />
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-1">
                        Este monto servirá como estándar corporativo para todas las garitas y puestos de seguridad.
                      </span>
                    </div>

                    {/* Porcentaje de IGSS */}
                    <div>
                      <label className="block font-bold text-slate-200 mb-1">
                        Porcentaje de Retención Laboral de IGSS (%):
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          max="100"
                          required
                          value={adminIgssPercentage}
                          onChange={e => setAdminIgssPercentage(Number(e.target.value))}
                          className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-sm font-mono font-bold text-cyan-300"
                        />
                        <span className="absolute right-3.5 top-2.5 text-xs font-bold text-slate-400">%</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-1">
                        Porcentaje legal de retención del Instituto Guatemalteco de Seguridad Social (estándar 4.83%).
                      </span>
                    </div>

                    {/* Checkbox aplicar a todos los guardias */}
                    <div className="p-3 rounded-xl bg-black/40 border border-white/5 flex items-center gap-3">
                      <input
                        type="checkbox"
                        id="applyAllGuards"
                        checked={applySalaryToEmployees}
                        onChange={e => setApplySalaryToEmployees(e.target.checked)}
                        className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400 accent-cyan-500 cursor-pointer"
                      />
                      <label htmlFor="applyAllGuards" className="text-xs text-slate-200 cursor-pointer font-medium">
                        Actualizar inmediatamente el salario en la nómina de todos los guardias registrados
                      </label>
                    </div>

                    <button
                      type="submit"
                      className="px-6 py-3 rounded-xl font-bold text-xs text-slate-950 bg-gradient-to-r from-emerald-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] flex items-center gap-2"
                    >
                      <Check className="w-4 h-4" />
                      <span>Guardar Parámetros Salariales de Guardias</span>
                    </button>

                  </form>
                </div>
              </div>

              {/* Right Column: Live Calculation Breakdown */}
              <div className="lg:col-span-5 space-y-4">
                <div className="liquid-glass rounded-3xl p-6 border border-white/10 space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Desglose Estimado por Guardia:
                  </h4>

                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300">Sueldo Base Mensual:</span>
                      <span className="font-mono font-bold text-white tabular-nums">
                        {formatCurrencyGTQ(adminGuardSalary)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs text-rose-300">
                      <span>Deducción IGSS ({adminIgssPercentage}%):</span>
                      <span className="font-mono font-bold tabular-nums">
                        - {formatCurrencyGTQ(previewIgssDiscount)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs text-emerald-300">
                      <span>Bonificación Incentivo Ley:</span>
                      <span className="font-mono font-bold tabular-nums">
                        + Q250.00
                      </span>
                    </div>

                    <div className="pt-3 border-t border-white/10 flex items-center justify-between text-sm">
                      <span className="font-bold text-white">Líquido Estimado a Recibir:</span>
                      <span className="font-mono font-black text-cyan-300 text-base tabular-nums">
                        {formatCurrencyGTQ(previewEstimatedNet)}
                      </span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400 leading-snug pt-3 border-t border-white/5">
                    Este cálculo se refleja automáticamente en la planilla quincenal y reportes contables oficiales en Excel.
                  </p>
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: QR CHECKPOINTS MANAGER & GOOGLE MAPS STORE LINKS */}
          {adminTab === 'QR_MANAGER' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Column: Stores & Form */}
              <div className="lg:col-span-7 space-y-4">
                <div className="liquid-glass rounded-3xl p-5 border border-white/10 space-y-4">
                  <div className="flex items-center justify-between border-b border-white/10 pb-3">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-cyan-400" />
                      <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                        Tiendas y Puestos con Enlace a Google Maps
                      </h3>
                    </div>
                    <button
                      onClick={() => setIsNewStoreModalOpen(true)}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5 text-slate-950" />
                      <span>Agregar Tienda</span>
                    </button>
                  </div>

                  <p className="text-xs text-slate-300 leading-snug">
                    Como administrador principal, puedes configurar la ubicación de cada tienda con un enlace oficial de Google Maps. Los códigos QR generados incluirán este enlace satelital para que el marcaje de los guardias quede vinculado a la posición exacta de la tienda.
                  </p>

                  {/* Stores List */}
                  <div className="space-y-2.5">
                    {checkpointsList.map(cp => {
                      const isSelected = cp.id === selectedCheckpointId;
                      return (
                        <div
                          key={cp.id}
                          onClick={() => setSelectedCheckpointId(cp.id)}
                          className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                            isSelected
                              ? 'bg-cyan-500/15 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.2)]'
                              : 'bg-black/30 border-white/5 hover:bg-white/5'
                          }`}
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white text-xs">{cp.name}</span>
                              <span className="text-[10px] font-mono px-2 py-0.2 rounded bg-white/10 text-cyan-300">
                                {cp.code}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5">{cp.address}</p>
                            <a
                              href={cp.googleMapsUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={e => e.stopPropagation()}
                              className="inline-flex items-center gap-1 text-[11px] text-cyan-400 hover:underline mt-1 font-semibold"
                            >
                              <span>Enlace Google Maps</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>

                          <div className="flex items-center gap-2">
                            {isSelected && (
                              <span className="text-[10px] font-bold text-cyan-300 bg-cyan-500/20 px-2 py-1 rounded-lg">
                                QR Activo
                              </span>
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                if (confirm(`¿Eliminar la tienda ${cp.name}?`)) {
                                  onDeleteCheckpoint(cp.id);
                                }
                              }}
                              className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors"
                              title="Eliminar tienda"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Right Column: Display Generated QR for the Selected Store */}
              <div className="lg:col-span-5 space-y-4">
                <div className="liquid-glass rounded-3xl p-5 border border-white/10 space-y-4 flex flex-col items-center text-center">
                  <div className="flex items-center gap-2 border-b border-white/10 pb-2 w-full justify-center">
                    <QrCode className="w-4 h-4 text-cyan-400" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                      Código QR Oficial para Escaneo
                    </h3>
                  </div>

                  {/* QR Canvas Display */}
                  <div className="p-4 bg-white rounded-3xl shadow-2xl flex flex-col items-center">
                    {generatedQRUrl ? (
                      <img
                        src={generatedQRUrl}
                        alt="Código QR de Tienda"
                        className="w-56 h-56 object-contain"
                      />
                    ) : (
                      <div className="w-56 h-56 flex items-center justify-center text-slate-500 text-xs">
                        Generando código...
                      </div>
                    )}
                    <div className="mt-2 text-center text-slate-900">
                      <span className="font-extrabold text-xs block">
                        {checkpointsList.find(c => c.id === selectedCheckpointId)?.name}
                      </span>
                      <span className="font-mono text-[10px] text-slate-600 block">
                        {checkpointsList.find(c => c.id === selectedCheckpointId)?.code}
                      </span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400 leading-snug">
                    Imprime o muestra este código en la garita o entrada de la tienda. Los guardias lo escanearán desde su cámara para registrar su ingreso y salida.
                  </p>

                  {checkpointsList.find(c => c.id === selectedCheckpointId)?.googleMapsUrl && (
                    <a
                      href={checkpointsList.find(c => c.id === selectedCheckpointId)?.googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 transition-all flex items-center gap-2"
                    >
                      <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Abrir Ubicación en Google Maps</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </div>

            </div>
          )}

          {/* TAB 4: INDIVIDUAL CHECKINS STREAM */}
          {adminTab === 'CHECKINS' && (
            <div className="liquid-glass rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
              <div className="p-4 border-b border-white/10 flex items-center justify-between">
                <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                  Bitácora de Marcajes Individuales ({guardCheckins.length} Registros)
                </h3>
                <span className="text-xs text-slate-400">
                  Historial de entradas y salidas con GPS
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-black/60 text-slate-400 text-[11px] font-bold uppercase tracking-wider border-b border-white/10">
                    <tr>
                      <th className="py-3 px-4">Guardia</th>
                      <th className="py-3 px-4">Tipo</th>
                      <th className="py-3 px-4">Hora & Fecha</th>
                      <th className="py-3 px-4">Tienda / Punto</th>
                      <th className="py-3 px-4">Retraso / Motivo</th>
                      <th className="py-3 px-4">Estado</th>
                      <th className="py-3 px-4">Google Maps</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {guardCheckins.map(chk => (
                      <tr key={chk.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3 px-4 font-semibold text-white">
                          {chk.guardName}
                        </td>
                        <td className="py-3 px-4">
                          {chk.type === 'ENTRADA' ? (
                            <span className="text-[10px] font-bold text-emerald-300 bg-emerald-500/20 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                              ENTRADA
                            </span>
                          ) : chk.type === 'SALIDA' ? (
                            <span className="text-[10px] font-bold text-rose-300 bg-rose-500/20 border border-rose-500/30 px-2 py-0.5 rounded-full">
                              SALIDA
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold text-cyan-300 bg-cyan-500/20 border border-cyan-500/30 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-cyan-400" />
                              REPORTE UBICACIÓN
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-mono text-cyan-300 tabular-nums">
                          {formatDateTime(chk.timestamp)}
                        </td>
                        <td className="py-3 px-4 text-slate-200">
                          {chk.checkpointName}
                        </td>
                        <td className="py-3 px-4">
                          {chk.delayReason ? (
                            <span className="text-amber-300 text-[11px] font-medium bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                              {chk.delayReason}
                            </span>
                          ) : (
                            <span className="text-slate-500 text-[11px]">A tiempo</span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {chk.isOfflineSynced ? (
                            <span className="text-[10px] text-sky-300 font-semibold bg-sky-500/15 px-2 py-0.5 rounded">
                              Sincronizado Offline
                            </span>
                          ) : (
                            <span className="text-[10px] text-emerald-300 font-semibold bg-emerald-500/15 px-2 py-0.5 rounded">
                              En Línea
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {chk.googleMapsUrl ? (
                            <a
                              href={chk.googleMapsUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold"
                            >
                              <span>Ver Mapa</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          ) : (
                            <span className="text-slate-600">—</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: WALLPAPER EDITOR FOR GUARDS */}
          {adminTab === 'WALLPAPER' && (
            <div className="liquid-glass rounded-3xl p-6 border border-white/10 space-y-5 max-w-2xl">
              <div>
                <h3 className="text-base font-bold text-white">
                  Fondo de Pantalla General para Guardias
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Personaliza la imagen de fondo que verán todos los guardias de seguridad al abrir su terminal de escaneo.
                </p>
              </div>

              {wallpaperSuccess && (
                <div className="p-3 bg-emerald-500/15 text-emerald-300 rounded-xl border border-emerald-500/30 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Fondo de pantalla guardado y aplicado para todos los guardias.</span>
                </div>
              )}

              <form onSubmit={handleSaveWallpaper} className="space-y-4">
                {/* Botón para Elegir desde la Galería de la Computadora o Teléfono */}
                <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2.5">
                  <span className="text-[11px] font-bold text-slate-300 block uppercase tracking-wider">
                    Elegir de tu Dispositivo:
                  </span>
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="file"
                      ref={wallpaperFileInputRef}
                      accept="image/*"
                      onChange={handleWallpaperGalleryUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => wallpaperFileInputRef.current?.click()}
                      className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 hover:text-white border border-cyan-400/40 hover:border-cyan-400 text-xs font-bold transition-all flex items-center gap-2 shadow-sm"
                    >
                      <Upload className="w-4 h-4 text-cyan-400" />
                      <span>📁 Elegir Fondo desde Galería (Computadora o Teléfono)</span>
                    </button>
                    {wallpaperUrlInput.startsWith('data:') && (
                      <span className="text-xs text-emerald-300 font-semibold bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20 flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Imagen de galería cargada</span>
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    O Enlace / URL Directo de la Imagen:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="https://images.unsplash.com/..."
                    value={wallpaperUrlInput.startsWith('data:') ? 'Imagen cargada desde Galería del Dispositivo' : wallpaperUrlInput}
                    onChange={e => setWallpaperUrlInput(e.target.value)}
                    disabled={wallpaperUrlInput.startsWith('data:')}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs disabled:opacity-75 font-mono"
                  />
                </div>

                {/* Curated Presets */}
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    Fondos Tácticos Recomendados:
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { name: 'Obsidiana Táctica', url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1920&q=80' },
                      { name: 'Centro de Monitoreo', url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1920&q=80' },
                      { name: 'Matriz Cyber Blue', url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1920&q=80' },
                      { name: 'Luz Neón Nocturna', url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1920&q=80' }
                    ].map(preset => (
                      <button
                        key={preset.name}
                        type="button"
                        onClick={() => setWallpaperUrlInput(preset.url)}
                        className="p-2 rounded-xl border border-white/5 bg-black/40 hover:bg-white/10 transition-all text-left group overflow-hidden"
                      >
                        <div
                          className="h-16 w-full rounded-lg bg-cover bg-center mb-1.5"
                          style={{ backgroundImage: `url(${preset.url})` }}
                        />
                        <span className="text-[11px] font-semibold text-slate-200 group-hover:text-cyan-300 block truncate">
                          {preset.name}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {wallpaperUrlInput && (
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-slate-400 block">Vista Previa:</span>
                    <div
                      className="h-44 w-full rounded-2xl bg-cover bg-center border border-white/15 relative overflow-hidden flex items-center justify-center"
                      style={{ backgroundImage: `url(${wallpaperUrlInput})` }}
                    >
                      <div className="absolute inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center">
                        <div className="liquid-glass px-4 py-2 rounded-xl text-xs font-bold text-white border border-white/20">
                          Vista de Terminal de Guardia
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl font-bold text-xs text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 transition-all shadow-[0_0_15px_rgba(6,182,212,0.35)]"
                >
                  Guardar Fondo para Guardias
                </button>
              </form>
            </div>
          )}

        </div>
      )}



      {/* Admin Add Store Modal */}
      {isNewStoreModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="liquid-glass-elevated rounded-3xl max-w-md w-full p-6 border border-white/15 shadow-2xl">
            <h3 className="text-base font-bold text-white pb-3 border-b border-white/10">
              Registrar Nueva Tienda / Puesto QR
            </h3>

            <form onSubmit={handleCreateStore} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Nombre de la Tienda / Sucursal:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Fermac - Sucursal Central Zona 1"
                  value={newStoreData.name}
                  onChange={e => setNewStoreData({ ...newStoreData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Empresa Asociada:
                </label>
                <select
                  value={newStoreData.companyId}
                  onChange={e => setNewStoreData({ ...newStoreData, companyId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                >
                  {companies.map(c => (
                    <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Enlace de Google Maps de la Tienda:
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://maps.google.com/?q=14.8348,-91.5181 o https://goo.gl/maps/..."
                  value={newStoreData.googleMapsUrl}
                  onChange={e => setNewStoreData({ ...newStoreData, googleMapsUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Dirección Descriptiva:
                </label>
                <input
                  type="text"
                  placeholder="Ej. 4ta Calle 12-40, Zona 1, Xela"
                  value={newStoreData.address}
                  onChange={e => setNewStoreData({ ...newStoreData, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewStoreModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300"
                >
                  Crear Tienda & Generar QR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
