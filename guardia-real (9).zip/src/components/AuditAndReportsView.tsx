import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Calendar, 
  Clock, 
  Building2, 
  User, 
  AlertTriangle, 
  CheckCircle2, 
  History, 
  RotateCcw, 
  Lock, 
  ArrowRight,
  Calculator,
  ShieldCheck,
  Check
} from 'lucide-react';
import { AuditLog, Company, Employee, AppUser } from '../types';
import { generateExcelReport, calculatePayrollRow, PayrollPeriodType } from '../utils/excelExport';
import { formatCurrencyGTQ, formatDate, formatDateTime, formatDPI } from '../utils/formatters';

interface AuditAndReportsViewProps {
  auditLogs: AuditLog[];
  employees: Employee[];
  companies: Company[];
  users: AppUser[];
  currentUser: AppUser;
}

export const AuditAndReportsView: React.FC<AuditAndReportsViewProps> = ({
  auditLogs,
  employees,
  companies,
  users,
  currentUser,
}) => {
  // Main view tab: 'PAYROLL' (Planilla Quincenal) | 'AUDIT_TRAIL' (Historial de Auditoría)
  const [subView, setSubView] = useState<'PAYROLL' | 'AUDIT_TRAIL'>('PAYROLL');

  // ==========================================
  // PAYROLL GENERATOR STATE
  // ==========================================
  const currentDate = new Date();
  const [payrollPeriodType, setPayrollPeriodType] = useState<PayrollPeriodType>('1RA_QUINCENA');
  const [selectedYear, setSelectedYear] = useState<number>(currentDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(currentDate.getMonth() + 1); // 1-12
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');
  const [payrollCompanyId, setPayrollCompanyId] = useState<string>('all');
  const [includeBonificacion, setIncludeBonificacion] = useState<boolean>(true);
  const [applyIGSS, setApplyIGSS] = useState<boolean>(true);

  // ==========================================
  // AUDIT LOGS FILTER STATE
  // ==========================================
  const [auditStartDate, setAuditStartDate] = useState('');
  const [auditEndDate, setAuditEndDate] = useState('');
  const [auditCompanyId, setAuditCompanyId] = useState('all');
  const [auditUserId, setAuditUserId] = useState('all');
  const [onlyCritical, setOnlyCritical] = useState(false);

  // Export state
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  // Permissions
  const canViewAudit = currentUser.role === 'ADMIN' || currentUser.permissions.canViewAuditLog;
  const canExport = currentUser.role === 'ADMIN' || currentUser.permissions.canExportExcel;

  const months = [
    { value: 1, label: 'Enero' },
    { value: 2, label: 'Febrero' },
    { value: 3, label: 'Marzo' },
    { value: 4, label: 'Abril' },
    { value: 5, label: 'Mayo' },
    { value: 6, label: 'Junio' },
    { value: 7, label: 'Julio' },
    { value: 8, label: 'Agosto' },
    { value: 9, label: 'Septiembre' },
    { value: 10, label: 'Octubre' },
    { value: 11, label: 'Noviembre' },
    { value: 12, label: 'Diciembre' },
  ];

  const companyMap = new Map<string, string>();
  companies.forEach(c => companyMap.set(c.id, c.name));

  // Filter employees for payroll preview
  const activePayrollEmployees = employees.filter(emp => {
    if (payrollCompanyId !== 'all' && emp.companyId !== payrollCompanyId) {
      return false;
    }
    return emp.status === 'ACTIVO';
  });

  // Calculate live preview payroll items
  const payrollRows = activePayrollEmployees.map(emp =>
    calculatePayrollRow(
      emp,
      payrollPeriodType,
      selectedYear,
      selectedMonth,
      customStartDate,
      customEndDate,
      includeBonificacion,
      applyIGSS
    )
  );

  // Summary totals for payroll preview
  const totalBaseSalary = payrollRows.reduce((sum, r) => sum + r.monthlySalary, 0);
  const totalOrdinario = payrollRows.reduce((sum, r) => sum + r.ordinarySalary, 0);
  const totalBonificacion = payrollRows.reduce((sum, r) => sum + r.bonificacionIncentivo, 0);
  const totalDevengado = payrollRows.reduce((sum, r) => sum + r.totalDevengado, 0);
  const totalIGSS = payrollRows.reduce((sum, r) => sum + r.descuentoIGSS, 0);
  const totalNetLiquido = payrollRows.reduce((sum, r) => sum + r.liquidoAPagar, 0);

  // Audit logs filtering
  const filteredLogs = auditLogs.filter(log => {
    if (auditStartDate && log.timestamp.slice(0, 10) < auditStartDate) return false;
    if (auditEndDate && log.timestamp.slice(0, 10) > auditEndDate) return false;
    if (auditCompanyId !== 'all' && log.companyId !== auditCompanyId) return false;
    if (auditUserId !== 'all' && log.userId !== auditUserId) return false;
    if (onlyCritical && !log.isCritical) return false;
    return true;
  });

  const handleExportPayrollExcel = () => {
    if (!canExport) return;
    try {
      setIsExporting(true);
      generateExcelReport(employees, auditLogs, companies, {
        periodType: payrollPeriodType,
        year: selectedYear,
        month: selectedMonth,
        startDate: payrollPeriodType === 'RANGO_PERSONALIZADO' ? customStartDate : undefined,
        endDate: payrollPeriodType === 'RANGO_PERSONALIZADO' ? customEndDate : undefined,
        companyId: payrollCompanyId,
        generatedBy: `${currentUser.name} (${currentUser.role})`,
      });
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 4500);
    } catch (err) {
      console.error('Error generating payroll Excel:', err);
    } finally {
      setIsExporting(false);
    }
  };

  if (!canViewAudit && subView === 'AUDIT_TRAIL') {
    return (
      <div className="liquid-glass-elevated rounded-3xl p-12 text-center max-w-xl mx-auto my-12 border border-white/10">
        <Lock className="w-12 h-12 text-slate-500 mx-auto mb-4" />
        <h2 className="text-lg font-bold text-white">Acceso Restringido a Auditoría</h2>
        <p className="text-sm text-slate-400 mt-2">
          Tu cuenta de invitado ({currentUser.name}) no tiene permisos para ver la bitácora de auditoría.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Top Header & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <span>Planilla de Pagos Quincenal & Auditoría</span>
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Generador de planilla contable guatemalteca (IGSS, Bonificación Decreto 37-2001, Líquido) y exportación a Excel.
          </p>
        </div>

        {/* View Toggle (Planilla Quincenal vs Bitácora de Cambios) */}
        <div className="flex items-center bg-black/50 p-1.5 rounded-2xl border border-white/10 shrink-0">
          <button
            onClick={() => setSubView('PAYROLL')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              subView === 'PAYROLL'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>Generar Planilla Quincenal</span>
          </button>
          <button
            onClick={() => setSubView('AUDIT_TRAIL')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              subView === 'AUDIT_TRAIL'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Historial de Auditoría</span>
          </button>
        </div>
      </div>

      {exportSuccess && (
        <div className="p-3.5 bg-emerald-500/15 text-emerald-300 text-xs rounded-2xl border border-emerald-500/30 flex items-center gap-2.5 animate-in fade-in shadow-[0_0_20px_rgba(16,185,129,0.2)]">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <span className="font-bold block">¡Planilla de Pagos descargada con éxito en Excel (.xlsx)!</span>
            <span className="text-[11px] text-emerald-400/80">Incluye sueldo quincenal, Bonificación Dto. 37-2001, retención IGSS laboral 4.83%, columna de firmas, y la hoja de dispersión bancaria.</span>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUBVIEW 1: PLANILLA DE PAGOS QUINCENAL / MENSUAL */}
      {/* ======================================================== */}
      {subView === 'PAYROLL' && (
        <div className="space-y-6">
          
          {/* Controls Panel */}
          <div className="liquid-glass p-5 rounded-3xl border border-white/10 space-y-4">
            
            {/* Step 1: Select Period Type */}
            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-cyan-400 mb-2.5 block">
                1. Selección del Período de Pago
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { id: '1RA_QUINCENA', label: '1ra Quincena', sub: '01 al 15 del mes (15 días)' },
                  { id: '2DA_QUINCENA', label: '2da Quincena', sub: '16 al fin de mes (13-16 días)' },
                  { id: 'MES_COMPLETO', label: 'Mes Completo', sub: '01 al fin de mes (30 días)' },
                  { id: 'RANGO_PERSONALIZADO', label: 'Rango Específico', sub: 'Días personalizados' },
                ].map(p => {
                  const isSelected = payrollPeriodType === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setPayrollPeriodType(p.id as PayrollPeriodType)}
                      className={`text-left p-3 rounded-2xl border transition-all ${
                        isSelected
                          ? 'bg-cyan-500/15 border-cyan-400/40 text-white shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                          : 'bg-black/30 border-white/5 text-slate-400 hover:border-white/15'
                      }`}
                    >
                      <span className={`text-xs font-bold block ${isSelected ? 'text-cyan-300' : 'text-slate-200'}`}>
                        {p.label}
                      </span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {p.sub}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Month, Year, Custom Range & Company */}
            <div className="pt-3 border-t border-white/5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              
              {/* Month Selector */}
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Mes de la Planilla
                </label>
                <select
                  value={selectedMonth}
                  onChange={e => setSelectedMonth(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                >
                  {months.map(m => (
                    <option key={m.value} value={m.value} className="bg-slate-900 text-white">
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Year Selector */}
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Año
                </label>
                <select
                  value={selectedYear}
                  onChange={e => setSelectedYear(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono"
                >
                  {[2025, 2026, 2027, 2028].map(y => (
                    <option key={y} value={y} className="bg-slate-900 text-white">
                      {y}
                    </option>
                  ))}
                </select>
              </div>

              {/* Company Filter */}
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Empresa Emisora
                </label>
                <select
                  value={payrollCompanyId}
                  onChange={e => setPayrollCompanyId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                >
                  <option value="all" className="bg-slate-900 text-white">Todas las empresas ({companies.length})</option>
                  {companies.map(c => (
                    <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Primary Action Button */}
              <div className="flex flex-col justify-end">
                {canExport ? (
                  <button
                    onClick={handleExportPayrollExcel}
                    disabled={isExporting}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs text-slate-950 bg-gradient-to-r from-emerald-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] disabled:opacity-50"
                  >
                    <Download className="w-4 h-4 text-slate-950" />
                    <span>{isExporting ? 'Generando...' : 'Descargar Planilla en Excel'}</span>
                  </button>
                ) : (
                  <div className="text-center p-2 rounded-xl liquid-glass text-[11px] text-slate-400 border border-white/5">
                    Modo invitado: Descarga bloqueada
                  </div>
                )}
              </div>

            </div>

            {/* Custom Range Picker (Visible only if RANGO_PERSONALIZADO) */}
            {payrollPeriodType === 'RANGO_PERSONALIZADO' && (
              <div className="pt-3 border-t border-white/5 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-semibold text-cyan-400 mb-1">
                    Día Inicial del Rango Específico
                  </label>
                  <input
                    type="date"
                    required
                    value={customStartDate}
                    onChange={e => setCustomStartDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-cyan-400 mb-1">
                    Día Final del Rango Específico
                  </label>
                  <input
                    type="date"
                    required
                    value={customEndDate}
                    onChange={e => setCustomEndDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                  />
                </div>
              </div>
            )}

            {/* Legal Guatemala Payroll Toggles */}
            <div className="pt-3 border-t border-white/5 flex flex-wrap items-center gap-6 text-xs text-slate-300">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeBonificacion}
                  onChange={e => setIncludeBonificacion(e.target.checked)}
                  className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400"
                />
                <span>Incluir Bonificación Incentivo Dto. 37-2001 (Q125.00 quincenal)</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={applyIGSS}
                  onChange={e => setApplyIGSS(e.target.checked)}
                  className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400"
                />
                <span>Aplicar Retención Laboral IGSS (4.83% sobre ordinario)</span>
              </label>
            </div>

          </div>

          {/* Payroll Financial Summary Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="liquid-glass p-3.5 rounded-2xl border border-white/10">
              <span className="text-[10px] uppercase font-semibold text-slate-400 block">Personal a Pagar</span>
              <span className="text-lg font-bold text-white mt-0.5 block tabular-nums">
                {payrollRows.length} Colaboradores
              </span>
            </div>

            <div className="liquid-glass p-3.5 rounded-2xl border border-white/10">
              <span className="text-[10px] uppercase font-semibold text-slate-400 block">Base Mensual</span>
              <span className="text-lg font-bold text-slate-300 mt-0.5 block tabular-nums">
                {formatCurrencyGTQ(totalBaseSalary)}
              </span>
            </div>

            <div className="liquid-glass p-3.5 rounded-2xl border border-white/10">
              <span className="text-[10px] uppercase font-semibold text-cyan-400 block">Sueldo Quincenal</span>
              <span className="text-lg font-bold text-cyan-300 mt-0.5 block tabular-nums">
                {formatCurrencyGTQ(totalOrdinario)}
              </span>
            </div>

            <div className="liquid-glass p-3.5 rounded-2xl border border-white/10">
              <span className="text-[10px] uppercase font-semibold text-emerald-400 block">Bonificaciones</span>
              <span className="text-lg font-bold text-emerald-300 mt-0.5 block tabular-nums">
                +{formatCurrencyGTQ(totalBonificacion)}
              </span>
            </div>

            <div className="liquid-glass p-3.5 rounded-2xl border border-white/10">
              <span className="text-[10px] uppercase font-semibold text-rose-400 block">Retención IGSS 4.83%</span>
              <span className="text-lg font-bold text-rose-300 mt-0.5 block tabular-nums">
                -{formatCurrencyGTQ(totalIGSS)}
              </span>
            </div>

            <div className="liquid-glass p-3.5 rounded-2xl border border-cyan-400/30 bg-cyan-950/20 shadow-[0_0_20px_rgba(6,182,212,0.15)]">
              <span className="text-[10px] uppercase font-bold text-cyan-300 block">LÍQUIDO A DESEMBOLSAR</span>
              <span className="text-lg font-extrabold text-cyan-200 mt-0.5 block tabular-nums">
                {formatCurrencyGTQ(totalNetLiquido)}
              </span>
            </div>
          </div>

          {/* Live Payroll Preview Table */}
          <div className="liquid-glass rounded-3xl overflow-hidden border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
                <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                  Vista Previa de la Planilla: {payrollRows[0]?.periodLabel || 'Período'}
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                Formato Oficial de Nómina Laboral Guatemala
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-black/50 text-slate-400 text-[11px] font-semibold uppercase tracking-wider border-b border-white/10">
                  <tr>
                    <th className="py-3 px-4">No.</th>
                    <th className="py-3 px-4">Colaborador / DPI</th>
                    <th className="py-3 px-4">Empresa & Puesto</th>
                    <th className="py-3 px-4 text-right">Base Mensual</th>
                    <th className="py-3 px-4 text-right text-cyan-300">Sueldo Quincena</th>
                    <th className="py-3 px-4 text-right text-emerald-300">Bonif. Ley</th>
                    <th className="py-3 px-4 text-right text-rose-400">IGSS (4.83%)</th>
                    <th className="py-3 px-4 text-right font-bold text-white">Líquido a Pagar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {payrollRows.map((row, idx) => (
                    <tr key={row.employee.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-3 px-4 text-slate-400 font-mono">
                        {idx + 1}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{row.employee.name}</div>
                        <div className="font-mono text-cyan-400 text-[11px] mt-0.5">DPI: {formatDPI(row.employee.dpi)}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-slate-300">{row.employee.position}</div>
                        <div className="text-slate-400 text-[11px]">{companyMap.get(row.employee.companyId)}</div>
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums text-slate-300">
                        {formatCurrencyGTQ(row.monthlySalary)}
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums font-semibold text-cyan-300">
                        {formatCurrencyGTQ(row.ordinarySalary)}
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums text-emerald-300">
                        {formatCurrencyGTQ(row.bonificacionIncentivo)}
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums">
                        {row.employee.appliesIGSS !== false ? (
                          <span className="text-rose-400">-{formatCurrencyGTQ(row.descuentoIGSS)}</span>
                        ) : (
                          <span className="text-amber-400 text-[10px] font-semibold bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                            Exento (Q0.00)
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums font-bold text-white text-sm">
                        {formatCurrencyGTQ(row.liquidoAPagar)}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-black/60 border-t border-white/10 font-bold text-xs">
                  <tr>
                    <td colSpan={3} className="py-3.5 px-4 text-white uppercase">
                      Totales de la Planilla ({payrollRows.length} Colaboradores)
                    </td>
                    <td className="py-3.5 px-4 text-right tabular-nums text-slate-300">
                      {formatCurrencyGTQ(totalBaseSalary)}
                    </td>
                    <td className="py-3.5 px-4 text-right tabular-nums text-cyan-300">
                      {formatCurrencyGTQ(totalOrdinario)}
                    </td>
                    <td className="py-3.5 px-4 text-right tabular-nums text-emerald-300">
                      {formatCurrencyGTQ(totalBonificacion)}
                    </td>
                    <td className="py-3.5 px-4 text-right tabular-nums text-rose-400">
                      -{formatCurrencyGTQ(totalIGSS)}
                    </td>
                    <td className="py-3.5 px-4 text-right tabular-nums text-cyan-200 text-sm">
                      {formatCurrencyGTQ(totalNetLiquido)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* ======================================================== */}
      {/* SUBVIEW 2: HISTORIAL DE AUDITORÍA CRONOLÓGICO */}
      {/* ======================================================== */}
      {subView === 'AUDIT_TRAIL' && (
        <div className="space-y-6">
          
          {/* Filter Panel */}
          <div className="liquid-glass p-5 rounded-3xl border border-white/10 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Fecha Inicial
                </label>
                <input
                  type="date"
                  value={auditStartDate}
                  onChange={e => setAuditStartDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Fecha Final
                </label>
                <input
                  type="date"
                  value={auditEndDate}
                  onChange={e => setAuditEndDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Usuario Modificador
                </label>
                <select
                  value={auditUserId}
                  onChange={e => setAuditUserId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                >
                  <option value="all" className="bg-slate-900 text-white">Todos los usuarios</option>
                  {users.map(u => (
                    <option key={u.id} value={u.id} className="bg-slate-900 text-white">
                      {u.name} ({u.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Empresa
                </label>
                <select
                  value={auditCompanyId}
                  onChange={e => setAuditCompanyId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                >
                  <option value="all" className="bg-slate-900 text-white">Todas las empresas</option>
                  {companies.map(c => (
                    <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

            </div>

            <div className="pt-2 border-t border-white/5 flex items-center justify-between flex-wrap gap-3 text-xs">
              <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                <input
                  type="checkbox"
                  checked={onlyCritical}
                  onChange={e => setOnlyCritical(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400"
                />
                <span>Mostrar solo cambios críticos (Salarios y bajas de personal)</span>
              </label>

              {(auditStartDate || auditEndDate || auditCompanyId !== 'all' || auditUserId !== 'all' || onlyCritical) && (
                <button
                  onClick={() => {
                    setAuditStartDate('');
                    setAuditEndDate('');
                    setAuditCompanyId('all');
                    setAuditUserId('all');
                    setOnlyCritical(false);
                  }}
                  className="flex items-center gap-1 text-slate-400 hover:text-white"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Restablecer filtros
                </button>
              )}
            </div>
          </div>

          {/* Audit Logs List */}
          <div className="space-y-3">
            {filteredLogs.map(log => (
              <div
                key={log.id}
                className={`liquid-glass rounded-2xl p-4 transition-all ${
                  log.isCritical ? 'border-amber-500/30 bg-amber-500/5' : 'border-white/10'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-white/5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-white text-xs">
                      {log.summary}
                    </span>
                    {log.isCritical && (
                      <span className="text-[10px] font-bold text-amber-300 bg-amber-500/20 border border-amber-500/30 px-2 py-0.5 rounded-full">
                        Crítico
                      </span>
                    )}
                  </div>

                  <div className="text-[11px] text-slate-400 flex items-center gap-1.5 whitespace-nowrap">
                    <Clock className="w-3 h-3 text-slate-500" />
                    <span className="tabular-nums">{formatDateTime(log.timestamp)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-2 flex-wrap">
                  <div className="flex items-center gap-1">
                    <User className="w-3 h-3 text-cyan-400" />
                    <span>Por: <strong className="text-white">{log.userName}</strong> ({log.userRole})</span>
                  </div>

                  {log.companyName && (
                    <>
                      <span aria-hidden="true">·</span>
                      <div className="flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-slate-500" />
                        <span>{log.companyName}</span>
                      </div>
                    </>
                  )}
                </div>

                {log.changes && log.changes.length > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-white/5 space-y-1">
                    {log.changes.map((ch, idx) => (
                      <div 
                        key={idx}
                        className="flex flex-col sm:flex-row sm:items-center justify-between text-[11px] bg-black/40 p-2 rounded-xl gap-1 border border-white/5"
                      >
                        <span className="font-semibold text-slate-300">
                          {ch.label || ch.field}:
                        </span>
                        <div className="flex items-center gap-2 font-mono">
                          <span className="text-rose-400 line-through">
                            {ch.oldValue !== null && ch.oldValue !== undefined ? String(ch.oldValue) : '(Vacío)'}
                          </span>
                          <ArrowRight className="w-3 h-3 text-slate-500 shrink-0" />
                          <span className="text-emerald-400 font-bold">
                            {ch.newValue !== null && ch.newValue !== undefined ? String(ch.newValue) : '(Vacío)'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

        </div>
      )}

    </div>
  );
};
