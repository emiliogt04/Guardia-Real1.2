import React, { useState, useRef } from 'react';
import { 
  Settings, 
  KeyRound, 
  Shield, 
  Users, 
  Save, 
  CheckCircle2, 
  AlertCircle, 
  Building, 
  DollarSign, 
  Image as ImageIcon, 
  Upload, 
  Trash2, 
  Download, 
  ShieldAlert, 
  Plus,
  Search,
  Shirt,
  Package,
  Tag,
  Filter,
  Sparkles,
  Layers,
  Edit2,
  Table,
  LayoutGrid,
  Check,
  X,
  ExternalLink
} from 'lucide-react';
import { AppUser, SystemSecurityConfig, UserPermissions, UniformInventoryItem } from '../types';
import { PermissionsManagementView } from './PermissionsManagementView';

interface SettingsViewProps {
  currentUser: AppUser;
  securityConfig: SystemSecurityConfig | null;
  onUpdateSecurityConfig: (config: Partial<SystemSecurityConfig>) => Promise<void>;
  users: AppUser[];
  onUpdatePermissions: (userId: string, newPermissions: UserPermissions) => Promise<void>;
  onUpdateUserRoleAndCode?: (userId: string, data: { role: 'ADMIN' | 'GUEST' | 'GUARD'; personalAccessCode?: string }) => Promise<void>;
  onCreateUser?: (userData: any) => Promise<void>;
  onSwitchUser?: (user: AppUser) => void;
  onDeleteUser?: (userId: string, reason?: string) => Promise<void>;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentUser,
  securityConfig,
  onUpdateSecurityConfig,
  users,
  onUpdatePermissions,
  onUpdateUserRoleAndCode,
  onCreateUser,
  onSwitchUser,
  onDeleteUser,
}) => {
  const isAdmin = currentUser.role === 'ADMIN';

  const [adminCode, setAdminCode] = useState(securityConfig?.adminAccessCode || '2004');
  const [guardBaseSalary, setGuardBaseSalary] = useState(String(securityConfig?.guardBaseSalary || 4200));
  const [igssPercent, setIgssPercent] = useState(String(securityConfig?.igssPercentage || 4.83));
  const [guardWallpaper, setGuardWallpaper] = useState(securityConfig?.guardWallpaperUrl || '');
  const [wallpaperFileName, setWallpaperFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [uniformPrices, setUniformPrices] = useState({
    gorra: securityConfig?.uniformPrices?.gorra ?? 60,
    pantalon: securityConfig?.uniformPrices?.pantalon ?? 180,
    botas: securityConfig?.uniformPrices?.botas ?? 250,
    camisaCafe: securityConfig?.uniformPrices?.camisaCafe ?? 120,
    playeraPolo: securityConfig?.uniformPrices?.playeraPolo ?? 90,
  });
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [isExporting, setIsExporting] = useState(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [resetAdminPin, setResetAdminPin] = useState('');
  const [resetError, setResetError] = useState<string | null>(null);
  const [isResetting, setIsResetting] = useState(false);

  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importAdminPin, setImportAdminPin] = useState('');
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importFileContent, setImportFileContent] = useState<any | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [isImporting, setIsImporting] = useState(false);

  const handleBackupFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportFile(file);
    setImportError(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (!json || typeof json !== 'object' || (!json.companies && !json.employees)) {
          throw new Error('El archivo seleccionado no es un respaldo válido de la aplicación.');
        }
        setImportFileContent(json);
      } catch (err: any) {
        setImportError(err.message || 'Error al leer el archivo JSON.');
        setImportFile(null);
        setImportFileContent(null);
      }
    };
    reader.readAsText(file);
  };

  const handleImportBackupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!importAdminPin.trim()) {
      setImportError('Ingresa el PIN de Administrador para confirmar la importación.');
      return;
    }
    if (!importFileContent) {
      setImportError('Selecciona un archivo JSON de respaldo válido primero.');
      return;
    }

    try {
      setIsImporting(true);
      setImportError(null);
      const res = await fetch('/api/import-backup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': currentUser.id,
        },
        body: JSON.stringify({
          adminAccessCode: importAdminPin.trim(),
          backupData: importFileContent,
        }),
      });
      const result = await res.json();
      if (!res.ok) {
        throw new Error(result.error || 'Error al importar el respaldo.');
      }
      alert('¡Respaldo importado y restaurado con éxito! La aplicación se recargará.');
      window.location.reload();
    } catch (err: any) {
      setImportError(err.message || 'Error al importar el respaldo.');
    } finally {
      setIsImporting(false);
    }
  };

  const [inventoryList, setInventoryList] = useState<UniformInventoryItem[]>(securityConfig?.inventoryItems || []);
  const [isAddingInventory, setIsAddingInventory] = useState(false);
  const [inventoryViewMode, setInventoryViewMode] = useState<'CARDS' | 'TABLE'>('TABLE');
  const [newItemName, setNewItemName] = useState('');
  const [newItemStock, setNewItemStock] = useState('20');
  const [newItemPrice, setNewItemPrice] = useState('100');
  const [newItemDesc, setNewItemDesc] = useState('');
  const [newItemCategory, setNewItemCategory] = useState<string>('Prenda / Uniforme');
  const [inventorySearchQuery, setInventorySearchQuery] = useState('');
  const [selectedInventoryCategory, setSelectedInventoryCategory] = useState('TODOS');
  const [isSavingAllPrices, setIsSavingAllPrices] = useState(false);
  const [recentlyAddedItemId, setRecentlyAddedItemId] = useState<string | null>(null);
  const [editingFullItem, setEditingFullItem] = useState<UniformInventoryItem | null>(null);

  // Popular presets for instant 1-click addition of new security gear
  const INVENTORY_PRESETS = [
    { name: 'Camisa Café Manga Larga', price: 120, stock: 30, category: 'Prenda / Uniforme', desc: 'Camisa reglamentaria color café con charreteras institucionales' },
    { name: 'Camisa Café Manga Corta', price: 110, stock: 30, category: 'Prenda / Uniforme', desc: 'Camisa operativa color café para clima cálido' },
    { name: 'Pantalón Comando Táctico', price: 180, stock: 25, category: 'Prenda / Uniforme', desc: 'Pantalón táctico comando 6 bolsillos con refuerzo en rodillas' },
    { name: 'Botas Militares de Asalto', price: 250, stock: 20, category: 'Calzado', desc: 'Botas de combate tácticas con suela antideslizante dieléctrica' },
    { name: 'Gorra Institucional Bordada', price: 60, stock: 35, category: 'Prenda / Uniforme', desc: 'Gorra táctica con escudo oficial bordado en alta definición' },
    { name: 'Playera Polo Institucional', price: 90, stock: 35, category: 'Prenda / Uniforme', desc: 'Playera tipo polo con bordado corporativo de seguridad' },
    { name: 'Chumpa Térmica Impermeable', price: 220, stock: 20, category: 'Prenda / Uniforme', desc: 'Chumpa para turno nocturno impermeable contra lluvia y frío extremo' },
    { name: 'Chaleco Táctico Porta-equipo', price: 280, stock: 15, category: 'Equipo Táctico', desc: 'Chaleco porta-equipo reforzado con cinta reflectiva de alta visibilidad' },
    { name: 'Cinturón Táctico / Fornitura', price: 75, stock: 30, category: 'Equipo Táctico', desc: 'Cinturón reforzado con hebilla de alta resistencia para accesorios' },
    { name: 'Linterna Táctica Recargable', price: 85, stock: 25, category: 'Equipo Táctico', desc: 'Linterna LED de alta potencia con batería recargable USB' },
    { name: 'Silbato de Metal con Cordón', price: 35, stock: 40, category: 'Accesorio', desc: 'Silbato metálico de advertencia con cordón de mando reglamentario' },
    { name: 'Radio Comunicador Walkie-Talkie', price: 350, stock: 10, category: 'Equipo Táctico', desc: 'Radio portátil UHF/VHF con auricular de seguridad' },
    { name: 'Esposas Metálicas con Llave', price: 130, stock: 15, category: 'Equipo Táctico', desc: 'Esposas de acero inoxidable reglamentarias de seguridad' },
    { name: 'Zapatos Tácticos de Charol', price: 240, stock: 15, category: 'Calzado', desc: 'Calzado formal de vestir para escoltas y seguridad ejecutiva' },
  ];

  const handleApplyPreset = (preset: typeof INVENTORY_PRESETS[0]) => {
    setNewItemName(preset.name);
    setNewItemPrice(String(preset.price));
    setNewItemStock(String(preset.stock));
    setNewItemCategory(preset.category);
    setNewItemDesc(preset.desc);
    setIsAddingInventory(true);
  };

  React.useEffect(() => {
    if (securityConfig?.inventoryItems) {
      setInventoryList(securityConfig.inventoryItems);
    }
  }, [securityConfig]);

  const handleAddInventoryItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    // Verificar si ya existe un artículo con nombre idéntico para evitar confusiones
    const existing = inventoryList.find(i => i.name.toLowerCase() === newItemName.trim().toLowerCase());
    if (existing) {
      if (!window.confirm(`Ya existe un artículo llamado "${existing.name}" en el catálogo (Precio: Q${existing.price}, Stock: ${existing.stock}). ¿Deseas agregar este nuevo artículo de todos modos?`)) {
        return;
      }
    }

    try {
      setIsSubmitting(true);
      setErrorMsg(null);
      const res = await fetch('/api/security/inventory', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': currentUser.id,
        },
        body: JSON.stringify({
          name: newItemName.trim(),
          stock: Number(newItemStock) || 0,
          price: Number(newItemPrice) || 0,
          category: newItemCategory,
          description: newItemDesc.trim(),
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Error al agregar artículo');
      }
      const responseData = await res.json();
      const createdItem = responseData.item || responseData;
      const updatedList = responseData.inventoryItems || [...inventoryList, createdItem];
      
      setInventoryList(updatedList);
      setRecentlyAddedItemId(createdItem.id);

      // Sincronizar precios de uniformes base si coincide
      const newUniformPrices = responseData.uniformPrices || {
        ...uniformPrices,
        gorra: createdItem.name.toLowerCase().includes('gorra') ? createdItem.price : uniformPrices.gorra,
        pantalon: (createdItem.name.toLowerCase().includes('pantalon') || createdItem.name.toLowerCase().includes('pantalón')) ? createdItem.price : uniformPrices.pantalon,
        botas: createdItem.name.toLowerCase().includes('bota') ? createdItem.price : uniformPrices.botas,
        camisaCafe: createdItem.name.toLowerCase().includes('camisa') ? createdItem.price : uniformPrices.camisaCafe,
        playeraPolo: (createdItem.name.toLowerCase().includes('polo') || createdItem.name.toLowerCase().includes('playera')) ? createdItem.price : uniformPrices.playeraPolo,
      };
      setUniformPrices(newUniformPrices);

      // Sincronizar inmediatamente en configuración general y en App.tsx para que los descuentos lo vean al instante
      await onUpdateSecurityConfig({
        inventoryItems: updatedList,
        uniformPrices: newUniformPrices,
      });

      setNewItemName('');
      setNewItemStock('20');
      setNewItemPrice('100');
      setNewItemDesc('');
      setIsAddingInventory(false);
      setSuccessMsg(`¡Artículo "${createdItem.name}" añadido exitosamente a Q${Number(createdItem.price).toFixed(2)} (${createdItem.stock} unidades)! Se integró en la modificación de precios y ya está disponible para entregas y descuentos en nómina de los colaboradores.`);
      setTimeout(() => {
        setSuccessMsg(null);
        setRecentlyAddedItemId(null);
      }, 5000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al agregar inventario.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateItemStockOrPrice = async (id: string, newStock: number, newPrice: number, updatedFields?: { name?: string; description?: string; category?: string }) => {
    try {
      const res = await fetch(`/api/security/inventory/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': currentUser.id,
        },
        body: JSON.stringify({ 
          stock: newStock, 
          price: newPrice,
          ...(updatedFields || {})
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Error al actualizar inventario');
      }
      const updatedData = await res.json();
      const updatedItem = updatedData.item || updatedData;
      const updatedList = updatedData.inventoryItems || inventoryList.map(i => i.id === id ? { ...i, stock: newStock, price: newPrice, ...(updatedFields || {}) } : i);
      setInventoryList(updatedList);

      const newUniformPrices = updatedData.uniformPrices || uniformPrices;
      setUniformPrices(newUniformPrices);

      // Notificar al estado central del sistema
      await onUpdateSecurityConfig({
        inventoryItems: updatedList,
        uniformPrices: newUniformPrices,
      });

      setEditingFullItem(null);
    } catch (err: any) {
      alert(err.message || 'Error al actualizar inventario');
    }
  };

  const handleSaveAllInventoryPrices = async () => {
    try {
      setIsSavingAllPrices(true);
      setErrorMsg(null);
      const res = await fetch('/api/security/inventory/bulk', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': currentUser.id,
        },
        body: JSON.stringify({ items: inventoryList }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Error al guardar precios');
      }
      const data = await res.json();
      const finalItems = data.items || data.inventoryItems || inventoryList;
      setInventoryList(finalItems);

      const finalPrices = data.uniformPrices || {
        gorra: Number(uniformPrices.gorra) || 60,
        pantalon: Number(uniformPrices.pantalon) || 180,
        botas: Number(uniformPrices.botas) || 250,
        camisaCafe: Number(uniformPrices.camisaCafe) || 120,
        playeraPolo: Number(uniformPrices.playeraPolo) || 90,
      };
      setUniformPrices(finalPrices);

      await onUpdateSecurityConfig({
        inventoryItems: finalItems,
        uniformPrices: finalPrices,
      });
      setSuccessMsg('¡Todos los precios y existencias del inventario fueron guardados y sincronizados exitosamente con nómina y descuentos!');
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al guardar precios del inventario');
    } finally {
      setIsSavingAllPrices(false);
    }
  };

  const handleDeleteInventoryItem = async (id: string, name: string) => {
    if (!window.confirm(`¿Deseas eliminar el artículo "${name}" del inventario? Esta acción lo removerá también de la selección de descuentos a empleados.`)) return;
    try {
      const res = await fetch(`/api/security/inventory/${id}`, {
        method: 'DELETE',
        headers: {
          'x-user-id': currentUser.id,
        },
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Error al eliminar artículo');
      }
      const data = await res.json();
      const updatedList = data.inventoryItems || inventoryList.filter(i => i.id !== id);
      setInventoryList(updatedList);
      
      await onUpdateSecurityConfig({
        inventoryItems: updatedList,
        uniformPrices,
      });

      setSuccessMsg(`Artículo "${name}" eliminado del inventario y del catálogo de descuentos.`);
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err: any) {
      alert(err.message || 'Error al eliminar artículo');
    }
  };

  const handleExportAllData = async () => {
    if (!isAdmin) return;
    try {
      setIsExporting(true);
      setErrorMsg(null);
      const res = await fetch('/api/export-backup', {
        headers: {
          'x-user-id': currentUser.id,
        },
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Error al exportar respaldo.');
      }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `guardia_real_backup_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      setSuccessMsg('Respaldo completo de la aplicación descargado con éxito.');
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al descargar respaldo.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleResetAppData = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetAdminPin.trim()) {
      setResetError('Ingresa el PIN de Administrador para confirmar.');
      return;
    }
    try {
      setIsResetting(true);
      setResetError(null);
      const res = await fetch('/api/reset-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': currentUser.id,
        },
        body: JSON.stringify({ adminAccessCode: resetAdminPin.trim() }),
      });
      const result = await res.json();
      if (!res.ok) {
        throw new Error(result.error || 'PIN incorrecto o error al borrar datos.');
      }
      alert('¡Todos los datos de la aplicación han sido borrados y restablecidos con éxito!');
      window.location.reload();
    } catch (err: any) {
      setResetError(err.message || 'Error al borrar los datos.');
    } finally {
      setIsResetting(false);
    }
  };

  const handleWallpaperFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Por favor selecciona un archivo de imagen válido desde tu galería (PNG, JPG, WEBP).');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      setErrorMsg('La imagen seleccionada supera los 15MB. Elige una imagen más liviana.');
      return;
    }

    setWallpaperFileName(file.name);
    setErrorMsg(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setGuardWallpaper(result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      setErrorMsg('Solo el administrador puede modificar la configuración del sistema.');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg(null);
      await onUpdateSecurityConfig({
        adminAccessCode: adminCode.trim(),
        guardBaseSalary: Number(guardBaseSalary) || 4200,
        igssPercentage: Number(igssPercent) || 4.83,
        guardWallpaperUrl: guardWallpaper.trim(),
        uniformPrices: {
          gorra: Number(uniformPrices.gorra) || 60,
          pantalon: Number(uniformPrices.pantalon) || 180,
          botas: Number(uniformPrices.botas) || 250,
          camisaCafe: Number(uniformPrices.camisaCafe) || 120,
          playeraPolo: Number(uniformPrices.playeraPolo) || 90,
        },
        inventoryItems: inventoryList,
      });
      setSuccessMsg('Configuración de Administrador, Sueldo de Guardias, Catálogo de Inventario y Precios guardada con éxito.');
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al guardar la configuración.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in pb-12">
      
      {/* Header */}
      <div className="liquid-glass p-6 rounded-3xl border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Settings className="w-6 h-6 text-cyan-400" />
            <span>Configuración General & Control de Permisos</span>
          </h1>
          <p className="text-xs text-slate-300 font-medium mt-1">
            Administra la contraseña de acceso, sueldo base unificado de guardias, IGSS, precios de uniformes y el control integral de permisos.
          </p>
        </div>
      </div>

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2.5">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="font-bold">{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
          <span className="font-bold">{errorMsg}</span>
        </div>
      )}

      {/* Admin Password & Salary Config Panel */}
      {isAdmin ? (
        <form onSubmit={handleSaveSettings} className="liquid-glass p-6 rounded-3xl border border-white/10 space-y-6">
          <h2 className="text-sm font-black uppercase tracking-wider text-cyan-300 flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-cyan-400" />
            <span>Credenciales de Administrador & Parámetros Salariales</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            {/* Admin Password / Access Code */}
            <div>
              <label className="block font-bold text-slate-200 mb-1.5 flex items-center justify-between">
                <span>Código PIN de Inicio de Sesión (Administrador)</span>
                <span className="text-[10px] text-cyan-400 font-mono font-bold bg-cyan-500/10 px-1.5 py-0.5 rounded border border-cyan-500/20">
                  Acceso Total
                </span>
              </label>
              <input
                type="text"
                value={adminCode}
                onChange={e => setAdminCode(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs font-mono font-bold text-cyan-300 bg-black/50 border border-white/10"
                placeholder="Ej. 2004 o nuevo PIN"
              />
              <span className="text-[10px] text-amber-300/90 mt-1 block leading-tight font-medium">
                ⚠️ Al guardar un nuevo PIN, el PIN anterior se eliminará permanentemente y solo el nuevo PIN funcionará para ingresar al sistema.
              </span>
            </div>

            {/* Guard Base Salary */}
            <div>
              <label className="block font-bold text-slate-200 mb-1.5">
                Sueldo Base Unificado (Guardias) (Q)
              </label>
              <input
                type="number"
                step="0.01"
                value={guardBaseSalary}
                onChange={e => setGuardBaseSalary(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs font-mono font-bold text-white bg-black/50 border border-white/10"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Sueldo mensual asignado por defecto para todos los guardias de seguridad.
              </span>
            </div>

            {/* IGSS Percentage */}
            <div>
              <label className="block font-bold text-slate-200 mb-1.5">
                Porcentaje IGSS Laboral (%)
              </label>
              <input
                type="number"
                step="0.01"
                value={igssPercent}
                onChange={e => setIgssPercent(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs font-mono font-bold text-white bg-black/50 border border-white/10"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Retención laboral aplicable (por defecto 4.83%).
              </span>
            </div>
          </div>

          {/* SECCIÓN: CATÁLOGO DE INVENTARIO Y MODIFICACIÓN DE PRECIOS */}
          <div className="pt-4 border-t border-white/10 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-amber-300 flex items-center gap-2">
                  <Package className="w-4 h-4 text-amber-400" />
                  <span>Catálogo de Inventario & Modificación de Precios</span>
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Gestiona precios unitarios y existencias. Cada nuevo artículo que crees se añade automáticamente a esta lista y queda inmediatamente disponible para entregas y descuentos en nómina de los colaboradores.
                </p>
              </div>

              {isAdmin && (
                <div className="flex flex-wrap items-center gap-2">
                  {/* View Mode Toggle: Table vs Cards */}
                  <div className="flex items-center p-0.5 bg-black/60 rounded-xl border border-white/10 text-xs">
                    <button
                      type="button"
                      onClick={() => setInventoryViewMode('TABLE')}
                      className={`px-2.5 py-1.5 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-all ${
                        inventoryViewMode === 'TABLE'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                      title="Vista en tabla para modificación rápida de precios"
                    >
                      <Table className="w-3.5 h-3.5" />
                      <span>Tabla de Precios</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setInventoryViewMode('CARDS')}
                      className={`px-2.5 py-1.5 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-all ${
                        inventoryViewMode === 'CARDS'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                      title="Vista en tarjetas con controles individuales"
                    >
                      <LayoutGrid className="w-3.5 h-3.5" />
                      <span>Tarjetas</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsAddingInventory(!isAddingInventory)}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs hover:from-amber-400 hover:to-orange-400 transition-all shadow-md flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isAddingInventory ? 'Cerrar Formulario' : 'Crear Nuevo Artículo'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveAllInventoryPrices}
                    disabled={isSavingAllPrices}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs hover:from-emerald-400 hover:to-teal-400 transition-all shadow-md flex items-center gap-1.5 disabled:opacity-50"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isSavingAllPrices ? 'Guardando...' : 'Guardar Todos los Precios'}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Formulario Mejorado para Crear Nuevo Artículo de Inventario (Solo Admin) */}
            {isAdmin && isAddingInventory && (
              <div className="p-4 sm:p-5 rounded-2xl bg-amber-950/30 border border-amber-500/40 space-y-4 shadow-xl animate-in fade-in">
                <div className="flex items-center justify-between pb-2 border-b border-amber-500/20">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <h4 className="text-xs font-black uppercase tracking-wider text-amber-300">
                      Crear Nuevo Artículo para Inventario, Precios y Descuento de Empleados:
                    </h4>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Sincronización Inmediata
                  </span>
                </div>

                {/* Sugerencias Rápidas de Artículos y Equipo con Precios Recomendados */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                    <span>💡 Sugerencias Rápidas de Seguridad (Haz clic en cualquiera para autorellenar):</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto custom-scrollbar p-1.5 bg-black/50 rounded-xl border border-white/5">
                    {INVENTORY_PRESETS.map(preset => (
                      <button
                        key={preset.name}
                        type="button"
                        onClick={() => handleApplyPreset(preset)}
                        className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-white/10 hover:border-amber-500/30 text-[11px] font-medium transition-all flex items-center gap-1.5 shadow-sm"
                      >
                        <Plus className="w-3 h-3 text-amber-400" />
                        <span>{preset.name}</span>
                        <span className="font-mono text-[10px] text-amber-400 font-bold">(Q{preset.price})</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Campos del Formulario */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-300 mb-1">
                      Nombre del Artículo *
                    </label>
                    <input
                      type="text"
                      value={newItemName}
                      onChange={e => setNewItemName(e.target.value)}
                      placeholder="Ej. Chumpa Térmica, Chaleco, Cinturón"
                      required
                      className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-white font-medium bg-black/60 border border-white/10"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-300 mb-1">
                      Categoría
                    </label>
                    <select
                      value={newItemCategory}
                      onChange={e => setNewItemCategory(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-white bg-slate-900 border border-white/10"
                    >
                      <option value="Prenda / Uniforme" className="bg-slate-900 text-white">Prenda / Uniforme</option>
                      <option value="Calzado" className="bg-slate-900 text-white">Calzado</option>
                      <option value="Equipo Táctico" className="bg-slate-900 text-white">Equipo Táctico</option>
                      <option value="Accesorio" className="bg-slate-900 text-white">Accesorio</option>
                      <option value="Protección" className="bg-slate-900 text-white">Protección</option>
                      <option value="Otro" className="bg-slate-900 text-white">Otro</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-300 mb-1">
                      Precio Unitario (Q) *
                    </label>
                    <div className="relative">
                      <span className="absolute left-2.5 top-2 text-xs font-bold text-amber-400">Q</span>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={newItemPrice}
                        onChange={e => setNewItemPrice(e.target.value)}
                        required
                        className="w-full pl-7 pr-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-amber-300 bg-black/60 border border-white/10"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-300 mb-1">
                      Stock Inicial (Unidades) *
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={newItemStock}
                      onChange={e => setNewItemStock(e.target.value)}
                      required
                      className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-cyan-300 bg-black/60 border border-white/10"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">
                    Descripción / Especificaciones / Tallas
                  </label>
                  <input
                    type="text"
                    value={newItemDesc}
                    onChange={e => setNewItemDesc(e.target.value)}
                    placeholder="Ej. Tallas M, L, XL, material impermeable con cinta reflectiva, color reglamentario..."
                    className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-slate-300 bg-black/60 border border-white/10"
                  />
                </div>

                {/* Previsualización en Tiempo Real */}
                {newItemName.trim() && (
                  <div className="p-3 rounded-xl bg-black/50 border border-amber-500/20 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase font-bold text-amber-400">🏷️ Previsualización:</span>
                      <span className="font-bold text-white">{newItemName.trim()}</span>
                      <span className="px-1.5 py-0.5 rounded text-[9px] bg-white/10 text-slate-300 font-semibold">{newItemCategory}</span>
                    </div>
                    <div className="flex items-center gap-3 font-mono text-xs">
                      <span>Precio: <strong className="text-amber-300">Q{Number(newItemPrice || 0).toFixed(2)}</strong></span>
                      <span>Stock: <strong className="text-cyan-300">{Number(newItemStock || 0)} u.</strong></span>
                      <span>Total: <strong className="text-emerald-400">Q{(Number(newItemPrice || 0) * Number(newItemStock || 0)).toFixed(2)}</strong></span>
                    </div>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-white/5">
                  <span className="text-[11px] text-slate-400 italic">
                    ✨ Al guardar, los administradores e invitados podrán entregar y descontar este artículo en nómina quincenal.
                  </span>
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <button
                      type="button"
                      onClick={() => setIsAddingInventory(false)}
                      className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs transition-colors"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={handleAddInventoryItem}
                      disabled={isSubmitting || !newItemName.trim()}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs hover:from-emerald-400 hover:to-teal-400 transition-all shadow-md flex items-center gap-1.5 disabled:opacity-50"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{isSubmitting ? 'Guardando...' : 'Guardar en Catálogo e Inventario'}</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Barra de Búsqueda, Filtros y Resumen */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-2xl bg-black/40 border border-white/10 text-xs">
              <div className="flex items-center gap-2 flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="text"
                  value={inventorySearchQuery}
                  onChange={e => setInventorySearchQuery(e.target.value)}
                  placeholder="Buscar artículo por nombre o descripción..."
                  className="w-full bg-transparent border-0 text-xs text-white placeholder-slate-500 focus:outline-none"
                />
                {inventorySearchQuery && (
                  <button
                    type="button"
                    onClick={() => setInventorySearchQuery('')}
                    className="text-[10px] text-slate-400 hover:text-white px-1"
                  >
                    Limpiar
                  </button>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {['TODOS', 'Prenda / Uniforme', 'Calzado', 'Equipo Táctico', 'Accesorio', 'Protección'].map(cat => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedInventoryCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                      selectedInventoryCategory === cat
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                        : 'bg-white/5 text-slate-400 hover:text-white border border-white/5'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Estadísticas de Inventario */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Total Artículos</span>
                <span className="text-sm font-mono font-bold text-white">{inventoryList.length}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Unidades en Stock</span>
                <span className="text-sm font-mono font-bold text-cyan-300">
                  {inventoryList.reduce((acc, curr) => acc + (Number(curr.stock) || 0), 0)} u.
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Valor Total Catálogo</span>
                <span className="text-sm font-mono font-bold text-emerald-400">
                  Q{inventoryList.reduce((acc, curr) => acc + ((Number(curr.stock) || 0) * (Number(curr.price) || 0)), 0).toFixed(2)}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Artículos Agotados</span>
                <span className="text-sm font-mono font-bold text-rose-400">
                  {inventoryList.filter(i => (Number(i.stock) || 0) <= 0).length}
                </span>
              </div>
            </div>

            {/* Lista Dinámica de Artículos con Modificación Directa de Precios y Stock */}
            {(() => {
              const filtered = inventoryList.filter(item => {
                const matchesSearch = !inventorySearchQuery.trim() || 
                  item.name.toLowerCase().includes(inventorySearchQuery.toLowerCase()) ||
                  (item.description && item.description.toLowerCase().includes(inventorySearchQuery.toLowerCase())) ||
                  (item.category && item.category.toLowerCase().includes(inventorySearchQuery.toLowerCase()));
                const matchesCat = selectedInventoryCategory === 'TODOS' || item.category === selectedInventoryCategory;
                return matchesSearch && matchesCat;
              });

              if (filtered.length === 0) {
                return (
                  <div className="p-8 rounded-2xl bg-black/30 border border-white/5 text-center text-xs text-slate-400 space-y-2">
                    <p className="font-semibold">No se encontraron artículos con el filtro seleccionado.</p>
                    {isAdmin && (
                      <button
                        type="button"
                        onClick={() => { setIsAddingInventory(true); setInventorySearchQuery(''); }}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30 font-bold inline-flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Crear nuevo artículo ahora</span>
                      </button>
                    )}
                  </div>
                );
              }

              {/* RENDERIZADO EN TABLA DE PRECIOS */}
              if (inventoryViewMode === 'TABLE') {
                return (
                  <div className="rounded-2xl border border-white/10 overflow-hidden bg-black/50 shadow-xl">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="bg-white/5 border-b border-white/10 text-[10px] uppercase font-bold text-slate-400">
                            <th className="py-3 px-3">Artículo & Detalles</th>
                            <th className="py-3 px-3">Categoría</th>
                            <th className="py-3 px-3 text-center">Precio Unitario (Q)</th>
                            <th className="py-3 px-3 text-center">Stock Disponible</th>
                            <th className="py-3 px-3 text-right">Valor Total Lote</th>
                            {isAdmin && <th className="py-3 px-3 text-right">Acciones</th>}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {filtered.map(item => {
                            const isOutOfStock = (Number(item.stock) || 0) <= 0;
                            const isLowStock = !isOutOfStock && (Number(item.stock) || 0) <= 3;
                            const isRecentlyAdded = recentlyAddedItemId === item.id;

                            return (
                              <tr 
                                key={item.id} 
                                className={`hover:bg-white/5 transition-colors ${
                                  isRecentlyAdded ? 'bg-amber-500/10 border-l-4 border-l-amber-400' : ''
                                }`}
                              >
                                <td className="py-3 px-3">
                                  <div className="flex items-center gap-2">
                                    <span className="font-bold text-white text-xs">{item.name}</span>
                                    {isRecentlyAdded && (
                                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/30 text-amber-300 border border-amber-500/40 animate-pulse">
                                        ¡Nuevo!
                                      </span>
                                    )}
                                  </div>
                                  {item.description && (
                                    <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">{item.description}</p>
                                  )}
                                </td>

                                <td className="py-3 px-3 whitespace-nowrap">
                                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/10 text-slate-300">
                                    {item.category || 'Uniforme'}
                                  </span>
                                </td>

                                <td className="py-3 px-3 text-center whitespace-nowrap">
                                  <div className="inline-flex items-center relative max-w-[110px]">
                                    <span className="absolute left-2 text-xs font-bold text-amber-400">Q</span>
                                    <input
                                      type="number"
                                      step="0.01"
                                      min="0"
                                      value={item.price}
                                      onChange={e => {
                                        const val = Number(e.target.value) || 0;
                                        setInventoryList(prev => prev.map(i => i.id === item.id ? { ...i, price: val } : i));
                                      }}
                                      onBlur={e => {
                                        handleUpdateItemStockOrPrice(item.id, item.stock, Number(e.target.value) || 0);
                                      }}
                                      className="w-full pl-6 pr-2 py-1.5 rounded-lg liquid-glass-input text-xs font-mono font-bold text-amber-300 bg-black/60 border border-white/10 text-right"
                                    />
                                  </div>
                                </td>

                                <td className="py-3 px-3 text-center whitespace-nowrap">
                                  <div className="inline-flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const nextStock = Math.max(0, (Number(item.stock) || 0) - 1);
                                        handleUpdateItemStockOrPrice(item.id, nextStock, item.price);
                                      }}
                                      className="w-6 h-6 rounded bg-white/10 hover:bg-white/20 text-white font-bold flex items-center justify-center text-xs"
                                      title="Reducir stock"
                                    >
                                      -
                                    </button>
                                    <input
                                      type="number"
                                      min="0"
                                      value={item.stock}
                                      onChange={e => {
                                        const val = Number(e.target.value) || 0;
                                        setInventoryList(prev => prev.map(i => i.id === item.id ? { ...i, stock: val } : i));
                                      }}
                                      onBlur={e => {
                                        handleUpdateItemStockOrPrice(item.id, Number(e.target.value) || 0, item.price);
                                      }}
                                      className="w-14 px-1 py-1 rounded-lg liquid-glass-input text-xs font-mono font-bold text-cyan-300 text-center bg-black/60 border border-white/10"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const nextStock = (Number(item.stock) || 0) + 1;
                                        handleUpdateItemStockOrPrice(item.id, nextStock, item.price);
                                      }}
                                      className="w-6 h-6 rounded bg-white/10 hover:bg-white/20 text-white font-bold flex items-center justify-center text-xs"
                                      title="Aumentar stock"
                                    >
                                      +
                                    </button>
                                    {isOutOfStock ? (
                                      <span className="ml-1 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30">
                                        Agotado
                                      </span>
                                    ) : isLowStock ? (
                                      <span className="ml-1 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                        Bajo
                                      </span>
                                    ) : null}
                                  </div>
                                </td>

                                <td className="py-3 px-3 text-right whitespace-nowrap font-mono font-bold text-emerald-400">
                                  Q{((Number(item.stock) || 0) * (Number(item.price) || 0)).toFixed(2)}
                                </td>

                                {isAdmin && (
                                  <td className="py-3 px-3 text-right whitespace-nowrap">
                                    <div className="flex items-center justify-end gap-1.5">
                                      <button
                                        type="button"
                                        onClick={() => setEditingFullItem(item)}
                                        className="p-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/20 transition-colors"
                                        title="Editar nombre, tallas o categoría"
                                      >
                                        <Edit2 className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleDeleteInventoryItem(item.id, item.name)}
                                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/25 text-rose-300 border border-rose-500/20 transition-colors"
                                        title="Eliminar artículo del catálogo"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </td>
                                )}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              }

              {/* RENDERIZADO EN TARJETAS INTERACTIVAS */}
              return (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {filtered.map(item => {
                    const isOutOfStock = (Number(item.stock) || 0) <= 0;
                    const isLowStock = !isOutOfStock && (Number(item.stock) || 0) <= 3;
                    const isRecentlyAdded = recentlyAddedItemId === item.id;

                    return (
                      <div 
                        key={item.id} 
                        className={`p-4 rounded-2xl bg-black/50 border flex flex-col justify-between gap-3 text-xs transition-all hover:border-white/20 shadow-lg relative overflow-hidden ${
                          isRecentlyAdded ? 'border-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.2)]' : 'border-white/10'
                        }`}
                      >
                        <div className="space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1">
                              <div className="flex items-center gap-1.5">
                                <span className="font-black text-white text-sm tracking-tight">{item.name}</span>
                                {isRecentlyAdded && (
                                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/30 text-amber-300 border border-amber-500/40">
                                    ¡Nuevo!
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-2 mt-0.5">
                                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-white/10 text-slate-300">
                                  {item.category || 'Uniforme'}
                                </span>
                                {isOutOfStock ? (
                                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/30">
                                    Agotado
                                  </span>
                                ) : isLowStock ? (
                                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                    Stock Bajo
                                  </span>
                                ) : (
                                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                    En Stock
                                  </span>
                                )}
                              </div>
                            </div>

                            {isAdmin && (
                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => setEditingFullItem(item)}
                                  className="p-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/20 transition-colors"
                                  title="Editar detalles completos"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteInventoryItem(item.id, item.name)}
                                  className="p-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/25 text-rose-300 border border-rose-500/20 transition-colors"
                                  title="Eliminar artículo del catálogo"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )}
                          </div>

                          {item.description && (
                            <p className="text-[11px] text-slate-400 line-clamp-2">{item.description}</p>
                          )}
                        </div>

                        {/* Modificación en vivo de Precio y Stock */}
                        <div className="pt-2.5 border-t border-white/5 space-y-2">
                          <div className="grid grid-cols-2 gap-2">
                            {/* Input de Precio Unitario */}
                            <div>
                              <label className="text-[10px] font-bold text-amber-300 block mb-0.5">
                                Precio Unitario (Q):
                              </label>
                              <div className="relative">
                                <span className="absolute left-2 top-1.5 text-xs font-bold text-amber-400">Q</span>
                                <input
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  value={item.price}
                                  onChange={e => {
                                    const val = Number(e.target.value) || 0;
                                    setInventoryList(prev => prev.map(i => i.id === item.id ? { ...i, price: val } : i));
                                  }}
                                  onBlur={e => {
                                    handleUpdateItemStockOrPrice(item.id, item.stock, Number(e.target.value) || 0);
                                  }}
                                  className="w-full pl-6 pr-2 py-1.5 rounded-lg liquid-glass-input text-xs font-mono font-bold text-amber-300 bg-black/60 border border-white/10"
                                />
                              </div>
                            </div>

                            {/* Input de Stock Disponible */}
                            <div>
                              <label className="text-[10px] font-bold text-cyan-300 block mb-0.5">
                                Stock Disp.:
                              </label>
                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    const nextStock = Math.max(0, (Number(item.stock) || 0) - 1);
                                    handleUpdateItemStockOrPrice(item.id, nextStock, item.price);
                                  }}
                                  className="w-6 h-7 rounded bg-white/10 hover:bg-white/20 text-white font-bold flex items-center justify-center text-xs"
                                >
                                  -
                                </button>
                                <input
                                  type="number"
                                  min="0"
                                  value={item.stock}
                                  onChange={e => {
                                    const val = Number(e.target.value) || 0;
                                    setInventoryList(prev => prev.map(i => i.id === item.id ? { ...i, stock: val } : i));
                                  }}
                                  onBlur={e => {
                                    handleUpdateItemStockOrPrice(item.id, Number(e.target.value) || 0, item.price);
                                  }}
                                  className="w-full px-1.5 py-1.5 rounded-lg liquid-glass-input text-xs font-mono font-bold text-cyan-300 text-center bg-black/60 border border-white/10"
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    const nextStock = (Number(item.stock) || 0) + 1;
                                    handleUpdateItemStockOrPrice(item.id, nextStock, item.price);
                                  }}
                                  className="w-6 h-7 rounded bg-white/10 hover:bg-white/20 text-white font-bold flex items-center justify-center text-xs"
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                            <span>Subtotal valor: <strong className="font-mono text-white">Q{((Number(item.stock) || 0) * (Number(item.price) || 0)).toFixed(2)}</strong></span>
                            <span className="text-emerald-400/90 text-[10px]">Autoguardado al editar</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}

            {/* Modal para Editar Artículo Completo (Nombre, Tallas, Categoría, Precio, Stock) */}
            {editingFullItem && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
                <div className="bg-slate-900 border border-white/20 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl relative">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <div className="flex items-center gap-2">
                      <Edit2 className="w-5 h-5 text-cyan-400" />
                      <h3 className="font-black text-white text-sm uppercase tracking-wider">
                        Editar Detalles del Artículo
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => setEditingFullItem(null)}
                      className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form
                    onSubmit={e => {
                      e.preventDefault();
                      handleUpdateItemStockOrPrice(
                        editingFullItem.id,
                        editingFullItem.stock,
                        editingFullItem.price,
                        {
                          name: editingFullItem.name,
                          category: editingFullItem.category,
                          description: editingFullItem.description,
                        }
                      );
                    }}
                    className="space-y-3 text-xs"
                  >
                    <div>
                      <label className="block text-[10px] font-bold text-slate-300 mb-1">Nombre del Artículo *</label>
                      <input
                        type="text"
                        value={editingFullItem.name}
                        onChange={e => setEditingFullItem({ ...editingFullItem, name: e.target.value })}
                        required
                        className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-white bg-black/60 border border-white/10"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-300 mb-1">Categoría</label>
                        <select
                          value={editingFullItem.category || 'Prenda / Uniforme'}
                          onChange={e => setEditingFullItem({ ...editingFullItem, category: e.target.value })}
                          className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-white bg-slate-900 border border-white/10"
                        >
                          <option value="Prenda / Uniforme">Prenda / Uniforme</option>
                          <option value="Calzado">Calzado</option>
                          <option value="Equipo Táctico">Equipo Táctico</option>
                          <option value="Accesorio">Accesorio</option>
                          <option value="Protección">Protección</option>
                          <option value="Otro">Otro</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-300 mb-1">Precio Unitario (Q) *</label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={editingFullItem.price}
                          onChange={e => setEditingFullItem({ ...editingFullItem, price: Number(e.target.value) || 0 })}
                          required
                          className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-amber-300 bg-black/60 border border-white/10"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-300 mb-1">Stock Disponible (Unidades) *</label>
                      <input
                        type="number"
                        min="0"
                        value={editingFullItem.stock}
                        onChange={e => setEditingFullItem({ ...editingFullItem, stock: Number(e.target.value) || 0 })}
                        required
                        className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-cyan-300 bg-black/60 border border-white/10"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-300 mb-1">Descripción / Especificaciones / Tallas</label>
                      <textarea
                        rows={2}
                        value={editingFullItem.description || ''}
                        onChange={e => setEditingFullItem({ ...editingFullItem, description: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-slate-300 bg-black/60 border border-white/10"
                      />
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                      <button
                        type="button"
                        onClick={() => setEditingFullItem(null)}
                        className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs"
                      >
                        Cancelar
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 text-slate-950 font-bold text-xs shadow-md"
                      >
                        Guardar Cambios
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>

            {/* SECCIÓN: FONDO DE PANTALLA DE GUARDIAS (ELEGIR DESDE GALERÍA DE COMPUTADORA O TELÉFONO) */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <h3 className="text-xs font-black uppercase tracking-wider text-cyan-300 flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-cyan-400" />
                  <span>Fondo de Pantalla de Guardias (Elegir de Galería o Enlace)</span>
                </h3>
                <span className="text-[10px] text-slate-400">
                  Visible en la terminal de asistencia y garita de todos los guardias
                </span>
              </div>

              {/* Botón para subir archivo desde la galería de la computadora o teléfono */}
              <div className="flex flex-wrap items-center gap-3">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleWallpaperFileChange}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 hover:text-white border border-cyan-400/40 hover:border-cyan-400 text-xs font-bold transition-all flex items-center gap-2 shadow-sm"
                >
                  <Upload className="w-4 h-4 text-cyan-400" />
                  <span>📁 Elegir Fondo de mi Galería (PC o Teléfono)</span>
                </button>

                {wallpaperFileName && (
                  <span className="text-xs text-emerald-300 font-semibold bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Foto seleccionada: {wallpaperFileName}</span>
                  </span>
                )}

                {guardWallpaper && (
                  <button
                    type="button"
                    onClick={() => {
                      setGuardWallpaper('');
                      setWallpaperFileName(null);
                    }}
                    className="p-2 text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 rounded-xl border border-rose-500/30 text-xs font-bold transition-all flex items-center gap-1"
                    title="Quitar fondo actual"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Quitar</span>
                  </button>
                )}
              </div>

              {/* Input alternativo de URL */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  O ingresa URL de Imagen directa:
                </label>
                <input
                  type="text"
                  value={guardWallpaper.startsWith('data:') ? 'Imagen cargada desde Galería del Dispositivo' : guardWallpaper}
                  onChange={e => {
                    setGuardWallpaper(e.target.value);
                    setWallpaperFileName(null);
                  }}
                  disabled={guardWallpaper.startsWith('data:')}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="w-full px-3.5 py-2 rounded-xl liquid-glass-input text-xs font-mono text-white bg-black/50 border border-white/10 disabled:opacity-75"
                />
              </div>

              {/* Vista previa en vivo del fondo de pantalla */}
              {guardWallpaper && (
                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider">
                    Vista Previa del Fondo de los Guardias:
                  </span>
                  <div
                    className="h-36 sm:h-44 w-full rounded-2xl bg-cover bg-center border border-white/20 relative overflow-hidden flex items-center justify-center shadow-lg"
                    style={{ backgroundImage: `url(${guardWallpaper})` }}
                  >
                    <div className="absolute inset-0 bg-black/45 backdrop-blur-[1px] flex items-center justify-center p-4">
                      <div className="liquid-glass px-4 py-2 rounded-xl text-xs font-black text-white border border-white/20 shadow-md">
                        Terminal de Guardia Real (Fondo Activo)
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 font-bold text-xs hover:from-cyan-400 hover:to-blue-400 transition-all flex items-center gap-2 shadow-lg active:scale-98"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? 'Guardando...' : 'Guardar Cambios de Configuración'}</span>
            </button>
          </div>
        </form>
      ) : (
        <div className="p-6 rounded-3xl bg-black/40 border border-white/10 text-center text-xs text-slate-300">
          <Shield className="w-6 h-6 text-amber-400 mx-auto mb-2" />
          <p className="font-bold">Sección restringida al Administrador Principal.</p>
          <p className="text-[11px] text-slate-400 mt-0.5">La modificación de contraseñas de administrador requiere rol ADMIN.</p>
        </div>
      )}

      {/* Respaldo y Mantenimiento de Datos (Exclusivo Administrador) */}
      {isAdmin && (
        <div className="liquid-glass p-6 rounded-3xl border border-rose-500/20 space-y-4">
          <h2 className="text-sm font-black uppercase tracking-wider text-rose-400 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>Respaldo & Mantenimiento de Datos del Sistema</span>
          </h2>
          <p className="text-xs text-slate-300">
            Descarga una copia de seguridad completa con toda la información de la aplicación (empresas, empleados, recibos, pagos, asistencias y configuraciones) o elimina todos los datos almacenados para un reinicio de fábrica.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleExportAllData}
              disabled={isExporting}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 hover:text-white border border-cyan-400/40 hover:border-cyan-400 text-xs font-bold transition-all flex items-center gap-2 shadow-sm"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span>{isExporting ? 'Generando Respaldo...' : '📥 Descargar Respaldo Completo de la App (JSON)'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setImportAdminPin('');
                setImportFile(null);
                setImportFileContent(null);
                setImportError(null);
                setIsImportModalOpen(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-300 hover:text-white border border-emerald-400/40 hover:border-emerald-400 text-xs font-bold transition-all flex items-center gap-2 shadow-sm"
            >
              <Upload className="w-4 h-4 text-emerald-400" />
              <span>📤 Importar Respaldo de la App (JSON)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setResetAdminPin('');
                setResetError(null);
                setIsResetModalOpen(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-bold transition-all flex items-center gap-2 shadow-sm"
            >
              <Trash2 className="w-4 h-4 text-rose-400" />
              <span>🗑️ Borrar Todos los Datos de la Aplicación</span>
            </button>
          </div>
        </div>
      )}

      {/* Modal de importación de respaldo con PIN de Admin */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="liquid-glass p-6 sm:p-8 rounded-3xl max-w-md w-full border border-emerald-500/40 space-y-5 shadow-2xl">
            <div className="flex items-center gap-3 text-emerald-400">
              <Upload className="w-7 h-7 shrink-0" />
              <h3 className="text-base font-black tracking-tight text-white uppercase">
                Importar Respaldo de la App (PIN Requerido)
              </h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              📂 Selecciona el archivo JSON descargado previamente como respaldo. Esto <strong className="text-emerald-300">reemplazará</strong> los datos actuales de la aplicación con la información del respaldo. Introduce el <strong className="text-cyan-300">PIN de Administrador</strong> para confirmar.
            </p>

            {importError && (
              <div className="p-3 rounded-xl bg-rose-500/25 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2 font-bold">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{importError}</span>
              </div>
            )}

            <form onSubmit={handleImportBackupSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  Archivo de Respaldo (.json)
                </label>
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleBackupFileSelect}
                  required
                  className="w-full text-xs text-slate-300 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-emerald-500/20 file:text-emerald-300 hover:file:bg-emerald-500/30 file:cursor-pointer bg-black/40 p-2 rounded-xl border border-white/10"
                />
                {importFile && (
                  <p className="text-[11px] text-emerald-400 mt-1 font-mono">
                    Archivo seleccionado: {importFile.name} ({Math.round(importFile.size / 1024)} KB)
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  PIN de Administrador Principal
                </label>
                <input
                  type="password"
                  value={importAdminPin}
                  onChange={e => setImportAdminPin(e.target.value)}
                  placeholder="Ingresa PIN de Admin (Ej. 2004)"
                  required
                  className="w-full px-4 py-3 rounded-xl liquid-glass-input text-sm font-mono font-bold text-emerald-300 bg-black/60 border border-white/20"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsImportModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold text-slate-300 transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isImporting || !importFileContent}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition-all shadow-lg flex items-center gap-2 disabled:opacity-50"
                >
                  <Upload className="w-4 h-4" />
                  <span>{isImporting ? 'Importando...' : 'Confirmar e Importar Respaldo'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de confirmación para borrar datos con PIN de Admin */}
      {isResetModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="liquid-glass p-6 sm:p-8 rounded-3xl max-w-md w-full border border-rose-500/40 space-y-5 shadow-2xl">
            <div className="flex items-center gap-3 text-rose-400">
              <ShieldAlert className="w-7 h-7 shrink-0" />
              <h3 className="text-base font-black tracking-tight text-white uppercase">
                Confirmación de Borrado Total (PIN Requerido)
              </h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              ⚠️ <strong className="text-rose-300">¡Advertencia Crítica!</strong> Esta acción eliminará permanentemente todos los registros, empleados, pagos, recibos y asistencias guardados en la aplicación. Para proceder, introduce el <strong className="text-cyan-300">PIN de Administrador</strong>.
            </p>

            {resetError && (
              <div className="p-3 rounded-xl bg-rose-500/25 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2 font-bold">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{resetError}</span>
              </div>
            )}

            <form onSubmit={handleResetAppData} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  PIN de Administrador Principal
                </label>
                <input
                  type="password"
                  value={resetAdminPin}
                  onChange={e => setResetAdminPin(e.target.value)}
                  placeholder="Ingresa PIN de Admin (Ej. 2004)"
                  required
                  autoFocus
                  className="w-full px-4 py-3 rounded-xl liquid-glass-input text-sm font-mono font-bold text-rose-300 bg-black/60 border border-white/20"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsResetModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold text-slate-300 transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isResetting}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-bold transition-all shadow-lg flex items-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{isResetting ? 'Borrando y Reiniciando...' : 'Confirmar y Borrar Todo'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Control de Permisos Section */}
      <div className="space-y-4 pt-4">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-cyan-400" />
          <h2 className="text-base font-black text-white tracking-tight">
            Control de Permisos de Usuarios & Invitados
          </h2>
        </div>

        <PermissionsManagementView
          users={users}
          currentUser={currentUser}
          onUpdatePermissions={onUpdatePermissions}
          onUpdateUserRoleAndCode={onUpdateUserRoleAndCode}
          onCreateUser={onCreateUser}
          onSwitchUser={onSwitchUser}
          onDeleteUser={onDeleteUser}
        />
      </div>

    </div>
  );
};
