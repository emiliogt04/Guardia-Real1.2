import React, { useState } from 'react';
import { Calendar, Save, FileText, CheckCircle2, Lock, RotateCcw, AlertTriangle } from 'lucide-react';
import { Employee, Company, SystemSecurityConfig } from '../types';
import { formatCurrencyGTQ } from '../utils/formatters';
import { MONTH_NAMES_ES, currentQuincena, quincenaLabel, parseQuincenaRef } from '../utils/quincenas';

interface PayrollCenterProps {
  employees: Employee[];
  companies: Company[];
  securityConfig?: SystemSecurityConfig | null;
  onSavePayroll: (payrollData: any) => Promise<void>;
  getAuthHeaders?: () => Record<string, string>;
}

type ViewMode = 'QUINCENA' | 'MES' | 'ANIO';

export const PayrollCenter: React.FC<PayrollCenterProps> = ({ companies, onSavePayroll, getAuthHeaders }) => {
  const now = currentQuincena();
  const [mode, setMode] = useState<ViewMode>('QUINCENA');
  const [year, setYear] = useState<number>(now.year);
  const [month, setMonth] = useState<number>(now.month);
  const [period, setPeriod] = useState<1 | 2>(now.quincena);
  const [companyId, setCompanyId] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  // Resultado mostrado: { rows, saved, partiallySaved, records, periodLabel, kind: 'QUINCENA' | 'HISTORIAL' }
  const [payrollData, setPayrollData] = useState<any>(null);
  const [errorMsg, setErrorMsg] = useState<string>('');

  const headers = () => (getAuthHeaders ? getAuthHeaders() : { 'Content-Type': 'application/json' });

  const loadPayroll = async () => {
    setIsLoading(true);
    setErrorMsg('');
    try {
      if (mode === 'QUINCENA') {
        // Si la quincena ya está guardada, el servidor devuelve el registro fijo; si no, una vista previa.
        const response = await fetch('/api/payroll/calculate', {
          method: 'POST',
          headers: headers(),
          body: JSON.stringify({
            year,
            month,
            tipo_quincena: period === 1 ? '1RA_QUINCENA' : '2DA_QUINCENA',
            companyId: companyId === 'all' ? undefined : companyId,
          }),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'No se pudo cargar la planilla.');
        setPayrollData({ ...data, kind: 'QUINCENA' });
      } else {
        // Mes / Año: se lee ÚNICAMENTE lo guardado; nunca se recalculan descuentos.
        const response = await fetch('/api/payroll/history', { headers: headers() });
        const history = await response.json();
        if (!response.ok) throw new Error(history.error || 'No se pudo cargar el historial.');
        const rows: any[] = [];
        for (const rec of history as any[]) {
          const q = parseQuincenaRef(rec.anio, rec.mes, rec.tipo_quincena);
          if (!q || q.year !== year || (mode === 'MES' && q.month !== month)) continue;
          for (const row of rec.rows || []) {
            if (companyId !== 'all' && row.companyId !== companyId) continue;
            rows.push({ ...row, saved: true, periodLabel: quincenaLabel(q), _order: q.year * 24 + (q.month - 1) * 2 + q.quincena });
          }
        }
        rows.sort((a, b) => a._order - b._order || String(a.employeeName).localeCompare(String(b.employeeName)));
        setPayrollData({
          kind: 'HISTORIAL',
          saved: true,
          periodLabel: mode === 'MES' ? `${MONTH_NAMES_ES[month - 1]} ${year}` : `Año ${year}`,
          rows,
        });
      }
    } catch (err: any) {
      setPayrollData(null);
      setErrorMsg(err.message || 'Error al cargar la planilla.');
    } finally {
      setIsLoading(false);
    }
  };

  const saveRows = async (markPaid: boolean) => {
    if (!payrollData || payrollData.kind !== 'QUINCENA' || !payrollData.rows) return;
    const label = payrollData.periodLabel || quincenaLabel({ year, month, quincena: period });
    if (!window.confirm(`Se guardará la ${label} como registro fijo. Los descuentos aplicados quedarán congelados y se registrará la cuota cobrada. ¿Continuar?`)) return;
    setIsSaving(true);
    setErrorMsg('');
    try {
      await onSavePayroll({
        year,
        month,
        period: period === 1 ? '1RA_QUINCENA' : '2DA_QUINCENA',
        companyId: companyId === 'all' ? undefined : companyId,
        rows: payrollData.rows.filter((r: any) => !r.saved).map((row: any) => (markPaid ? { ...row, status: 'PAGADO' } : row)),
      });
      await loadPayroll();
    } catch (err: any) {
      setErrorMsg(err.message || 'No se pudo guardar la planilla.');
    } finally {
      setIsSaving(false);
    }
  };

  const reopenRecord = async (recordId: string) => {
    if (!window.confirm('¿Reabrir esta quincena guardada? Las cuotas de descuentos de esa quincena quedarán liberadas y la planilla volverá a calcularse con los datos actuales.')) return;
    setIsSaving(true);
    setErrorMsg('');
    try {
      const res = await fetch(`/api/payroll/history/${recordId}`, { method: 'DELETE', headers: headers() });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'No se pudo reabrir la quincena.');
      await loadPayroll();
    } catch (err: any) {
      setErrorMsg(err.message || 'No se pudo reabrir la quincena.');
    } finally {
      setIsSaving(false);
    }
  };

  const rows: any[] = payrollData?.rows || [];
  const hasUnsaved = payrollData?.kind === 'QUINCENA' && rows.some(r => !r.saved);
  const exportLabel = payrollData?.periodLabel || '';
  const showMonth = mode !== 'ANIO';
  const showPeriod = mode === 'QUINCENA';

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Calendar className="w-5 h-5 text-cyan-400" />
          Centro de Nómina
        </h2>

        <div className="inline-flex p-1 rounded-xl bg-black/60 border border-white/10">
          {([['QUINCENA', 'Quincena'], ['MES', 'Mes (guardado)'], ['ANIO', 'Año (guardado)']] as [ViewMode, string][]).map(([m, label]) => (
            <button
              key={m}
              type="button"
              onClick={() => { setMode(m); setPayrollData(null); setErrorMsg(''); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${mode === m ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'}`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
          <input type="number" value={year} onChange={e => setYear(Number(e.target.value))} className="p-2 rounded-xl bg-black/60 border border-white/10 text-white" />
          {showMonth ? (
            <select value={month} onChange={e => setMonth(Number(e.target.value))} className="p-2 rounded-xl bg-black/60 border border-white/10 text-white">
              {MONTH_NAMES_ES.map((name, i) => <option key={name} value={i + 1} className="bg-slate-900">{name}</option>)}
            </select>
          ) : <div />}
          {showPeriod ? (
            <select value={period} onChange={e => setPeriod(Number(e.target.value) as 1 | 2)} className="p-2 rounded-xl bg-black/60 border border-white/10 text-white">
              <option value={1} className="bg-slate-900">1ra Quincena</option>
              <option value={2} className="bg-slate-900">2da Quincena</option>
            </select>
          ) : <div />}
          <select value={companyId} onChange={e => setCompanyId(e.target.value)} className="p-2 rounded-xl bg-black/60 border border-white/10 text-white">
            <option value="all" className="bg-slate-900">Todas las empresas</option>
            {companies.map(c => <option key={c.id} value={c.id} className="bg-slate-900">{c.name}</option>)}
          </select>
          <button onClick={loadPayroll} disabled={isLoading} className="px-4 py-2 bg-cyan-500 text-slate-950 font-bold rounded-xl hover:bg-cyan-400 disabled:opacity-60">
            {isLoading ? 'Cargando...' : mode === 'QUINCENA' ? 'Calcular / Ver' : 'Ver guardado'}
          </button>
        </div>
        {mode !== 'QUINCENA' && (
          <p className="text-[11px] text-slate-400">
            Las vistas por mes y año muestran únicamente las planillas ya guardadas; no se recalculan descuentos.
          </p>
        )}
      </div>

      {errorMsg && (
        <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-200 text-xs flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMsg}</span>
        </div>
      )}

      {payrollData && (
        <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-4">
          {payrollData.kind === 'QUINCENA' && (
            <div className={`p-3 rounded-xl border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${
              payrollData.saved
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
                : 'bg-amber-500/10 border-amber-500/30 text-amber-200'
            }`}>
              <span className="flex items-center gap-2 font-semibold">
                {payrollData.saved ? <Lock className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                {payrollData.saved
                  ? `${payrollData.periodLabel}: planilla guardada (registro fijo). Los descuentos no se recalculan.`
                  : payrollData.partiallySaved
                    ? `${payrollData.periodLabel}: guardada solo para algunos colaboradores; el resto es vista previa.`
                    : `${payrollData.periodLabel}: vista previa, aún no guardada.`}
              </span>
              {(payrollData.records || []).length > 0 && (
                <span className="flex flex-wrap gap-2">
                  {(payrollData.records as any[]).map(rec => (
                    <button
                      key={rec.id}
                      type="button"
                      disabled={isSaving}
                      onClick={() => reopenRecord(rec.id)}
                      className="px-2.5 py-1 rounded-lg bg-black/40 border border-white/10 text-white font-bold flex items-center gap-1.5 hover:bg-black/60 disabled:opacity-50"
                      title="Reabrir esta quincena guardada"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Reabrir{rec.companyId && rec.companyId !== 'all' ? ' (empresa)' : ''}
                    </button>
                  ))}
                </span>
              )}
            </div>
          )}

          {rows.length === 0 ? (
            <p className="text-xs text-slate-400 italic p-3 rounded-xl bg-white/5 border border-white/5">
              {payrollData.kind === 'HISTORIAL'
                ? 'No hay planillas guardadas en este período.'
                : 'No hay colaboradores activos para calcular.'}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-white text-xs">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="py-2 text-left">Colaborador</th>
                    <th className="py-2 text-right">Sueldo Base</th>
                    <th className="py-2 text-right">IGSS</th>
                    <th className="py-2 text-right">Descuentos</th>
                    <th className="py-2 text-right">Neto</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row: any, i: number) => (
                    <tr key={`${row.employeeId}-${row.periodLabel || ''}-${i}`} className="border-b border-white/5">
                      <td className="py-2">
                        <div className="font-bold">{row.employeeName}</div>
                        {row.periodLabel && <div className="text-[10px] text-cyan-300">{row.periodLabel}</div>}
                        {row.appliedDiscounts && row.appliedDiscounts.length > 0 && (
                          <div className="text-[10px] text-slate-400 mt-1">
                            {row.appliedDiscounts.map((d: any) => (
                              <div key={d.id}>
                                - {d.reason}: {formatCurrencyGTQ(d.amountToCharge ?? d.installmentAmount ?? d.amount)}
                                {d.totalInstallments > 1 && ` (cuota ${d.currentInstallment} de ${d.totalInstallments})`}
                              </div>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="py-2 text-right align-top">{formatCurrencyGTQ(row.quincenalBase)}</td>
                      <td className="py-2 text-right align-top">{formatCurrencyGTQ(row.igssDeduction || 0)}</td>
                      <td className="py-2 text-right align-top">{formatCurrencyGTQ(row.discountsTotal)}</td>
                      <td className="py-2 text-right font-bold text-cyan-300 align-top">{formatCurrencyGTQ(row.netAmount)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t border-white/20 font-bold">
                    <td className="py-2">Total</td>
                    <td className="py-2 text-right">{formatCurrencyGTQ(rows.reduce((a, r) => a + (r.quincenalBase || 0), 0))}</td>
                    <td className="py-2 text-right">{formatCurrencyGTQ(rows.reduce((a, r) => a + (r.igssDeduction || 0), 0))}</td>
                    <td className="py-2 text-right">{formatCurrencyGTQ(rows.reduce((a, r) => a + (r.discountsTotal || 0), 0))}</td>
                    <td className="py-2 text-right text-cyan-300">{formatCurrencyGTQ(rows.reduce((a, r) => a + (r.netAmount || 0), 0))}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}

          {hasUnsaved && (
            <div className="flex gap-2">
              <button onClick={() => saveRows(false)} disabled={isSaving} className="flex-1 py-3 flex items-center justify-center gap-2 bg-slate-700 text-white font-bold rounded-xl hover:bg-slate-600 disabled:opacity-60">
                <Save className="w-5 h-5" /> {isSaving ? 'Guardando...' : 'Guardar planilla (registro fijo)'}
              </button>
              <button onClick={() => saveRows(true)} disabled={isSaving} className="flex-1 py-3 flex items-center justify-center gap-2 bg-emerald-500 text-slate-950 font-bold rounded-xl hover:bg-emerald-400 disabled:opacity-60">
                <CheckCircle2 className="w-5 h-5" /> {isSaving ? 'Procesando...' : 'Guardar y marcar pagada'}
              </button>
            </div>
          )}

          {rows.length > 0 && (
            <div className="flex gap-2 pt-2">
              <button onClick={async () => {
                const { exportPayrollSummaryToPDF } = await import('../utils/payrollExport');
                exportPayrollSummaryToPDF({
                  rows,
                  periodLabel: exportLabel,
                  companyName: companyId === 'all' ? 'Guardia Real' : (companies.find(c => c.id === companyId)?.name || 'Guardia Real'),
                });
              }} className="flex-1 py-2 flex items-center justify-center gap-2 bg-rose-500/20 text-rose-300 font-bold rounded-xl hover:bg-rose-500/30">
                <FileText className="w-4 h-4" /> Exportar PDF Resumen
              </button>
              <button onClick={async () => {
                const { exportPayrollSummaryToExcel } = await import('../utils/payrollExport');
                exportPayrollSummaryToExcel({ rows, periodLabel: exportLabel });
              }} className="flex-1 py-2 flex items-center justify-center gap-2 bg-emerald-500/20 text-emerald-300 font-bold rounded-xl hover:bg-emerald-500/30">
                <FileText className="w-4 h-4" /> Exportar Excel Resumen
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
