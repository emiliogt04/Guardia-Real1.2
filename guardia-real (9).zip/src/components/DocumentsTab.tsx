import React, { useState } from 'react';
import { FileText, Upload, Download, Plus, Trash2 } from 'lucide-react';
import { Employee } from '../types';

interface DocumentsTabProps {
  viewingEmployee: Employee;
  onUpdateEmployee: (updatedEmployee: Employee) => void;
  isAdmin: boolean;
}

export const DocumentsTab: React.FC<DocumentsTabProps> = ({ viewingEmployee, onUpdateEmployee, isAdmin }) => {
  const [uploading, setUploading] = useState<string | null>(null);

  const handleFileUpload = async (docType: string, file: File, otherName?: string) => {
    if (!isAdmin) return;
    setUploading(docType);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      try {
        const body = { fileContent: base64String, otherName };
        const res = await fetch(`/api/employees/${viewingEmployee.id}/documents/${docType}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });
        const data = await res.json();
        if (data.success) {
          onUpdateEmployee({ ...viewingEmployee, documents: data.documents });
        } else {
          alert('Error al subir el archivo');
        }
      } catch (err) {
        alert('Error de conexión');
      } finally {
        setUploading(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDeleteDocument = async (docType: string, index?: number) => {
    if (!isAdmin || !confirm('¿Estás seguro de eliminar este documento?')) return;
    try {
      const res = await fetch(`/api/employees/${viewingEmployee.id}/documents/${docType}/${index ?? ''}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data.success) {
        onUpdateEmployee({ ...viewingEmployee, documents: data.documents });
      } else {
        alert('Error al eliminar el archivo');
      }
    } catch (err) {
      alert('Error de conexión');
    }
  };

  const docTypes = [
    { id: 'personalInfo', label: 'Información Personal (Ficha)' },
    { id: 'resignationForm', label: 'Formulario de Baja' },
    { id: 'fingerprints', label: 'Huellas' },
    { id: 'contract', label: 'CONTRATO' },
  ];

  return (
    <div className="space-y-4">
      {docTypes.map(doc => (
        <div key={doc.id} className="p-4 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <FileText className="w-5 h-5 text-cyan-400" />
            <span className="text-sm font-semibold text-white">{doc.label}</span>
          </div>
          <div className="flex items-center gap-2">
              {viewingEmployee.documents?.[doc.id as keyof typeof viewingEmployee.documents] ? (
              <div className="flex items-center gap-2">
                <a 
                  href={viewingEmployee.documents[doc.id as keyof typeof viewingEmployee.documents]} 
                  download={`${doc.id}_${viewingEmployee.name}.pdf`}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-bold hover:bg-emerald-500/30 flex items-center gap-1"
                >
                  <Download className="w-4 h-4" /> Descargar
                </a>
                {isAdmin && (
                  <button onClick={() => handleDeleteDocument(doc.id)} className="p-1.5 rounded-lg bg-red-500/20 text-red-300 hover:bg-red-500/30">
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ) : isAdmin ? (
              <label className="px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 text-xs font-bold hover:bg-cyan-500/30 cursor-pointer flex items-center gap-1">
                <Upload className="w-4 h-4" /> {uploading === doc.id ? 'Subiendo...' : 'Subir PDF'}
                <input type="file" accept="application/pdf" className="hidden" onChange={(e) => e.target.files?.[0] && handleFileUpload(doc.id, e.target.files[0])} />
              </label>
            ) : <span className="text-xs text-slate-500 italic">No disponible</span>}
          </div>
        </div>
      ))}
      
      {/* Sección de Otros Documentos */}
      <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm font-semibold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-purple-400" /> Otros Documentos
          </span>
          {isAdmin && (
            <label className="px-3 py-1.5 rounded-lg bg-purple-500/20 text-purple-300 text-xs font-bold hover:bg-purple-500/30 cursor-pointer flex items-center gap-1">
              <Plus className="w-4 h-4" /> Agregar
              <input type="file" accept="application/pdf" className="hidden" onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  const name = prompt("Nombre del documento:");
                  if (name) handleFileUpload('others', file, name);
                }
              }} />
            </label>
          )}
        </div>
        <div className="space-y-2">
          {viewingEmployee.documents?.others?.map((doc, idx) => (
            <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-white/5 border border-white/10">
              <span className="text-xs text-slate-300">{doc.name}</span>
              <div className="flex items-center gap-2">
                <a href={doc.url} download={doc.name} className="text-purple-400 hover:text-purple-300 text-xs font-bold flex items-center gap-1">
                  <Download className="w-4 h-4" /> Descargar
                </a>
                {isAdmin && (
                  <button onClick={() => handleDeleteDocument('others', idx)} className="p-1 rounded-lg bg-red-500/20 text-red-300 hover:bg-red-500/30">
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
