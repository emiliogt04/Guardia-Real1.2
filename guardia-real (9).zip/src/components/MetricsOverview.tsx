import React from 'react';
import { Building2, Users, DollarSign, History, ShieldCheck, QrCode } from 'lucide-react';
import { Company, Employee, AuditLog, AppUser, GuardCheckin } from '../types';
import { formatCurrencyGTQ } from '../utils/formatters';

interface MetricsOverviewProps {
  companies: Company[];
  employees: Employee[];
  auditLogs: AuditLog[];
  currentUser: AppUser;
  guardCheckins?: GuardCheckin[];
}

export const MetricsOverview: React.FC<MetricsOverviewProps> = ({
  companies,
  employees,
  auditLogs,
  currentUser,
  guardCheckins = [],
}) => {
  if (currentUser.role === 'GUARD') {
    return null;
  }

  const activeEmployees = employees.filter(e => e.status === 'ACTIVO');
  const inactiveEmployees = employees.filter(e => e.status === 'DE_BAJA');
  
  const canViewSalaries = currentUser.role === 'ADMIN' || currentUser.permissions?.canViewSalaries !== false;
  const canViewAudit = currentUser.role === 'ADMIN' || !!currentUser.permissions?.canViewAuditLog;

  const totalMonthlyPayroll = activeEmployees.reduce((sum, e) => sum + (e.monthlySalary || 0), 0);
  const estimatedQuincenalPayroll = totalMonthlyPayroll / 2;
  const criticalAuditCount = auditLogs.filter(l => l.isCritical).length;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      
      {/* Metric 1: Total Empresas */}
      <div className="liquid-glass-interactive rounded-2xl p-5 flex items-start justify-between relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 rounded-full blur-xl -z-10 group-hover:bg-blue-500/20 transition-all"></div>
        <div>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            Empresas Activas
          </span>
          <span className="text-2xl font-extrabold text-white mt-1.5 block tabular-nums tracking-tight">
            {companies.length}
          </span>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Sociedades anónimas registradas
          </span>
        </div>
        <div className="p-3 bg-blue-500/15 text-blue-400 rounded-xl border border-blue-400/20 shadow-[0_0_15px_rgba(59,130,246,0.15)]">
          <Building2 className="w-5 h-5" />
        </div>
      </div>

      {/* Metric 2: Colaboradores Activos */}
      <div className="liquid-glass-interactive rounded-2xl p-5 flex items-start justify-between relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl -z-10 group-hover:bg-emerald-500/20 transition-all"></div>
        <div>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            Colaboradores Activos
          </span>
          <span className="text-2xl font-extrabold text-white mt-1.5 block tabular-nums tracking-tight">
            {activeEmployees.length}
          </span>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {inactiveEmployees.length} registros con fecha de baja
          </span>
        </div>
        <div className="p-3 bg-emerald-500/15 text-emerald-400 rounded-xl border border-emerald-400/20 shadow-[0_0_15px_rgba(16,185,129,0.15)]">
          <Users className="w-5 h-5" />
        </div>
      </div>

      {/* Metric 3: Nómina Mensual & Quincenal (Oculto para guardias y roles sin permiso) */}
      {canViewSalaries ? (
        <div className="liquid-glass-interactive rounded-2xl p-5 flex items-start justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/10 rounded-full blur-xl -z-10 group-hover:bg-cyan-500/20 transition-all"></div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Planilla Quincenal Aprox.
            </span>
            <span className="text-2xl font-extrabold text-cyan-300 mt-1.5 block tabular-nums tracking-tight">
              {formatCurrencyGTQ(estimatedQuincenalPayroll)}
            </span>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Mensual total: {formatCurrencyGTQ(totalMonthlyPayroll)}
            </span>
          </div>
          <div className="p-3 bg-cyan-500/15 text-cyan-400 rounded-xl border border-cyan-400/20 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>
      ) : (
        <div className="liquid-glass-interactive rounded-2xl p-5 flex items-start justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 rounded-full blur-xl -z-10 group-hover:bg-purple-500/20 transition-all"></div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Puesto de Garita
            </span>
            <span className="text-base font-bold text-purple-300 mt-1.5 block tracking-tight truncate max-w-[200px]" title={currentUser.stationName || 'Guardia de Seguridad'}>
              {currentUser.stationName || 'Garita Central'}
            </span>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Sueldos y deducciones confidenciales
            </span>
          </div>
          <div className="p-3 bg-purple-500/15 text-purple-400 rounded-xl border border-purple-400/20 shadow-[0_0_15px_rgba(168,85,247,0.15)]">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      )}

      {/* Metric 4: Auditoría o Marcajes de Seguridad */}
      {canViewAudit ? (
        <div className="liquid-glass-interactive rounded-2xl p-5 flex items-start justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-xl -z-10 group-hover:bg-amber-500/20 transition-all"></div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Auditoría de Cambios
            </span>
            <span className="text-2xl font-extrabold text-white mt-1.5 block tabular-nums tracking-tight">
              {auditLogs.length}
            </span>
            <span className="text-[11px] text-amber-400 font-medium mt-1 block">
              {criticalAuditCount} ajustes salariales / bajas
            </span>
          </div>
          <div className="p-3 bg-amber-500/15 text-amber-400 rounded-xl border border-amber-400/20 shadow-[0_0_15px_rgba(245,158,11,0.15)]">
            <History className="w-5 h-5" />
          </div>
        </div>
      ) : (
        <div className="liquid-glass-interactive rounded-2xl p-5 flex items-start justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl -z-10 group-hover:bg-emerald-500/20 transition-all"></div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Marcajes de Guardia QR
            </span>
            <span className="text-2xl font-extrabold text-emerald-400 mt-1.5 block tabular-nums tracking-tight">
              {guardCheckins.length}
            </span>
            <span className="text-[11px] text-emerald-300 font-medium mt-1 block">
              Entradas y salidas satelitales
            </span>
          </div>
          {/* Icono QR eliminado */}
          <div className="p-3 bg-emerald-500/15 text-emerald-400 rounded-xl border border-emerald-400/20 shadow-[0_0_15px_rgba(16,185,129,0.15)]">
            <History className="w-5 h-5" />
          </div>
        </div>
      )}

    </div>
  );
};
