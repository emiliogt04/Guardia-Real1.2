import React, { useState, useEffect } from 'react';
import { Package, Search, Plus, Save, Table, LayoutGrid, AlertCircle, CheckCircle2 } from 'lucide-react';
import { AppUser, SystemSecurityConfig } from '../types';

interface Props {
  currentUser: AppUser;
  securityConfig: SystemSecurityConfig | null;
  onUpdateSecurityConfig: (config: Partial<SystemSecurityConfig>) => Promise<void>;
}

export const InventoryView: React.FC<Props> = ({ currentUser, securityConfig, onUpdateSecurityConfig }) => {
  const [inventoryList, setInventoryList] = useState(securityConfig?.inventoryItems || []);
  const [inventorySearchQuery, setInventorySearchQuery] = useState('');
  const [selectedInventoryCategory, setSelectedInventoryCategory] = useState('TODOS');
  const [inventoryViewMode, setInventoryViewMode] = useState<'TABLE' | 'CARDS'>('TABLE');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [recentlyAddedItemId, setRecentlyAddedItemId] = useState<string | null>(null);
  const [isSavingAllPrices, setIsSavingAllPrices] = useState(false);

  useEffect(() => {
    if (securityConfig && securityConfig.inventoryItems) {
      setInventoryList(securityConfig.inventoryItems);
    }
  }, [securityConfig]);

  const handleUpdateItemStockOrPrice = async (id: string, newStock: number, newPrice: number) => {
    try {
      const res = await fetch(`/api/security/inventory/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': currentUser.id,
        },
        body: JSON.stringify({ stock: newStock, price: newPrice }),
      });
      if (!res.ok) throw new Error('Error al actualizar inventario');
      
      const updatedData = await res.json();
      setInventoryList(updatedData.inventoryItems);
      await onUpdateSecurityConfig({ inventoryItems: updatedData.inventoryItems, uniformPrices: updatedData.uniformPrices });
      setSuccessMsg('Artículo actualizado exitosamente.');
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err: any) {
      setErrorMsg(err.message);
    }
  };

  const filtered = inventoryList.filter(item => {
    const matchesSearch = !inventorySearchQuery.trim() || 
      item.name.toLowerCase().includes(inventorySearchQuery.toLowerCase());
    const matchesCat = selectedInventoryCategory === 'TODOS' || item.category === selectedInventoryCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6 animate-in fade-in pb-12">
      <div className="liquid-glass p-6 rounded-3xl border border-white/10 flex justify-between items-center">
        <h1 className="text-xl font-black text-white flex items-center gap-3">
          <Package className="w-7 h-7 text-amber-400" />
          <span>Gestión de Inventario y Stock</span>
        </h1>
      </div>

      {successMsg && <div className="p-4 rounded-2xl bg-emerald-500/15 text-emerald-300 text-xs">{successMsg}</div>}
      {errorMsg && <div className="p-4 rounded-2xl bg-rose-500/15 text-rose-300 text-xs">{errorMsg}</div>}

      <div className="liquid-glass p-6 rounded-3xl border border-white/10">
        <div className="flex gap-4 mb-6">
           <input
             type="text"
             value={inventorySearchQuery}
             onChange={e => setInventorySearchQuery(e.target.value)}
             placeholder="Buscar artículo..."
             className="flex-1 px-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs"
           />
           <select
             value={selectedInventoryCategory}
             onChange={e => setSelectedInventoryCategory(e.target.value)}
             className="px-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs"
           >
             <option value="TODOS">Todas las categorías</option>
             {['Prenda / Uniforme', 'Calzado', 'Equipo Táctico', 'Accesorio'].map(cat => (
               <option key={cat} value={cat}>{cat}</option>
             ))}
           </select>
        </div>

        <table className="w-full text-left text-xs text-white">
          <thead>
            <tr className="border-b border-white/10 text-slate-400 uppercase text-[10px]">
              <th className="py-3 px-3">Artículo</th>
              <th className="py-3 px-3">Precio (Q)</th>
              <th className="py-3 px-3">Stock</th>
              <th className="py-3 px-3">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {filtered.map(item => (
              <tr key={item.id}>
                <td className="py-3 px-3">{item.name}</td>
                <td className="py-3 px-3">
                  <input
                    type="number"
                    defaultValue={item.price}
                    className="w-20 px-2 py-1 rounded bg-black/50 border border-white/10"
                    onBlur={(e) => handleUpdateItemStockOrPrice(item.id, item.stock, Number(e.target.value))}
                  />
                </td>
                <td className="py-3 px-3">
                  <input
                    type="number"
                    defaultValue={item.stock}
                    className="w-20 px-2 py-1 rounded bg-black/50 border border-white/10"
                    onBlur={(e) => handleUpdateItemStockOrPrice(item.id, Number(e.target.value), item.price)}
                  />
                </td>
                <td className="py-3 px-3 text-emerald-400">Actualizado</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
