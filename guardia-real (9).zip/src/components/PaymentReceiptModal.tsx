import React, { useState } from 'react';
import { X, Printer, Download, CheckCircle2, ShieldCheck, DollarSign, Calendar, FileText, Loader2 } from 'lucide-react';
import { PaymentReceipt } from '../types';
import { exportReceiptToPDF } from '../utils/receiptPdfExport';
import { formatDPI } from '../utils/formatters';
import guardiaRealLogo from '../assets/guardia_real_logo.jpg';

interface PaymentReceiptModalProps {
  receipt: PaymentReceipt | null;
  onClose: () => void;
  companyName?: string;
  companyNit?: string;
}

export const PaymentReceiptModal: React.FC<PaymentReceiptModalProps> = ({
  receipt,
  onClose,
  companyName = 'GUARDIA REAL DE GUATEMALA',
  companyNit = 'NIT: 9812401-2',
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  if (!receipt) return null;

  const handleExportPdf = async () => {
    try {
      setIsExporting(true);
      await exportReceiptToPDF(receipt, companyName, companyNit);
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 2500);
    } catch (err) {
      console.error('Error al exportar recibo a PDF:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in custom-scrollbar">
      <div className="liquid-glass-elevated rounded-3xl max-w-2xl w-full p-5 sm:p-7 border border-white/20 my-auto shadow-2xl relative space-y-5">
        
        {/* Header con acciones */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 print:hidden">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/30">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Comprobante de Pago Oficial
              </h3>
              <p className="text-[11px] text-slate-400">
                Formato Carta (1 por Hoja) · Recibo No. #{receipt.id.slice(0, 8).toUpperCase()}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportPdf}
              disabled={isExporting}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
                exportSuccess
                  ? 'bg-emerald-500 text-slate-950 font-bold'
                  : 'bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950'
              }`}
              title="Descargar Comprobante en formato Hoja Tamaño Carta (1 por Hoja)"
            >
              {isExporting ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Generando PDF...</span>
                </>
              ) : exportSuccess ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-slate-950" />
                  <span>¡PDF Guardado!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar PDF (Hoja Carta)</span>
                </>
              )}
            </button>

            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95"
              title="Imprimir Comprobante en impresora o guardar"
            >
              <Printer className="w-3.5 h-3.5 text-slate-300" />
              <span className="hidden sm:inline">Imprimir</span>
            </button>

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Voucher Imprimible */}
        <div id="printable-receipt" className="bg-white text-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-300 shadow-lg space-y-5 font-sans relative overflow-hidden">
          {/* Fondo / Marca de agua con el logo institucional */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
            <img 
              src={guardiaRealLogo} 
              alt="Logo Watermark" 
              className="w-[340px] h-[340px] object-contain opacity-[0.05] grayscale" 
            />
          </div>

          <div className="relative z-10 space-y-5">
            {/* Encabezado del Recibo con Logo Oficial Guardia Real */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between pb-4 border-b-2 border-slate-800 gap-3">
            <div className="flex items-center gap-3">
              <img 
                src={guardiaRealLogo} 
                alt="Logo Guardia Real" 
                className="w-16 h-16 object-contain rounded-xl drop-shadow-md shrink-0 border border-slate-200 bg-slate-50 p-0.5" 
              />
              <div>
                <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight uppercase">
                  {companyName}
                </h2>
                <p className="text-[11px] text-slate-600 font-medium mt-0.5">
                  Seguridad Privada & Servicios Especializados de Vigilancia GT
                </p>
                <p className="text-[10px] text-slate-500 font-mono">
                  {companyNit} · República de Guatemala · Nómina Oficial
                </p>
              </div>
            </div>

            <div className="sm:text-right bg-slate-100 p-2.5 rounded-xl border border-slate-300 shrink-0">
              <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-800 block">
                COMPROBANTE DE PAGO
              </span>
              <span className="text-base font-black font-mono text-slate-900">
                NO. {receipt.id.slice(0, 8).toUpperCase()}
              </span>
              <span className="text-[10px] font-bold text-slate-500 block uppercase">
                ORIGINAL - ADMINISTRACIÓN
              </span>
              <span className="text-[11px] text-slate-700 block font-semibold mt-0.5">
                Fecha: {String(receipt.day).padStart(2, '0')}/{String(receipt.month).padStart(2, '0')}/{receipt.year}
              </span>
            </div>
          </div>

          {/* Cuadro de Monto Principal */}
          <div className="p-4 rounded-xl bg-cyan-50 border-2 border-cyan-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] uppercase font-bold text-cyan-900 block">
                Valor Total Liquidado:
              </span>
              <span className="text-2xl sm:text-3xl font-black font-mono text-cyan-900">
                Q {receipt.amount.toFixed(2)}
              </span>
            </div>
            <div className="sm:text-right max-w-sm">
              <span className="text-[10px] uppercase font-bold text-slate-600 block">
                Cantidad en Letras:
              </span>
              <span className="text-xs font-bold text-slate-900 uppercase">
                {receipt.amountInWords || `${receipt.amount.toFixed(2)} QUETZALES EXACTOS`}
              </span>
            </div>
          </div>

          {/* Datos del Beneficiario y Detalle */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-1">
            <div className="space-y-1 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Datos del Colaborador (Guardia):
              </span>
              <p className="font-bold text-slate-900 text-sm">
                {receipt.employeeName}
              </p>
              {receipt.employeeDpi && (
                <p className="text-slate-600 font-mono">
                  DPI: <strong>{receipt.employeeDpi}</strong>
                </p>
              )}
            </div>

            <div className="space-y-1 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Detalles del Método de Pago:
              </span>
              <p className="font-semibold text-slate-800">
                Forma: <strong>{receipt.paymentMethod || 'TRANSFERENCIA BANCARIA'}</strong>
              </p>
              {receipt.referenceNumber && (
                <p className="text-slate-600 font-mono">
                  Referencia / Boleta: <strong>{receipt.referenceNumber}</strong>
                </p>
              )}
            </div>
          </div>

          {/* Concepto del Pago */}
          <div className="p-3.5 rounded-xl bg-slate-100 border border-slate-300 space-y-1 text-xs">
            <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider block">
              Por Concepto De:
            </span>
            <p className="font-semibold text-slate-900 leading-relaxed">
              {receipt.concept}
            </p>
            {receipt.observations && (
              <p className="text-[11px] text-slate-600 italic pt-1 border-t border-slate-200">
                Observaciones: {receipt.observations}
              </p>
            )}
          </div>

          {/* Cuadro de Firma Exclusiva del Colaborador (Firma de Recibido) */}
          <div className="pt-8 flex justify-center text-center text-xs">
            <div className="w-80 space-y-1">
              <div className="border-t-2 border-slate-800 pt-2.5">
                <p className="font-black text-slate-900 text-sm uppercase tracking-wide">
                  {receipt.employeeName}
                </p>
                {receipt.employeeDpi && (
                  <p className="text-[11px] text-slate-600 font-mono font-medium">
                    DPI: {formatDPI(receipt.employeeDpi)}
                  </p>
                )}
                <p className="text-[10px] text-cyan-800 font-extrabold uppercase tracking-wider mt-1">
                  Firma de Conforme / Recibido (Colaborador)
                </p>
                <p className="text-[9px] text-slate-400 italic">
                  Recibí a mi entera satisfacción el valor liquidado correspondiente
                </p>
              </div>
            </div>
          </div>

          <div className="text-[9px] text-center text-slate-400 pt-2 border-t border-slate-200">
            Este documento constituye constancia y comprobante legal de liquidación de sueldo o anticipo laboral · Guardia Real Guatemala.
          </div>
          </div>
        </div>

        {/* Footer del modal */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/10 print:hidden">
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportPdf}
              disabled={isExporting}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
                exportSuccess
                  ? 'bg-emerald-500 text-slate-950 font-bold'
                  : 'bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950'
              }`}
            >
              {isExporting ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Generando PDF...</span>
                </>
              ) : exportSuccess ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-slate-950" />
                  <span>¡PDF Guardado!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar PDF (Hoja Carta)</span>
                </>
              )}
            </button>

            <button
              onClick={handlePrint}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <Printer className="w-3.5 h-3.5 text-slate-300" />
              <span>Imprimir</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-300 bg-white/10 hover:bg-white/15 rounded-xl transition-colors"
          >
            Cerrar Comprobante
          </button>
        </div>

      </div>
    </div>
  );
};
