import React, { useState } from 'react';
import { 
  X, 
  Check, 
  Sparkles, 
  Sun, 
  Moon, 
  Image as ImageIcon, 
  Trash2, 
  Upload, 
  Smartphone, 
  Monitor,
  Droplets
} from 'lucide-react';
import { AppThemeMode, CrystalColor, AppThemeSettings, AppUser } from '../types';

interface ThemeSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: AppUser | null;
  themeSettings: AppThemeSettings;
  onSelectTheme: (newSettings: AppThemeSettings) => void;
  onUpdatePersonalWallpaper?: (url?: string) => Promise<void>;
}

export const ThemeSelectorModal: React.FC<ThemeSelectorModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  themeSettings,
  onSelectTheme,
  onUpdatePersonalWallpaper,
}) => {
  const [customWallpaper, setCustomWallpaper] = useState<string>(
    themeSettings.customWallpaperUrl || currentUser?.personalWallpaperUrl || ''
  );
  const [isSavingWallpaper, setIsSavingWallpaper] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const isGuard = currentUser?.role === 'GUARD';

  if (!isOpen) return null;

  const crystalOptions: { id: CrystalColor; name: string; colorHex: string; glowClass: string }[] = [
    { id: 'cyan', name: 'Cristal Cyan Neón', colorHex: '#06b6d4', glowClass: 'bg-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.7)]' },
    { id: 'blue', name: 'Cristal Azul Zafiro', colorHex: '#3b82f6', glowClass: 'bg-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.7)]' },
    { id: 'emerald', name: 'Cristal Esmeralda', colorHex: '#10b981', glowClass: 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.7)]' },
    { id: 'purple', name: 'Cristal Amatista', colorHex: '#a855f7', glowClass: 'bg-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.7)]' },
    { id: 'amber', name: 'Cristal Ámbar Dorado', colorHex: '#f59e0b', glowClass: 'bg-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.7)]' },
    { id: 'rose', name: 'Cristal Rubí Rosa', colorHex: '#f43f5e', glowClass: 'bg-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.7)]' },
  ];

  // Temas del dispositivo y computadora predefinidos
  const deviceThemes = [
    { name: 'Titanio Grafito', url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1920&q=80' },
    { name: 'Obsidiana Espacial', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1920&q=80' },
    { name: 'Ciudad Nocturna', url: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1920&q=80' },
    { name: 'Reflejo Azul', url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=1920&q=80' },
    { name: 'Minimalista Dark', url: 'https://images.unsplash.com/photo-1507499739999-097706ad8914?auto=format&fit=crop&w=1920&q=80' },
  ];

  const handleApplyWallpaper = async (url?: string) => {
    try {
      setIsSavingWallpaper(true);
      const targetUrl = url !== undefined ? url : customWallpaper.trim();
      onSelectTheme({
        ...themeSettings,
        customWallpaperUrl: targetUrl || undefined,
      });
      if (onUpdatePersonalWallpaper) {
        await onUpdatePersonalWallpaper(targetUrl || undefined);
      }
    } catch (e) {
      console.warn('Error saving wallpaper:', e);
    } finally {
      setIsSavingWallpaper(false);
    }
  };

  // Subir imagen directamente desde el dispositivo / computadora
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Por favor selecciona un archivo de imagen válido (PNG, JPG, WEBP).');
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      alert('La imagen no debe superar los 8MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64Url = event.target?.result as string;
      if (base64Url) {
        setCustomWallpaper(base64Url);
        setUploadStatus('Imagen cargada desde tu dispositivo.');
        await handleApplyWallpaper(base64Url);
        setTimeout(() => setUploadStatus(null), 3000);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in overflow-y-auto">
      <div className="liquid-glass-elevated rounded-3xl max-w-xl w-full p-6 border shadow-2xl relative my-auto max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/40 shadow-[0_0_15px_rgba(6,182,212,0.4)]">
              <Droplets className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">Personalización Liquid Glass</h3>
              <p className="text-xs text-slate-400">El efecto de cristal líquido se aplica a los bordes y marcos de los cuadros</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-5">
          
          {/* SECCIÓN 1: TONO DE LOS CUADROS (OSCURO O CLARO) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-300">
                1. Tono de los Cuadros (Superficie de Cristal Líquido):
              </span>
              <span className="text-[10px] text-cyan-400 font-mono">
                {themeSettings.mode === 'liquid-glass-dark' 
                  ? 'Liquid Glass Oscuro' 
                  : (themeSettings.mode === 'liquid-glass-light-blue' ? 'Liquid Glass Claro Cristal Azul' : 'Liquid Glass Claro')}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Opción 1: Liquid Glass Claro */}
              <button
                type="button"
                onClick={() => onSelectTheme({ ...themeSettings, mode: 'liquid-glass-light' })}
                className={`p-3.5 rounded-2xl border text-left transition-all flex flex-col gap-2 relative ${
                  themeSettings.mode === 'liquid-glass-light'
                    ? 'bg-white/30 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.4)] ring-2 ring-cyan-400/50'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded-xl bg-white text-slate-900 flex items-center justify-center shadow-md">
                    <Sun className="w-4 h-4 text-amber-500" />
                  </div>
                  {themeSettings.mode === 'liquid-glass-light' && (
                    <div className="w-5 h-5 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">Liquid Glass Claro</span>
                  <span className="text-[10px] text-slate-300">Cristal blanco escarchado con bordes luminosos</span>
                </div>
              </button>

              {/* Opción 2: Liquid Glass Claro Cristal Azul */}
              <button
                type="button"
                onClick={() => onSelectTheme({ ...themeSettings, mode: 'liquid-glass-light-blue' })}
                className={`p-3.5 rounded-2xl border text-left transition-all flex flex-col gap-2 relative ${
                  themeSettings.mode === 'liquid-glass-light-blue'
                    ? 'bg-sky-500/25 border-sky-400 shadow-[0_0_20px_rgba(56,189,248,0.4)] ring-2 ring-sky-400/50'
                    : 'bg-sky-950/20 border-white/10 hover:bg-sky-900/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded-xl bg-sky-500/30 text-sky-300 flex items-center justify-center shadow-md border border-sky-400/40">
                    <Droplets className="w-4 h-4 text-sky-300" />
                  </div>
                  {themeSettings.mode === 'liquid-glass-light-blue' && (
                    <div className="w-5 h-5 rounded-full bg-sky-400 text-slate-950 flex items-center justify-center">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">Liquid Glass Claro Cristal Azul</span>
                  <span className="text-[10px] text-sky-200">Cristal translúcido con tinte y bordes azul cobalto</span>
                </div>
              </button>

              {/* Opción 3: Liquid Glass Oscuro */}
              <button
                type="button"
                onClick={() => onSelectTheme({ ...themeSettings, mode: 'liquid-glass-dark' })}
                className={`p-3.5 rounded-2xl border text-left transition-all flex flex-col gap-2 relative ${
                  themeSettings.mode === 'liquid-glass-dark'
                    ? 'bg-slate-900/90 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.4)] ring-2 ring-cyan-400/50'
                    : 'bg-black/50 border-white/10 hover:bg-black/70'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded-xl bg-slate-950 text-cyan-400 flex items-center justify-center shadow-md border border-cyan-400/40">
                    <Moon className="w-4 h-4" />
                  </div>
                  {themeSettings.mode === 'liquid-glass-dark' && (
                    <div className="w-5 h-5 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">Liquid Glass Oscuro</span>
                  <span className="text-[10px] text-slate-400">Obsidiana profunda con halo de cristal líquido</span>
                </div>
              </button>
            </div>
          </div>

          {/* SECCIÓN 2: COLOR DE CRISTAL LÍQUIDO PARA LOS BORDES */}
          <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-200 block">
                  2. Color de Cristal Líquido (Bordes de los Cuadros):
                </span>
                <span className="text-[10px] text-slate-400">
                  Ilumina el marco, halo y reflejo óptico de cada tarjeta y recuadro
                </span>
              </div>
              <span className="text-xs text-cyan-400 font-bold">
                {crystalOptions.find(c => c.id === themeSettings.crystalColor)?.name}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {crystalOptions.map(opt => {
                const isSelected = themeSettings.crystalColor === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => onSelectTheme({ ...themeSettings, crystalColor: opt.id })}
                    className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-semibold transition-all ${
                      isSelected
                        ? 'border-white text-white bg-white/20 shadow-lg ring-1 ring-white/50'
                        : 'border-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/5'
                    }`}
                  >
                    <span className={`w-3.5 h-3.5 rounded-full shrink-0 ${opt.glowClass}`}></span>
                    <span className="truncate">{opt.name.replace('Cristal ', '')}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECCIÓN 3: FONDO DE PANTALLA (DISPOSITIVO / COMPUTADORA) */}
          <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-cyan-400" />
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-200">
                  3. Fondo de Pantalla (Dispositivo o Computadora):
                </span>
              </div>
              {isGuard && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
                  Asignado por Admin
                </span>
              )}
            </div>

            {isGuard ? (
              <p className="text-xs text-slate-400 leading-snug">
                El fondo de pantalla para los guardias de seguridad es configurado corporativamente por el Administrador Principal para mantener la identidad visual en garita.
              </p>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-slate-300 leading-snug">
                  Puedes subir una foto desde tu teléfono o computadora, o bien elegir un tema del dispositivo:
                </p>

                {/* Subir archivo desde la computadora o teléfono */}
                <div>
                  <input
                    type="file"
                    id="device-wallpaper-input"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <label
                    htmlFor="device-wallpaper-input"
                    className="cursor-pointer w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 border border-cyan-400/40 text-cyan-300 text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md active:scale-98"
                  >
                    <Upload className="w-4 h-4 text-cyan-400" />
                    <span>Elegir Fondo de tu Teléfono o Computadora</span>
                  </label>
                  {uploadStatus && (
                    <span className="text-[11px] text-emerald-400 font-semibold block text-center mt-1">
                      ✓ {uploadStatus}
                    </span>
                  )}
                </div>

                {/* Temas del dispositivo predefinidos */}
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                    Temas del Sistema Predefinidos:
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {deviceThemes.map(w => (
                      <button
                        key={w.name}
                        type="button"
                        onClick={() => {
                          setCustomWallpaper(w.url);
                          handleApplyWallpaper(w.url);
                        }}
                        className="p-1 rounded-xl border border-white/5 bg-black/60 hover:bg-white/10 transition-all text-left group"
                      >
                        <div
                          className="h-10 w-full rounded-lg bg-cover bg-center mb-1 group-hover:scale-102 transition-transform"
                          style={{ backgroundImage: `url(${w.url})` }}
                        />
                        <span className="text-[9px] font-semibold text-slate-300 block truncate">
                          {w.name}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* URL personalizada & Limpiar fondo */}
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="url"
                    placeholder="O pega un enlace de imagen (https://...)"
                    value={customWallpaper}
                    onChange={e => setCustomWallpaper(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => handleApplyWallpaper()}
                    disabled={isSavingWallpaper}
                    className="px-3 py-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-semibold shrink-0 hover:bg-cyan-500/30"
                  >
                    Aplicar
                  </button>
                  {(themeSettings.customWallpaperUrl || customWallpaper) && (
                    <button
                      type="button"
                      onClick={() => {
                        setCustomWallpaper('');
                        handleApplyWallpaper('');
                      }}
                      title="Quitar fondo personalizado"
                      className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

              </div>
            )}
          </div>

        </div>

        {/* Footer */}
        <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between">
          <span className="text-[11px] text-slate-400">
            Los bordes de los cuadros reflejan el cristal líquido seleccionado
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 transition-all shadow-[0_0_15px_rgba(6,182,212,0.35)]"
          >
            Listo / Aplicar
          </button>
        </div>

      </div>
    </div>
  );
};
