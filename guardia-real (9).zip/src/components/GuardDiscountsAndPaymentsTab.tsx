import React, { useState } from 'react';
import { 
  DollarSign, 
  Calendar, 
  Trash2, 
  History, 
  Tag, 
  Shirt, 
  Plus, 
  CreditCard, 
  CheckCircle2, 
  Check, 
  Lock,
  Building2,
  Search,
  Package,
  AlertTriangle,
  Edit2,
  X
} from 'lucide-react';
import { Employee, SystemSecurityConfig, GuardPayment, GuardDiscount, GUATEMALA_BANKS } from '../types';
import {
  MONTH_NAMES_ES,
  QuincenaRef,
  currentQuincena,
  quincenaLabel,
  getDiscountProgress,
  getInstallmentNumber,
  getInstallmentAmount,
  isDiscountApplicable,
  INACTIVE_DISCOUNT_STATUSES,
} from '../utils/quincenas';

interface GuardDiscountsAndPaymentsTabProps {
  viewingEmployee: Employee;
  isAdmin: boolean;
  canEdit: boolean;
  securityConfig?: SystemSecurityConfig | null;
  payments: GuardPayment[];
  onAddDiscount?: (employeeId: string, data: { 
    amount: number; 
    reason: string; 
    description?: string; 
    period?: '1RA_QUINCENA' | '2DA_QUINCENA' | 'MENSUAL';
    discountType?: 'ANTICIPO' | 'UNIFORME' | 'OTRO';
    installments?: number;
    installmentAmount?: number;
    date?: string;
    startYear?: number;
    startMonth?: number;
    startQuincena?: 1 | 2;
    uniformItems?: string[];
    uniformItemIds?: string[];
    uniformQuantities?: Record<string, number>;
    uniformItemDetails?: { id: string; name: string; quantity: number; unitPrice: number; subtotal: number }[];
  }) => Promise<void>;
  onDeleteDiscount?: (employeeId: string, discountId: string, reason?: string) => Promise<void>;
  onUpdateDiscountStart?: (employeeId: string, discountId: string, data: { startYear: number; startMonth: number; startQuincena: 1 | 2; installments?: number }) => Promise<void>;
  onRecordPayment?: (paymentData: any) => Promise<void>;
  onOpenAddBankModal?: () => void;
}

export const GuardDiscountsAndPaymentsTab: React.FC<GuardDiscountsAndPaymentsTabProps> = ({
  viewingEmployee,
  isAdmin,
  canEdit,
  securityConfig,
  payments,
  onAddDiscount,
  onDeleteDiscount,
  onUpdateDiscountStart,
  onRecordPayment,
  onOpenAddBankModal,
}) => {
  const [selectedHistoryMonth, setSelectedHistoryMonth] = useState<string>('ALL');
  const [discountTypeOption, setDiscountTypeOption] = useState<'ANTICIPO' | 'UNIFORME'>('ANTICIPO');
  
  // Uniform inventory state
  const inventoryItems = securityConfig?.inventoryItems || [];
  const [selectedInventoryIds, setSelectedInventoryIds] = useState<string[]>([]);
  const [selectedInventoryQuantities, setSelectedInventoryQuantities] = useState<Record<string, number>>({});
  const [inventorySearch, setInventorySearch] = useState<string>('');
  const [inventoryCategoryFilter, setInventoryCategoryFilter] = useState<string>('TODOS');
  const [uniformInstallments, setUniformInstallments] = useState<number>(1);
  const [uniformDate, setUniformDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [uniformNotes, setUniformNotes] = useState<string>('');

  // Quincena de inicio del descuento: por defecto la quincena que se está trabajando (editable)
  const [startQ, setStartQ] = useState<QuincenaRef>(() => currentQuincena());
  // Edición de la quincena de inicio de un descuento ya creado
  const [editingDiscountId, setEditingDiscountId] = useState<string | null>(null);
  const [editStart, setEditStart] = useState<QuincenaRef>(() => currentQuincena());
  const [editInstallments, setEditInstallments] = useState<number>(1);
  const [isSavingEdit, setIsSavingEdit] = useState<boolean>(false);
  const yearOptions = Array.from({ length: 6 }, (_, i) => new Date().getFullYear() - 2 + i);

  // En el formulario de añadir descuento, usar este estado para la fecha:
  // <input type="date" value={uniformDate} onChange={(e) => setUniformDate(e.target.value)} ... />


  // Payment form state
  const [paymentPeriod, setPaymentPeriod] = useState<'1RA_QUINCENA' | '2DA_QUINCENA'>('1RA_QUINCENA');
  const [paymentMonth, setPaymentMonth] = useState<number>(new Date().getMonth() + 1);
  const [paymentYear, setPaymentYear] = useState<number>(new Date().getFullYear());
  const [paymentBank, setPaymentBank] = useState<string>('Banco Industrial (BI)');
  const [paymentMethod, setPaymentMethod] = useState<'TRANSFERENCIA' | 'EFECTIVO'>('TRANSFERENCIA');
  const [paymentReference, setPaymentReference] = useState<string>('');
  const [customPaymentAmount, setCustomPaymentAmount] = useState<string>('');
  const [paymentNotes, setPaymentNotes] = useState<string>('');
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [paymentSuccessMsg, setPaymentSuccessMsg] = useState<string | null>(null);

  // All banks including custom ones
  const availableBanks = [
    ...GUATEMALA_BANKS,
    ...(securityConfig?.customBanks || [])
  ];

  // La lista usa siempre la versión vigente de cada descuento (cuotas cobradas y estado actualizados)
  const liveDiscounts = new Map<string, GuardDiscount>((viewingEmployee.discounts || []).map(d => [d.id, d] as [string, GuardDiscount]));
  const fullHistory: GuardDiscount[] = ((viewingEmployee.discountHistory && viewingEmployee.discountHistory.length > 0)
    ? viewingEmployee.discountHistory
    : (viewingEmployee.discounts || [])).map(h => liveDiscounts.get(h.id) || h);

  const monthsWithMovements = Array.from(new Set<string>(fullHistory.map((d): string => {
    if (d.date && d.date.length >= 7) return d.date.slice(0, 7);
    return new Date().toISOString().slice(0, 7);
  }))).sort().reverse();

  const monthsNamesMap: Record<string, string> = {
    '01': 'Enero', '02': 'Febrero', '03': 'Marzo', '04': 'Abril',
    '05': 'Mayo', '06': 'Junio', '07': 'Julio', '08': 'Agosto',
    '09': 'Septiembre', '10': 'Octubre', '11': 'Noviembre', '12': 'Diciembre'
  };

  const formatMonthLabel = (yyyyMm: string) => {
    const [y, m] = yyyyMm.split('-');
    return `${monthsNamesMap[m] || m} ${y}`;
  };

  const filteredDiscounts = selectedHistoryMonth === 'ALL'
    ? fullHistory
    : fullHistory.filter(d => (d.date && d.date.startsWith(selectedHistoryMonth)));

  const activeDiscounts = filteredDiscounts.filter(d => d.status !== 'ELIMINADO');
  const deletedDiscounts = filteredDiscounts.filter(d => d.status === 'ELIMINADO');
  // Saldo pendiente: solo descuentos vigentes, por las cuotas que aún faltan por cobrar
  const totalActiveSum = (viewingEmployee.discounts || [])
    .filter(d => !INACTIVE_DISCOUNT_STATUSES.includes(d.status || ''))
    .reduce((s, d) => s + getDiscountProgress(d).remainingAmount, 0);

  // Selector reutilizable de quincena (año / mes / quincena)
  const renderQuincenaPicker = (value: QuincenaRef, onChange: (q: QuincenaRef) => void) => (
    <div className="grid grid-cols-3 gap-1.5">
      <select
        value={value.quincena}
        onChange={e => onChange({ ...value, quincena: Number(e.target.value) as 1 | 2 })}
        className="px-2 py-2 rounded-xl liquid-glass-input text-xs font-bold text-white bg-slate-900"
      >
        <option value={1} className="bg-slate-900">1ra quincena</option>
        <option value={2} className="bg-slate-900">2da quincena</option>
      </select>
      <select
        value={value.month}
        onChange={e => onChange({ ...value, month: Number(e.target.value) })}
        className="px-2 py-2 rounded-xl liquid-glass-input text-xs font-bold text-white bg-slate-900"
      >
        {MONTH_NAMES_ES.map((m, i) => <option key={m} value={i + 1} className="bg-slate-900">{m}</option>)}
      </select>
      <select
        value={value.year}
        onChange={e => onChange({ ...value, year: Number(e.target.value) })}
        className="px-2 py-2 rounded-xl liquid-glass-input text-xs font-bold text-white bg-slate-900"
      >
        {Array.from(new Set([...yearOptions, value.year])).sort().map(y => <option key={y} value={y} className="bg-slate-900">{y}</option>)}
      </select>
    </div>
  );

  // Uniform prices
  const uniformPrices = {
    gorra: securityConfig?.uniformPrices?.gorra ?? 60,
    pantalon: securityConfig?.uniformPrices?.pantalon ?? 180,
    botas: securityConfig?.uniformPrices?.botas ?? 250,
    camisaCafe: securityConfig?.uniformPrices?.camisaCafe ?? 120,
    playeraPolo: securityConfig?.uniformPrices?.playeraPolo ?? 90,
  };

  let totalUniformCalculated = 0;
  const itemsSelected: string[] = [];
  const uniformItemIdsSelected: string[] = [];
  const uniformQuantitiesSelected: Record<string, number> = {};
  const uniformItemDetailsSelected: { id: string; name: string; quantity: number; unitPrice: number; subtotal: number }[] = [];

  for (const invId of selectedInventoryIds) {
    const item = inventoryItems.find(i => i.id === invId);
    if (item) {
      const qty = Math.max(1, selectedInventoryQuantities[invId] || 1);
      const subtotal = item.price * qty;
      totalUniformCalculated += subtotal;
      itemsSelected.push(qty > 1 ? `${qty}x ${item.name} (Q${subtotal.toFixed(2)})` : `${item.name} (Q${item.price.toFixed(2)})`);
      uniformItemIdsSelected.push(item.id);
      uniformQuantitiesSelected[item.id] = qty;
      uniformItemDetailsSelected.push({
        id: item.id,
        name: item.name,
        quantity: qty,
        unitPrice: item.price,
        subtotal,
      });
    }
  }

  const safeInstallments = Math.max(1, Math.min(7, uniformInstallments || 1));
  const installmentCalculated = totalUniformCalculated / safeInstallments;

  // Financial calculations for fortnight payment
  const monthsList = [
    { value: 1, label: 'Enero' },
    { value: 2, label: 'Febrero' },
    { value: 3, label: 'Marzo' },
    { value: 4, label: 'Abril' },
    { value: 5, label: 'Mayo' },
    { value: 6, label: 'Junio' },
    { value: 7, label: 'Julio' },
    { value: 8, label: 'Agosto' },
    { value: 9, label: 'Septiembre' },
    { value: 10, label: 'Octubre' },
    { value: 11, label: 'Noviembre' },
    { value: 12, label: 'Diciembre' },
  ];

  const halfSalary = (viewingEmployee.monthlySalary || 0) / 2;
  const igssPercent = securityConfig?.igssPercentage ?? 4.83;
  const igssAmount = viewingEmployee.appliesIGSS ? (halfSalary * igssPercent / 100) : 0;

  // Descuentos de la quincena que se está pagando: solo los que caen dentro de su rango de cuotas
  const paymentQuincena: QuincenaRef = { year: paymentYear, month: paymentMonth, quincena: paymentPeriod === '2DA_QUINCENA' ? 2 : 1 };
  const activePeriodDiscounts = (viewingEmployee.discounts || [])
    .filter(d => isDiscountApplicable(d, paymentQuincena))
    .reduce((sum, d) => sum + getInstallmentAmount(d, getInstallmentNumber(d, paymentQuincena) || 1), 0);

  const calculatedNetQuincena = Math.max(0, halfSalary - igssAmount - activePeriodDiscounts);

  const existingPaidRecord = payments.find(p => 
    p.employeeId === viewingEmployee.id && 
    p.period === paymentPeriod && 
    p.month === paymentMonth && 
    p.year === paymentYear &&
    p.status === 'PAGADO'
  );

  return (
    <div className="space-y-5">
      {/* ========================================================================= */}
      {/* 1. SECCIÓN: MOVIMIENTOS & DESCUENTOS POR MES                              */}
      {/* ========================================================================= */}
      <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-white/5 gap-2">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Movimientos & Descuentos por Mes:
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-bold text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20">
              Total Activo Pendiente: Q{totalActiveSum.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Selector de Mes para Historial de Movimientos */}
        <div className="p-2.5 rounded-xl bg-black/60 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-slate-300 font-semibold">
            <Calendar className="w-3.5 h-3.5 text-cyan-400" />
            <span>Filtrar descuentos por período:</span>
          </div>
          <select
            value={selectedHistoryMonth}
            onChange={e => setSelectedHistoryMonth(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg liquid-glass-input text-xs font-bold text-cyan-300 bg-slate-900 border border-white/10"
          >
            <option value="ALL" className="bg-slate-900 text-white">Todos los Meses (Historial Completo)</option>
            {monthsWithMovements.map(m => (
              <option key={m} value={m} className="bg-slate-900 text-white">
                {formatMonthLabel(m)} ({m})
              </option>
            ))}
          </select>
        </div>

        {/* Lista de Descuentos Activos */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
              Descuentos Activos del Período {selectedHistoryMonth !== 'ALL' ? `(${formatMonthLabel(selectedHistoryMonth)})` : ''}:
            </span>
            <span className="text-[10px] text-slate-400 italic">
              Se deducen solo en las quincenas de su rango de cuotas
            </span>
          </div>

          {activeDiscounts.length === 0 ? (
            <p className="text-xs text-slate-400 italic bg-white/5 p-3 rounded-xl border border-white/5">
              No hay descuentos activos registrados para {selectedHistoryMonth !== 'ALL' ? formatMonthLabel(selectedHistoryMonth) : 'este colaborador'}.
            </p>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto custom-scrollbar pr-1">
              {activeDiscounts.map(disc => (
                <div key={disc.id} className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between gap-3 text-xs">
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-black text-rose-300 text-sm">Q{disc.amount.toFixed(2)}</span>
                      <span className="font-bold text-white">{disc.reason}</span>
                      {(() => {
                        const finished = getDiscountProgress(disc).finished || disc.status === 'FINALIZADO';
                        const inactive = disc.status === 'CANCELADO';
                        return (
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase border ${
                            finished
                              ? 'bg-slate-500/20 text-slate-300 border-slate-500/30'
                              : inactive
                                ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                                : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                          }`}>
                            {finished ? 'Finalizado' : inactive ? 'Cancelado' : 'Activo'}
                          </span>
                        );
                      })()}
                      {disc.discountType && (
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          disc.discountType === 'UNIFORME' 
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' 
                            : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        }`}>
                          {disc.discountType === 'UNIFORME' ? 'Uniforme' : 'Anticipo'}
                        </span>
                      )}
                    </div>
                    {(() => {
                      const prog = getDiscountProgress(disc);
                      return (
                        <div className="flex flex-wrap items-center gap-1.5 mt-1.5 text-[10px]">
                          <span className="font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 font-semibold">
                            Q{prog.perInstallment.toFixed(2)} por cuota
                          </span>
                          <span className="font-mono px-1.5 py-0.5 rounded bg-white/5 text-slate-200 border border-white/10">
                            Cuotas aplicadas: <strong>{prog.applied}</strong> de {prog.total}
                          </span>
                          <span className="font-mono px-1.5 py-0.5 rounded bg-white/5 text-slate-200 border border-white/10">
                            Restantes: <strong>{prog.remaining}</strong>
                          </span>
                          {prog.start && (
                            <span className="text-slate-400">
                              Inicia: <strong className="text-cyan-300">{quincenaLabel(prog.start)}</strong>
                              {prog.end && prog.total > 1 && <> · Termina: <strong className="text-cyan-300">{quincenaLabel(prog.end)}</strong></>}
                            </span>
                          )}
                        </div>
                      );
                    })()}
                    {editingDiscountId === disc.id && onUpdateDiscountStart && (
                      <div className="mt-2 p-2.5 rounded-xl bg-black/50 border border-cyan-500/30 space-y-2">
                        <span className="text-[10px] font-bold text-cyan-300 uppercase">Editar quincena de inicio</span>
                        {renderQuincenaPicker(editStart, setEditStart)}
                        <div className="flex items-center gap-2">
                          <label className="text-[10px] font-bold text-slate-300">Cuotas (quincenas):</label>
                          <input
                            type="number"
                            min={1}
                            max={24}
                            value={editInstallments}
                            onChange={e => setEditInstallments(Math.max(1, Math.min(24, Number(e.target.value) || 1)))}
                            className="w-16 px-2 py-1 rounded-lg liquid-glass-input text-xs font-mono font-bold text-white"
                          />
                          <div className="flex-1" />
                          <button
                            type="button"
                            disabled={isSavingEdit}
                            onClick={async () => {
                              setIsSavingEdit(true);
                              try {
                                await onUpdateDiscountStart(viewingEmployee.id, disc.id, {
                                  startYear: editStart.year,
                                  startMonth: editStart.month,
                                  startQuincena: editStart.quincena,
                                  installments: editInstallments,
                                });
                                setEditingDiscountId(null);
                              } catch (err: any) {
                                alert(err.message || 'Error al editar el descuento');
                              } finally {
                                setIsSavingEdit(false);
                              }
                            }}
                            className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold text-[11px] hover:bg-cyan-400 disabled:opacity-50"
                          >
                            {isSavingEdit ? 'Guardando...' : 'Guardar'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingDiscountId(null)}
                            className="p-1.5 rounded-lg bg-white/5 text-slate-300 hover:text-white border border-white/10"
                            title="Cancelar edición"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )}
                    {disc.description && (
                      <p className="text-[11px] text-slate-300 mt-1 leading-snug">{disc.description}</p>
                    )}
                    <div className="flex flex-wrap items-center gap-3 text-[10px] text-slate-400 mt-1">
                      <span>📅 Fecha: <strong>{disc.date}</strong></span>
                      <span>👤 Registró: {disc.appliedBy}</span>
                    </div>
                  </div>
                  {isAdmin && onUpdateDiscountStart && disc.status !== 'CANCELADO' && (
                    <button
                      type="button"
                      onClick={() => {
                        const prog = getDiscountProgress(disc);
                        setEditStart(prog.start || currentQuincena());
                        setEditInstallments(prog.total);
                        setEditingDiscountId(editingDiscountId === disc.id ? null : disc.id);
                      }}
                      className="p-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 transition-colors shrink-0"
                      title="Editar quincena de inicio"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                  )}
                  {canEdit && onDeleteDiscount && (
                    <button
                      onClick={async () => {
                        const confirmMsg = `¿Deseas anular o eliminar este descuento de Q${disc.amount.toFixed(2)} (${disc.reason})?`;
                        if (window.confirm(confirmMsg)) {
                          const reasonPrompt = prompt('Ingresa el motivo de anulación (quedará registrado en el historial):', 'Cancelado por solicitud administrativa');
                          if (reasonPrompt !== null) {
                            try {
                              await onDeleteDiscount(viewingEmployee.id, disc.id, reasonPrompt.trim() || 'Anulado por Administrador');
                            } catch (err: any) {
                              alert(err.message || 'Error al eliminar descuento');
                            }
                          }
                        }
                      }}
                      className="p-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition-colors shrink-0"
                      title="Eliminar descuento y registrar en historial"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Historial de Descuentos Anulados / Eliminados */}
        {deletedDiscounts.length > 0 && (
          <div className="pt-2 border-t border-white/5 space-y-2">
            <div className="flex items-center gap-1.5 text-slate-300">
              <History className="w-3.5 h-3.5 text-rose-400" />
              <span className="text-[11px] font-bold uppercase tracking-wider text-rose-300">
                Historial de Descuentos Cancelados / Anulados ({deletedDiscounts.length}):
              </span>
            </div>

            <div className="space-y-1.5 max-h-36 overflow-y-auto custom-scrollbar pr-1">
              {deletedDiscounts.map(delDisc => (
                <div key={delDisc.id} className="p-2.5 rounded-xl bg-rose-950/20 border border-rose-500/20 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="line-through text-slate-400 font-mono font-bold">
                        Q{delDisc.amount.toFixed(2)}
                      </span>
                      <span className="font-semibold text-slate-200">{delDisc.reason}</span>
                      <span className="text-[9px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold uppercase">
                        Cancelado / Anulado
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {delDisc.deletedAt ? new Date(delDisc.deletedAt).toLocaleString('es-GT', { dateStyle: 'short', timeStyle: 'short' }) : delDisc.date}
                    </span>
                  </div>
                  {delDisc.deletionReason && (
                    <p className="text-[11px] text-rose-300/90 mt-1 italic">
                      Motivo de anulación: "{delDisc.deletionReason}"
                    </p>
                  )}
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    Anulado por: <strong>{delDisc.deletedBy || 'Administrador'}</strong> · Fecha original: {delDisc.date}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* FORMULARIO PARA APLICAR NUEVO DESCUENTO */}
        {canEdit && onAddDiscount && (
          <div className="pt-3 border-t border-white/10 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Tag className="w-4 h-4 text-cyan-400" />
                <span>Aplicar Nuevo Descuento:</span>
              </span>

              <div className="inline-flex p-1 rounded-xl bg-black/60 border border-white/10 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => setDiscountTypeOption('ANTICIPO')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    discountTypeOption === 'ANTICIPO'
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Descuento por Anticipo</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDiscountTypeOption('UNIFORME')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    discountTypeOption === 'UNIFORME'
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Shirt className="w-3.5 h-3.5" />
                  <span>Descuento por Uniforme</span>
                </button>
              </div>
            </div>

            {/* Opción 1: Anticipo */}
            {discountTypeOption === 'ANTICIPO' && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const form = e.currentTarget;
                  const amtInput = form.elements.namedItem('anticipoAmount') as HTMLInputElement;
                  const reasonInput = form.elements.namedItem('anticipoReason') as HTMLInputElement;
                  const descInput = form.elements.namedItem('anticipoDesc') as HTMLInputElement;
                  const dateInput = form.elements.namedItem('anticipoDate') as HTMLInputElement;
                  const installmentsInput = form.elements.namedItem('anticipoInstallments') as HTMLInputElement;

                  const amount = Number(amtInput.value);
                  const reason = reasonInput.value.trim();
                  const description = descInput.value.trim();
                  const date = dateInput.value;
                  const installments = Math.floor(Number(installmentsInput.value || 1));
                  if (!Number.isFinite(installments) || installments < 1 || installments > 24) {
                    alert('El número de cuotas debe ser un entero entre 1 y 24.');
                    return;
                  }

                  if (!amount || amount <= 0) {
                    alert('Ingresa un monto válido mayor a 0 para el anticipo.');
                    return;
                  }
                  if (!reason) {
                    alert('El motivo del anticipo es obligatorio.');
                    return;
                  }
                  if (!date) {
                    alert('La fecha es obligatoria.');
                    return;
                  }

                  try {
                    await onAddDiscount(viewingEmployee.id, {
                      amount,
                      reason: `Anticipo: ${reason}`,
                      description: description || `Descuento por anticipo de sueldo de Q${amount.toFixed(2)}`,
                      date,
                      discountType: 'ANTICIPO',
                      installments,
                      installmentAmount: Math.round((amount / installments) * 100) / 100,
                      startYear: startQ.year,
                      startMonth: startQ.month,
                      startQuincena: startQ.quincena,
                    });
                    amtInput.value = '';
                    reasonInput.value = '';
                    descInput.value = '';
                  } catch (err: any) {
                    alert(err.message || 'Error al aplicar descuento por anticipo');
                  }
                }}
                className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/20 space-y-3"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                  <DollarSign className="w-4 h-4 text-emerald-400" />
                  <span>Formulario de Descuento por Anticipo:</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="text-[10px] font-bold text-slate-300 block mb-1">Monto del Anticipo (Q)</label>
                    <input
                      type="number"
                      step="0.01"
                      name="anticipoAmount"
                      placeholder="Ej. 250.00"
                      required
                      className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-300 block mb-1">Fecha de Aplicación</label>
                    <input
                      type="date"
                      name="anticipoDate"
                      value={uniformDate}
                      onChange={(e) => setUniformDate(e.target.value)}
                      required
                      className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-300 block mb-1">Cuotas (Quincenas)</label>
                    <input
                      type="number"
                      name="anticipoInstallments"
                      defaultValue="1"
                      min="1"
                      max="24"
                      className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 block mb-1">
                    Quincena de inicio (primera cuota){' '}
                    <span className="font-normal text-slate-400">— por defecto: {quincenaLabel(currentQuincena())}</span>
                  </label>
                  {renderQuincenaPicker(startQ, setStartQ)}
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 block mb-1">Motivo del Anticipo</label>
                  <input
                    type="text"
                    name="anticipoReason"
                    placeholder="Ej. Adelanto quincenal, emergencia familiar, préstamo personal"
                    required
                    className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-white"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 block mb-1">Descripción / Observaciones Adicionales</label>
                  <input
                    type="text"
                    name="anticipoDesc"
                    placeholder="Detalles sobre el pago anticipado o comprobante..."
                    className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-slate-300"
                  />
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs hover:from-emerald-400 hover:to-teal-400 transition-all shadow-md flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Aplicar Descuento por Anticipo</span>
                  </button>
                </div>
              </form>
            )}

            {/* Opción 2: Uniforme e Inventario Dinámico */}
            {discountTypeOption === 'UNIFORME' && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (totalUniformCalculated <= 0) {
                    alert('Debes seleccionar al menos un accesorio de uniforme para aplicar el descuento.');
                    return;
                  }

                  const reasonSummary = `Uniforme: ${itemsSelected.join(', ')}`;
                  const descSummary = `Total uniforme: Q${totalUniformCalculated.toFixed(2)} fraccionado en ${safeInstallments} quincena(s) (Q${installmentCalculated.toFixed(2)} c/u). ${uniformNotes.trim()}`;

                  try {
                    await onAddDiscount(viewingEmployee.id, {
                      amount: totalUniformCalculated,
                      reason: reasonSummary,
                      description: descSummary,
                      date: uniformDate,
                      discountType: 'UNIFORME',
                      installments: safeInstallments,
                      installmentAmount: Number(installmentCalculated.toFixed(2)),
                      startYear: startQ.year,
                      startMonth: startQ.month,
                      startQuincena: startQ.quincena,
                      uniformItems: itemsSelected,
                      uniformItemIds: uniformItemIdsSelected,
                      uniformQuantities: uniformQuantitiesSelected,
                      uniformItemDetails: uniformItemDetailsSelected,
                    });
                    setSelectedInventoryIds([]);
                    setSelectedInventoryQuantities({});
                    setUniformNotes('');
                  } catch (err: any) {
                    alert(err.message || 'Error al aplicar descuento por uniforme');
                  }
                }}
                className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/20 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 font-bold text-amber-300">
                    <Shirt className="w-4 h-4 text-amber-400" />
                    <span>Selección de Accesorios del Inventario de Uniformes:</span>
                  </div>
                  <span className="text-[10px] text-amber-400/90 font-medium">
                    📦 Las cantidades entregadas se descontarán automáticamente del inventario
                  </span>
                </div>

                {/* Filtros y Búsqueda de Inventario */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 rounded-xl bg-black/40 border border-white/10 text-xs">
                  <div className="flex items-center gap-2 flex-1">
                    <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      value={inventorySearch}
                      onChange={e => setInventorySearch(e.target.value)}
                      placeholder="Buscar por prenda, bota, gorra, chaleco..."
                      className="w-full bg-transparent border-0 text-xs text-white placeholder-slate-500 focus:outline-none"
                    />
                    {inventorySearch && (
                      <button
                        type="button"
                        onClick={() => setInventorySearch('')}
                        className="text-[10px] text-slate-400 hover:text-white px-1"
                      >
                        Limpiar
                      </button>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-1">
                    {['TODOS', 'Prenda / Uniforme', 'Calzado', 'Equipo Táctico', 'Accesorio'].map(cat => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setInventoryCategoryFilter(cat)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-all ${
                          inventoryCategoryFilter === cat
                            ? 'bg-amber-500/30 text-amber-300 border border-amber-500/40'
                            : 'bg-white/5 text-slate-400 hover:text-white border border-white/5'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Grid Dinámico de Artículos de Inventario con Selector de Cantidad */}
                {(() => {
                  const filtered = inventoryItems.filter(item => {
                    const matchesSearch = !inventorySearch.trim() || 
                      item.name.toLowerCase().includes(inventorySearch.toLowerCase()) ||
                      (item.description && item.description.toLowerCase().includes(inventorySearch.toLowerCase())) ||
                      (item.category && item.category.toLowerCase().includes(inventorySearch.toLowerCase()));
                    const matchesCat = inventoryCategoryFilter === 'TODOS' || item.category === inventoryCategoryFilter;
                    return matchesSearch && matchesCat;
                  });

                  if (filtered.length === 0) {
                    return (
                      <div className="p-6 rounded-xl bg-black/40 border border-white/5 text-center text-xs text-slate-400">
                        No se encontraron artículos con el filtro seleccionado.
                      </div>
                    );
                  }

                  return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 text-xs max-h-72 overflow-y-auto custom-scrollbar p-1">
                      {filtered.map(item => {
                        const isSelected = selectedInventoryIds.includes(item.id);
                        const isOutOfStock = (Number(item.stock) || 0) <= 0;
                        const qty = Math.max(1, selectedInventoryQuantities[item.id] || 1);
                        const subtotal = item.price * qty;

                        return (
                          <div 
                            key={item.id} 
                            className={`flex flex-col justify-between p-2.5 rounded-xl border transition-all ${
                              isOutOfStock 
                                ? 'bg-red-950/20 border-red-500/30 opacity-60 cursor-not-allowed' 
                                : (isSelected ? 'bg-amber-500/20 border-amber-400 text-white shadow-md' : 'bg-black/50 border-white/10 text-slate-300 hover:border-white/20')
                            }`}
                          >
                            <div className="space-y-1.5">
                              <div className="flex items-start justify-between gap-2">
                                <label className="flex items-start gap-2 cursor-pointer flex-1">
                                  <input
                                    type="checkbox"
                                    checked={isSelected}
                                    disabled={isOutOfStock}
                                    onChange={e => {
                                      if (e.target.checked) {
                                        setSelectedInventoryIds(prev => [...prev, item.id]);
                                        setSelectedInventoryQuantities(prev => ({ ...prev, [item.id]: 1 }));
                                      } else {
                                        setSelectedInventoryIds(prev => prev.filter(id => id !== item.id));
                                        setSelectedInventoryQuantities(prev => {
                                          const copy = { ...prev };
                                          delete copy[item.id];
                                          return copy;
                                        });
                                      }
                                    }}
                                    className="w-4 h-4 rounded text-amber-500 mt-0.5 shrink-0"
                                  />
                                  <div>
                                    <span className="font-bold block leading-tight text-white">{item.name}</span>
                                    <span className="text-[9px] uppercase tracking-wider font-semibold text-slate-400">
                                      {item.category || 'Uniforme'}
                                    </span>
                                  </div>
                                </label>
                                <span className="font-mono font-bold text-amber-300 text-xs shrink-0">
                                  Q{Number(item.price).toFixed(2)}
                                </span>
                              </div>

                              {item.description && (
                                <p className="text-[10px] text-slate-400 line-clamp-1 pl-6">
                                  {item.description}
                                </p>
                              )}
                            </div>

                            <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-[11px]">
                              <span className={item.stock <= 3 ? 'text-amber-400 font-bold text-[10px]' : 'text-slate-400 text-[10px]'}>
                                Stock: {item.stock} disp.
                              </span>

                              {isOutOfStock ? (
                                <span className="text-red-400 font-bold uppercase text-[10px]">Agotado</span>
                              ) : isSelected ? (
                                <div className="flex items-center gap-1.5 bg-black/60 px-2 py-0.5 rounded-lg border border-amber-500/40">
                                  <span className="text-[10px] text-slate-400">Cant:</span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      if (qty <= 1) {
                                        setSelectedInventoryIds(prev => prev.filter(id => id !== item.id));
                                        setSelectedInventoryQuantities(prev => {
                                          const copy = { ...prev };
                                          delete copy[item.id];
                                          return copy;
                                        });
                                      } else {
                                        setSelectedInventoryQuantities(prev => ({ ...prev, [item.id]: qty - 1 }));
                                      }
                                    }}
                                    className="w-5 h-5 rounded bg-white/10 hover:bg-white/20 text-white font-bold flex items-center justify-center text-xs"
                                    title="Disminuir cantidad"
                                  >
                                    -
                                  </button>
                                  <span className="font-mono font-bold text-amber-300 min-w-4 text-center">
                                    {qty}
                                  </span>
                                  <button
                                    type="button"
                                    disabled={qty >= (Number(item.stock) || 0)}
                                    onClick={() => {
                                      if (qty < (Number(item.stock) || 0)) {
                                        setSelectedInventoryQuantities(prev => ({ ...prev, [item.id]: qty + 1 }));
                                      }
                                    }}
                                    className="w-5 h-5 rounded bg-white/10 hover:bg-white/20 text-white font-bold flex items-center justify-center text-xs disabled:opacity-30"
                                    title="Aumentar cantidad"
                                  >
                                    +
                                  </button>
                                  <span className="font-mono text-cyan-300 font-bold text-[10px] ml-1">
                                    = Q{subtotal.toFixed(2)}
                                  </span>
                                </div>
                              ) : (
                                <span className="text-[10px] text-slate-400">Clic para entregar</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}

                {/* Resumen Visual de Artículos Seleccionados */}
                {uniformItemDetailsSelected.length > 0 && (
                  <div className="p-3 rounded-xl bg-black/60 border border-amber-500/30 space-y-2 text-xs">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 block">
                      Desglose de Uniforme a Entregar y Descontar:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {uniformItemDetailsSelected.map(det => (
                        <span key={det.id} className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-200 border border-amber-500/30 font-medium flex items-center gap-1.5">
                          <span className="font-bold font-mono text-white">{det.quantity}x</span>
                          <span>{det.name}</span>
                          <span className="font-mono text-amber-300 font-bold">(Q{det.subtotal.toFixed(2)})</span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-white/10">
                  <div>
                    <label className="text-[10px] font-bold text-slate-300 block mb-1">
                      Fraccionar Descuento en Quincenas (Máximo 7):
                    </label>
                    <select
                      value={uniformInstallments}
                      onChange={e => setUniformInstallments(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-bold text-cyan-300 bg-black/60 border border-white/10 font-mono"
                    >
                      <option value="1" className="bg-slate-900 text-white">1 Quincena (Pago único)</option>
                      <option value="2" className="bg-slate-900 text-white">2 Quincenas</option>
                      <option value="3" className="bg-slate-900 text-white">3 Quincenas</option>
                      <option value="4" className="bg-slate-900 text-white">4 Quincenas</option>
                      <option value="5" className="bg-slate-900 text-white">5 Quincenas</option>
                      <option value="6" className="bg-slate-900 text-white">6 Quincenas</option>
                      <option value="7" className="bg-slate-900 text-white">7 Quincenas (Plazo Máximo)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-300 block mb-1">
                      Fecha de Registro:
                    </label>
                    <input
                      type="date"
                      value={uniformDate}
                      onChange={(e) => setUniformDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-bold text-cyan-300 bg-black/60 border border-white/10"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 block mb-1">
                    Quincena de inicio (primera cuota){' '}
                    <span className="font-normal text-slate-400">— por defecto: {quincenaLabel(currentQuincena())}</span>
                  </label>
                  {renderQuincenaPicker(startQ, setStartQ)}
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 block mb-1">Observaciones / Entrega de Uniforme</label>
                  <input
                    type="text"
                    value={uniformNotes}
                    onChange={e => setUniformNotes(e.target.value)}
                    placeholder="Ej. Talla M, entrega en garita central, accesorios nuevos..."
                    className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-slate-300"
                  />
                </div>

                <div className="p-3 rounded-xl bg-black/50 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">
                      Monto Total de Uniforme:
                    </span>
                    <span className="text-sm font-black text-white font-mono">
                      Q{totalUniformCalculated.toFixed(2)}
                    </span>
                  </div>

                  <div className="sm:text-right">
                    <span className="text-[10px] uppercase font-bold text-amber-300 block">
                      Descuento por Quincena ({safeInstallments} cuota{safeInstallments > 1 ? 's' : ''}):
                    </span>
                    <span className="text-sm font-black text-amber-400 font-mono">
                      Q{installmentCalculated.toFixed(2)} / quincena
                    </span>
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="submit"
                    disabled={totalUniformCalculated <= 0}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs hover:from-amber-400 hover:to-orange-400 transition-all shadow-md flex items-center gap-1.5 disabled:opacity-50"
                  >
                    <Shirt className="w-3.5 h-3.5" />
                    <span>Aplicar Descuento por Uniforme (Q{totalUniformCalculated.toFixed(2)})</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 2. SECCIÓN: CONTROL DE LIQUIDACIÓN & PAGO QUINCENAL                       */}
      {/* ========================================================================= */}
      <div className="p-4 rounded-2xl bg-black/40 border border-emerald-500/30 space-y-4 shadow-[0_0_20px_rgba(16,185,129,0.1)]">
        <div className="flex items-center justify-between pb-2 border-b border-white/5">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-400" />
            <span>Control de Liquidación & Pago Quincenal:</span>
          </span>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-lg border border-emerald-500/20 font-bold">
            {isAdmin ? 'Acceso Exclusivo Administrador' : 'Solo Consulta'}
          </span>
        </div>

        {paymentSuccessMsg && (
          <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span className="font-semibold">{paymentSuccessMsg}</span>
          </div>
        )}

        {isAdmin && onRecordPayment ? (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              const finalAmount = Number(customPaymentAmount !== '' ? customPaymentAmount : calculatedNetQuincena);
              if (isNaN(finalAmount) || finalAmount < 0) {
                alert('Por favor ingresa un monto válido a liquidar.');
                return;
              }

              try {
                setIsProcessingPayment(true);
                await onRecordPayment({
                  employeeId: viewingEmployee.id,
                  employeeName: viewingEmployee.name,
                  period: paymentPeriod,
                  month: paymentMonth,
                  year: paymentYear,
                  calculatedAmount: calculatedNetQuincena,
                  paidAmount: finalAmount,
                  paymentMethod: paymentMethod,
                  bankName: paymentBank,
                  referenceNumber: paymentReference.trim(),
                  notes: paymentNotes.trim() || `Liquidación ${paymentPeriod === '1RA_QUINCENA' ? '1ra Quincena' : '2da Quincena'} de ${monthsList.find(m => m.value === paymentMonth)?.label} ${paymentYear}. Descuentos aplicados: Q${activePeriodDiscounts.toFixed(2)}.`,
                  notifyGuard: true,
                });
                setPaymentSuccessMsg(`¡${paymentPeriod === '1RA_QUINCENA' ? '1ra Quincena' : '2da Quincena'} de ${monthsList.find(m => m.value === paymentMonth)?.label} ${paymentYear} registrada como PAGADA con éxito (Q${finalAmount.toFixed(2)})!`);
                setPaymentReference('');
                setCustomPaymentAmount('');
                setPaymentNotes('');
                setTimeout(() => setPaymentSuccessMsg(null), 5000);
              } catch (err: any) {
                alert(err.message || 'Error al registrar el pago quincenal');
              } finally {
                setIsProcessingPayment(false);
              }
            }}
            className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/20 space-y-3.5 text-xs"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Marcar Quincena del Guardia como Pagada:</span>
              </span>
              {existingPaidRecord ? (
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px] flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Esta quincena ya figura como PAGADA (Q{existingPaidRecord.paidAmount.toFixed(2)})</span>
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-[10px]">
                  Pendiente de Pago
                </span>
              )}
            </div>

            {/* Selector de Quincena, Mes y Año */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Quincena Pagada: <span className="text-rose-400">*</span>
                </label>
                <select
                  value={paymentPeriod}
                  onChange={e => setPaymentPeriod(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-bold text-emerald-300 bg-slate-900 border border-white/10"
                >
                  <option value="1RA_QUINCENA" className="bg-slate-900 text-white">1ra Quincena (Días 1 al 15)</option>
                  <option value="2DA_QUINCENA" className="bg-slate-900 text-white">2da Quincena (Días 16 a fin de mes)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Mes Pagado: <span className="text-rose-400">*</span>
                </label>
                <select
                  value={paymentMonth}
                  onChange={e => setPaymentMonth(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-bold text-emerald-300 bg-slate-900 border border-white/10"
                >
                  {monthsList.map(m => (
                    <option key={m.value} value={m.value} className="bg-slate-900 text-white">
                      {m.label} ({String(m.value).padStart(2, '0')})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Año Pagado: <span className="text-rose-400">*</span>
                </label>
                <select
                  value={paymentYear}
                  onChange={e => setPaymentYear(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-bold text-emerald-300 bg-slate-900 border border-white/10 font-mono"
                >
                  {[2028, 2027, 2026, 2025, 2024, 2023].map(y => (
                    <option key={y} value={y} className="bg-slate-900 text-white">
                      {y}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Banco y Medio de Pago */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-bold text-slate-300">
                    Banco / Medio de Cobro:
                  </label>
                  {onOpenAddBankModal && (
                    <button
                      type="button"
                      onClick={onOpenAddBankModal}
                      className="text-[10px] text-cyan-400 hover:text-cyan-300 font-bold underline flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Agregar Banco</span>
                    </button>
                  )}
                </div>
                <select
                  value={paymentBank}
                  onChange={e => {
                    const val = e.target.value;
                    setPaymentBank(val);
                    if (val === 'En efectivo') {
                      setPaymentMethod('EFECTIVO');
                    } else {
                      setPaymentMethod('TRANSFERENCIA');
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-semibold text-white bg-slate-900 border border-white/10"
                >
                  {availableBanks.map(b => (
                    <option key={b} value={b} className="bg-slate-900 text-white">
                      {b}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  No. Boleta / Referencia Bancaria:
                </label>
                <input
                  type="text"
                  placeholder="Ej. TRANSF-88912 o Boleta Depósito"
                  value={paymentReference}
                  onChange={e => setPaymentReference(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono"
                />
              </div>
            </div>

            {/* Descripción opcional de pago */}
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                Descripción / Detalle Específico del Pago:
              </label>
              <input
                type="text"
                placeholder="Ej. Pago ordinario quincenal, bono de puntualidad o liquidación de día específico"
                value={paymentNotes}
                onChange={e => setPaymentNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs text-white"
              />
            </div>

            {/* Desglose Quincenal y Botón de Pago */}
            <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400">Sueldo Quincenal Base:</span>
                  <span className="font-mono font-bold text-white">Q{halfSalary.toFixed(2)}</span>
                </div>
                {viewingEmployee.appliesIGSS && (
                  <div className="flex items-center gap-2 text-[11px] text-slate-400">
                    <span>Retención IGSS ({igssPercent}%):</span>
                    <span className="font-mono text-amber-400 font-semibold">-Q{igssAmount.toFixed(2)}</span>
                  </div>
                )}
                {activePeriodDiscounts > 0 && (
                  <div className="flex items-center gap-2 text-[11px] text-slate-400">
                    <span>Descuentos en este Período:</span>
                    <span className="font-mono text-rose-400 font-semibold">-Q{activePeriodDiscounts.toFixed(2)}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3">
                <div>
                  <label className="text-[10px] uppercase font-bold text-emerald-300 block">
                    Monto Final a Pagar (Q):
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder={calculatedNetQuincena.toFixed(2)}
                    value={customPaymentAmount !== '' ? customPaymentAmount : calculatedNetQuincena.toFixed(2)}
                    onChange={e => setCustomPaymentAmount(e.target.value)}
                    className="w-32 px-2.5 py-1.5 rounded-lg liquid-glass-input font-mono font-bold text-sm text-emerald-300 text-right bg-slate-900 border border-white/10"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isProcessingPayment}
                  className="px-4 py-2.5 rounded-xl font-bold text-xs text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 transition-all shadow-[0_0_15px_rgba(16,185,129,0.3)] disabled:opacity-50 flex items-center gap-1.5 shrink-0 self-end"
                >
                  <CheckCircle2 className="w-4 h-4 text-slate-950" />
                  <span>{isProcessingPayment ? 'Registrando...' : 'Colocar como Pagado'}</span>
                </button>
              </div>
            </div>
          </form>
        ) : (
          <div className="p-3 bg-black/40 rounded-xl border border-white/5 text-xs text-slate-400 flex items-center gap-2">
            <Lock className="w-4 h-4 text-slate-500 shrink-0" />
            <span>Solo el Administrador Principal tiene autorización para marcar quincenas como pagadas y registrar pagos.</span>
          </div>
        )}

        {/* Historial de Quincenas Pagadas para este colaborador */}
        <div className="space-y-2 pt-1">
          <span className="text-[11px] font-bold text-slate-300 block uppercase tracking-wider">
            Historial de Quincenas Pagadas al Guardia:
          </span>
          {(() => {
            const guardPayments = payments.filter(p => p.employeeId === viewingEmployee.id && p.status === 'PAGADO');
            if (guardPayments.length === 0) {
              return (
                <p className="text-xs text-slate-400 italic bg-white/5 p-3 rounded-xl border border-white/5">
                  No hay pagos quincenales registrados para este colaborador en el sistema.
                </p>
              );
            }

            const monthsNames = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

            return (
              <div className="space-y-2 max-h-40 overflow-y-auto custom-scrollbar pr-1">
                {guardPayments.map(pay => (
                  <div key={pay.id} className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/20 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-black text-emerald-300 text-sm">
                        Q{pay.paidAmount.toFixed(2)}
                      </span>
                      <div>
                        <div className="flex items-center gap-1.5 font-bold text-white">
                          <span>{pay.period === '1RA_QUINCENA' ? '1ra Quincena' : '2da Quincena'} · {monthsNames[pay.month] || pay.month} {pay.year}</span>
                          <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold uppercase">
                            PAGADO
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {pay.bankName} {pay.referenceNumber ? `(Ref: ${pay.referenceNumber})` : ''} · Liquidado el {pay.paymentDate}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
};
