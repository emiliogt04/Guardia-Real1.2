import React, { useState } from 'react';
import { 
  KeyRound, 
  ShieldCheck, 
  Lock, 
  LogIn, 
  X, 
  AlertCircle, 
  CheckCircle2,
  Eye,
  EyeOff,
  Sparkles
} from 'lucide-react';
import { AppUser, SystemSecurityConfig } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose?: () => void;
  onLoginSuccess: (user: AppUser) => void;
  securityConfig: SystemSecurityConfig | null;
  users: AppUser[];
  isEmbedded?: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  securityConfig,
  users,
  isEmbedded = false,
}) => {
  const [pinCode, setPinCode] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen && !isEmbedded) return null;

  // Single PIN validation handler: The ONLY way to access the application
  const handlePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = pinCode.trim();

    if (!cleanPin) {
      setErrorMessage('Por favor ingresa tu código PIN de acceso.');
      return;
    }

    try {
      setIsLoading(true);
      setErrorMessage(null);
      setSuccessMessage(null);

      const res = await fetch('/api/auth/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: cleanPin }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Código PIN no válido o no reconocido.');
      }

      const roleLabel = data.role === 'ADMIN' 
        ? 'Administrador General' 
        : data.role === 'GUARD' 
        ? 'Guardia de Seguridad' 
        : 'Usuario Autorizado';

      setSuccessMessage(data.message || `¡Acceso concedido como ${roleLabel}! Bienvenido/a ${data.user?.name || ''}.`);

      setTimeout(() => {
        onLoginSuccess(data.user);
        if (onClose) onClose();
      }, 700);
    } catch (err: any) {
      setErrorMessage(err.message || 'Código PIN incorrecto. Solicita tu PIN de acceso al Administrador General.');
    } finally {
      setIsLoading(false);
    }
  };

  const cardContent = (
    <div className="liquid-glass-elevated rounded-3xl max-w-md w-full p-6 sm:p-7 border border-white/15 shadow-2xl relative my-auto space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center text-slate-950 font-black shadow-[0_0_20px_rgba(6,182,212,0.4)] text-base">
            GR
          </div>
          <div>
            <h3 className="text-base font-black text-white tracking-tight">Acceso Exclusivo con PIN</h3>
            <p className="text-[11px] text-slate-400 font-medium">GUARDIA REAL · Seguridad & Control de Acceso</p>
          </div>
        </div>
        {!isEmbedded && onClose && (
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Admin PIN Provisioning Notice */}
      <div className="p-3.5 rounded-2xl bg-cyan-950/30 border border-cyan-400/30 space-y-1.5 shadow-sm">
        <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs">
          <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>Ingreso Autorizado por PIN Único</span>
        </div>
        <p className="text-[11px] text-slate-300 leading-relaxed">
          El <strong>Administrador brinda los códigos PIN</strong> para cada usuario y colaborador. El sistema validará tu PIN e identificará automáticamente tu perfil (Administrador, Guardia o Invitado).
        </p>
      </div>

      {/* Single PIN Form */}
      <form onSubmit={handlePinSubmit} className="space-y-4">
        <div>
          <label className="block font-bold text-slate-200 text-xs mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
              <span>Código PIN de Ingreso:</span>
            </span>
            <span className="text-[10px] font-mono text-cyan-400 font-semibold bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
              Obligatorio
            </span>
          </label>

          <div className="relative">
            <input
              type={showPin ? 'text' : 'password'}
              required
              autoFocus
              placeholder="Ingresa tu PIN asignado"
              value={pinCode}
              onChange={e => {
                setPinCode(e.target.value);
                setErrorMessage(null);
              }}
              className="w-full pl-4 pr-11 py-3 rounded-2xl liquid-glass-input text-base font-mono tracking-widest font-bold text-cyan-300 text-center placeholder:tracking-normal placeholder:font-normal placeholder:text-slate-500 focus:border-cyan-400 transition-all shadow-inner"
            />
            <button
              type="button"
              onClick={() => setShowPin(!showPin)}
              tabIndex={-1}
              className="absolute right-3.5 top-3.5 text-slate-400 hover:text-white transition-colors"
              title={showPin ? 'Ocultar PIN' : 'Mostrar PIN'}
            >
              {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          <p className="text-[10px] text-slate-400 mt-1.5 text-center">
            La única forma de ingresar al sistema o acceder a un usuario es introduciendo su código PIN correspondiente.
          </p>
        </div>

        {errorMessage && (
          <div className="p-3 bg-rose-500/15 text-rose-300 rounded-xl border border-rose-500/30 text-xs flex items-center gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span className="leading-snug">{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3 bg-emerald-500/15 text-emerald-300 rounded-xl border border-emerald-500/30 text-xs flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span className="leading-snug font-semibold">{successMessage}</span>
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading || !pinCode.trim()}
          className="w-full py-3.5 px-4 rounded-xl font-black text-xs text-slate-950 bg-gradient-to-r from-cyan-400 via-teal-300 to-blue-400 hover:from-cyan-300 hover:via-teal-200 hover:to-blue-300 transition-all shadow-[0_0_25px_rgba(6,182,212,0.35)] disabled:opacity-50 flex items-center justify-center gap-2 active:scale-98"
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              <span>Validando PIN en el Sistema...</span>
            </>
          ) : (
            <>
              <LogIn className="w-4 h-4 text-slate-950" />
              <span>Validar PIN e Ingresar al Sistema</span>
            </>
          )}
        </button>
      </form>

      {/* Footer Info */}
      <div className="pt-2 border-t border-white/10 text-center">
        <p className="text-[10px] text-slate-500">
          ¿No tienes tu PIN o lo olvidaste? Solicita tu asignación directamente al Administrador General.
        </p>
      </div>
    </div>
  );

  if (isEmbedded) {
    return <div className="w-full flex items-center justify-center animate-in fade-in zoom-in-95 my-auto">{cardContent}</div>;
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in overflow-y-auto">
      {cardContent}
    </div>
  );
};
