import React, { useState } from 'react';
import { 
  Building2, 
  Users, 
  FileSpreadsheet, 
  ShieldCheck, 
  Bell, 
  Menu, 
  X, 
  ChevronDown, 
  Download,
  AlertTriangle,
  Check,
  Sparkles,
  QrCode,
  Palette,
  KeyRound,
  LogOut,
  Settings,
  Package,
  DollarSign
} from 'lucide-react';
import { AppUser, RealtimeNotification } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: AppUser;
  users?: AppUser[];
  onSwitchUser?: (user: AppUser) => void;
  notifications: RealtimeNotification[];
  onMarkNotificationsRead: () => void;
  onQuickExport: () => void;
  canExport: boolean;
  onOpenThemeModal: () => void;
  onOpenAuthModal: () => void;
  onLogout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  notifications,
  onMarkNotificationsRead,
  onQuickExport,
  canExport,
  onOpenThemeModal,
  onOpenAuthModal,
  onLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  const allNavItems = [
    { 
      id: 'companies', 
      label: 'Empresas', 
      icon: Building2,
      visible: currentUser.role === 'ADMIN' || currentUser.permissions?.canViewCompanies !== false,
    },
    { 
      id: 'employees', 
      label: 'Trabajadores', 
      icon: Users,
      visible: currentUser.role === 'ADMIN' || currentUser.permissions?.canViewEmployees !== false,
    },
    { 
      id: 'audit', 
      label: 'Planilla & Excel', 
      icon: FileSpreadsheet,
      // Los guardias NO pueden ver la planilla ni sueldos; si se quita permiso de ver salarios o planilla, se remueve la pestaña
      visible: currentUser.role === 'ADMIN' || (currentUser.role !== 'GUARD' && !!currentUser.permissions?.canViewAuditLog && currentUser.permissions?.canViewSalaries !== false),
    },
    // QR scanner removed per user request
    { 
      id: 'permissions', 
      label: 'Control de Permisos', 
      icon: ShieldCheck,
      visible: currentUser.role === 'ADMIN',
    },
    {
      id: 'settings',
      label: 'Configuraciones',
      icon: Settings,
      visible: currentUser.role === 'ADMIN',
    },
    {
      id: 'payroll',
      label: 'Centro de Nómina',
      icon: DollarSign,
      visible: currentUser.role === 'ADMIN',
    },
    {
      id: 'inventory',
      label: 'Inventario',
      icon: Package,
      visible: currentUser.role === 'ADMIN' || currentUser.role === 'GUEST',
    },
  ];

  const navItems = allNavItems.filter(item => item.visible);

  return (
    <header className="sticky top-0 z-40 bg-[#090d16]/80 backdrop-blur-2xl border-b border-white/10 shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-8">
          
          {/* Zone 1: Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button 
              onClick={() => setActiveTab(navItems[0]?.id || 'companies')}
              className="text-left flex items-center gap-3 focus:outline-none group"
            >
              <div className="relative">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center font-extrabold text-xs text-slate-950 shadow-[0_0_20px_rgba(6,182,212,0.4)] border border-cyan-300/40 group-hover:scale-105 transition-transform">
                  GR
                </div>
                <div className="absolute -inset-0.5 bg-cyan-400 rounded-xl blur-xs opacity-30 -z-10 group-hover:opacity-60 transition-opacity"></div>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-base font-extrabold tracking-tight text-white whitespace-nowrap block leading-tight uppercase">
                    GUARDIA REAL
                  </span>
                  <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                    Liquid
                  </span>
                </div>
                <span className="text-[10px] font-medium text-slate-400 block leading-none mt-0.5 tracking-tight truncate max-w-[200px]">
                  SERVICIOS DE SEGURIDAD CORPORATIVA
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-1.5 p-1 rounded-xl bg-slate-950/40 border border-white/5 backdrop-blur-md">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-400/30 shadow-[0_0_12px_rgba(6,182,212,0.2)]'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions, Notifications & User Switcher */}
          <div className="flex items-center gap-2.5 shrink-0">
            
            {/* Liquid Glass Theme Switcher */}
            <button
              onClick={onOpenThemeModal}
              title="Cambiar tema Liquid Glass"
              className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl border border-white/10 transition-all flex items-center gap-1.5 text-xs font-semibold"
            >
              <Palette className="w-4 h-4 text-cyan-400" />
              <span className="hidden xl:inline">Tema Visual</span>
            </button>

            {/* Quick Login / Role Code button */}
            <button
              onClick={onOpenAuthModal}
              title="Iniciar sesión con Google o Código de Acceso"
              className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl border border-white/10 transition-all flex items-center gap-1.5 text-xs font-semibold"
            >
              <KeyRound className="w-4 h-4 text-amber-400" />
              <span className="hidden xl:inline">Acceso / PIN</span>
            </button>

            {/* Quick Excel Export if allowed */}
            {canExport && (
              <button
                onClick={onQuickExport}
                title="Descargar planilla quincenal en Excel"
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded-lg hover:bg-emerald-500/20 hover:border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.15)] transition-all whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>Exportar Planilla</span>
              </button>
            )}

            {/* Notifications Popover */}
            <div className="relative">
              <button
                onClick={() => {
                  setNotifDropdownOpen(!notifDropdownOpen);
                  setUserDropdownOpen(false);
                }}
                className="relative p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl border border-white/5 transition-colors focus:outline-none"
                aria-label="Notificaciones"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-[0_0_8px_rgba(244,63,94,0.6)]">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>

              {notifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 liquid-glass-elevated rounded-2xl py-2 z-50 animate-in fade-in zoom-in-95">
                  <div className="flex items-center justify-between px-4 py-2 border-b border-white/10">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-xs text-white uppercase tracking-wider">Alertas en Tiempo Real</span>
                      {unreadCount > 0 && (
                        <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-500/30 font-medium px-2 py-0.5 rounded-full">
                          {unreadCount} nuevas
                        </span>
                      )}
                    </div>
                    {unreadCount > 0 && (
                      <button
                        onClick={onMarkNotificationsRead}
                        className="text-[11px] text-cyan-400 hover:text-cyan-300 font-medium"
                      >
                        Marcar leídas
                      </button>
                    )}
                  </div>

                  <div className="max-h-80 overflow-y-auto divide-y divide-white/5">
                    {notifications.length === 0 ? (
                      <div className="py-6 text-center text-xs text-slate-400">
                        No hay notificaciones recientes
                      </div>
                    ) : (
                      notifications.slice(0, 8).map(n => (
                        <div
                          key={n.id}
                          className={`p-3 text-xs hover:bg-white/5 transition-colors ${
                            !n.read ? 'bg-amber-500/10' : ''
                          }`}
                        >
                          <div className="flex items-start gap-2.5">
                            <AlertTriangle className={`w-4 h-4 shrink-0 mt-0.5 ${
                              n.type === 'salary' ? 'text-amber-400' : 'text-cyan-400'
                            }`} />
                            <div className="flex-1">
                              <p className="font-semibold text-slate-200 leading-tight">{n.title}</p>
                              <p className="text-slate-400 mt-1 leading-normal text-[11px]">{n.message}</p>
                              <p className="text-[10px] text-slate-500 mt-1">
                                {new Date(n.timestamp).toLocaleTimeString('es-GT', { hour: '2-digit', minute: '2-digit' })} · Por {n.actorName}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Current User Switcher dropdown */}
            <div className="relative">
              <button
                onClick={() => {
                  setUserDropdownOpen(!userDropdownOpen);
                  setNotifDropdownOpen(false);
                }}
                className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl border border-white/10 bg-slate-900/60 hover:bg-slate-800/80 transition-all text-left focus:outline-none backdrop-blur-md"
              >
                <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold ${
                  currentUser.role === 'ADMIN' 
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-[0_0_10px_rgba(6,182,212,0.3)]' 
                    : currentUser.role === 'GUARD'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}>
                  {currentUser.role === 'ADMIN' ? 'A' : (currentUser.role === 'GUARD' ? 'G' : 'I')}
                </div>
                <div className="hidden sm:block text-left">
                  <p className="text-xs font-semibold text-slate-200 leading-none truncate max-w-[130px]">
                    {currentUser.name}
                  </p>
                  <p className="text-[10px] text-slate-400 leading-none mt-1">
                    {currentUser.role === 'ADMIN' ? 'Administrador' : (currentUser.role === 'GUARD' ? 'Guardia (Control QR)' : 'Invitado')}
                  </p>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 liquid-glass-elevated rounded-2xl p-4 z-50 animate-in fade-in zoom-in-95 space-y-3 shadow-2xl border border-white/10">
                  <div className="flex items-center gap-2.5 pb-3 border-b border-white/10">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold shrink-0 ${
                      currentUser.role === 'ADMIN' 
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-[0_0_10px_rgba(6,182,212,0.3)]' 
                        : currentUser.role === 'GUARD'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}>
                      {currentUser.role === 'ADMIN' ? 'A' : (currentUser.role === 'GUARD' ? 'G' : 'I')}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-white truncate">
                        {currentUser.name}
                      </p>
                      <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-full mt-0.5 ${
                        currentUser.role === 'ADMIN' 
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' 
                          : currentUser.role === 'GUARD'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}>
                        {currentUser.role === 'ADMIN' ? 'Administrador General' : (currentUser.role === 'GUARD' ? 'Guardia de Seguridad' : 'Usuario Invitado')}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-300">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Correo:</span>
                      <span className="font-mono text-slate-200 truncate max-w-[160px]">{currentUser.email}</span>
                    </div>
                    {currentUser.stationName && (
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400">Puesto:</span>
                        <span className="font-semibold text-emerald-300 truncate max-w-[160px]">{currentUser.stationName}</span>
                      </div>
                    )}
                  </div>

                  {onLogout && (
                    <div className="pt-2 border-t border-white/10">
                      <button
                        onClick={() => {
                          setUserDropdownOpen(false);
                          onLogout();
                        }}
                        className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-rose-300 hover:text-rose-100 hover:bg-rose-500/15 border border-rose-500/30 transition-all text-center"
                      >
                        <LogOut className="w-3.5 h-3.5 text-rose-400" />
                        <span>Cerrar Sesión</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Quick Logout Button on Desktop */}
            {onLogout && (
              <button
                onClick={onLogout}
                title="Cerrar Sesión"
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-semibold transition-all focus:outline-none"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Salir</span>
              </button>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl border border-white/5 focus:outline-none"
              aria-label="Menú móvil"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-[#090d16]/95 backdrop-blur-2xl px-4 pt-3 pb-4 space-y-1">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    : 'text-slate-400 hover:bg-white/5'
                }`}
              >
                <Icon className="w-4 h-4" />
                {item.label}
              </button>
            );
          })}
          {canExport && (
            <button
              onClick={() => {
                onQuickExport();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 mt-2"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              Descargar Planilla Quincenal
            </button>
          )}

          <div className="pt-2 border-t border-white/10 grid grid-cols-2 gap-2 mt-2">
            <button
              onClick={() => {
                onOpenThemeModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-xs font-semibold text-cyan-300 bg-cyan-500/10 border border-cyan-500/30"
            >
              <Palette className="w-4 h-4" />
              <span>Tema Visual</span>
            </button>

            <button
              onClick={() => {
                onOpenAuthModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-xs font-semibold text-amber-300 bg-amber-500/10 border border-amber-500/30"
            >
              <KeyRound className="w-4 h-4" />
              <span>Acceso / PIN</span>
            </button>
          </div>

          {onLogout && (
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onLogout();
              }}
              className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold text-rose-300 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 transition-all mt-2"
            >
              <LogOut className="w-4 h-4 text-rose-400" />
              <span>Cerrar Sesión</span>
            </button>
          )}
        </div>
      )}
    </header>
  );
};
