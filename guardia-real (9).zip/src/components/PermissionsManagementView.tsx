import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Plus, 
  Check, 
  X, 
  Lock, 
  AlertCircle,
  Users,
  Building2,
  DollarSign,
  FileSpreadsheet,
  History,
  Trash2
} from 'lucide-react';
import { AppUser, UserPermissions, SystemSecurityConfig } from '../types';
import { KeyRound, Save } from 'lucide-react';

interface PermissionsManagementViewProps {
  users: AppUser[];
  currentUser: AppUser;
  securityConfig?: SystemSecurityConfig | null;
  onUpdatePermissions: (userId: string, permissions: UserPermissions) => Promise<void>;
  onCreateUser?: (userData: { name: string; email: string; role: 'ADMIN' | 'GUEST' | 'GUARD'; permissions: UserPermissions }) => Promise<void>;
  onSwitchUser?: (user: AppUser) => void;
  onUpdateSecurityConfig?: (config: Partial<SystemSecurityConfig>) => Promise<void>;
  onUpdateUserRoleAndCode?: (
    userId: string, 
    data: { role: 'ADMIN' | 'GUEST' | 'GUARD'; personalAccessCode?: string; username?: string; permissions?: UserPermissions }
  ) => Promise<void>;
  onDeleteUser?: (userId: string, reason?: string) => Promise<void>;
}

export const PermissionsManagementView: React.FC<PermissionsManagementViewProps> = ({
  users,
  currentUser,
  securityConfig,
  onUpdatePermissions,
  onCreateUser,
  onSwitchUser,
  onUpdateSecurityConfig,
  onUpdateUserRoleAndCode,
  onDeleteUser,
}) => {
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [newUserData, setNewUserData] = useState({
    name: '',
    email: '',
    role: 'GUEST' as 'ADMIN' | 'GUEST' | 'GUARD',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState('');

  // Access codes state
  const [adminCode, setAdminCode] = useState(securityConfig?.adminAccessCode || 'ADMIN-2026');
  const [guardCode, setGuardCode] = useState(securityConfig?.guardAccessCode || 'GUARDIA-7788');
  const [guestCode, setGuestCode] = useState(securityConfig?.guestAccessCode || 'INVITADO-1234');
  const [isSavingCodes, setIsSavingCodes] = useState(false);

  useEffect(() => {
    if (securityConfig) {
      if (securityConfig.adminAccessCode && securityConfig.adminAccessCode !== '••••••••') {
        setAdminCode(securityConfig.adminAccessCode);
      }
      if (securityConfig.guardAccessCode && securityConfig.guardAccessCode !== '••••••••') {
        setGuardCode(securityConfig.guardAccessCode);
      }
      if (securityConfig.guestAccessCode && securityConfig.guestAccessCode !== '••••••••') {
        setGuestCode(securityConfig.guestAccessCode);
      }
    }
  }, [securityConfig]);

  const handleSaveAccessCodes = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSavingCodes(true);
      await onUpdateSecurityConfig?.({
        adminAccessCode: adminCode.trim(),
        guardAccessCode: guardCode.trim(),
        guestAccessCode: guestCode.trim(),
      });
      setMessage('¡Códigos de inicio de sesión actualizados con éxito!');
      setTimeout(() => setMessage(''), 4000);
    } catch (err: any) {
      alert(err.message || 'Error al guardar los códigos.');
    } finally {
      setIsSavingCodes(false);
    }
  };

  const isAdmin = currentUser.role === 'ADMIN';

  const permissionDefinitions: {
    key: keyof UserPermissions;
    title: string;
    category: 'VISUALIZACIÓN' | 'OPERACIÓN';
    badge: string;
    description: string;
    icon: any;
    isSalaryPrivacy?: boolean;
  }[] = [
    // Visualización y pestañas
    {
      key: 'canViewCompanies',
      title: 'Pestaña: Empresas',
      category: 'VISUALIZACIÓN',
      badge: 'Pestaña',
      description: 'Permite ver el directorio de empresas. Si se desactiva, la pestaña desaparece de la barra.',
      icon: Building2,
    },
    {
      key: 'canViewEmployees',
      title: 'Pestaña: Trabajadores',
      category: 'VISUALIZACIÓN',
      badge: 'Pestaña',
      description: 'Permite ver el listado de colaboradores. Si se desactiva, la pestaña desaparece de la barra.',
      icon: Users,
    },
    {
      key: 'canViewSalaries',
      title: 'Ver Sueldos y Descuentos (IGSS)',
      category: 'VISUALIZACIÓN',
      badge: 'Confidencialidad',
      description: 'Control de privacidad: Si está desactivado, el usuario o guardia NO puede ver sueldos mensuales, quincenas ni deducciones de IGSS.',
      icon: DollarSign,
      isSalaryPrivacy: true,
    },
    {
      key: 'canViewAuditLog',
      title: 'Pestaña: Planilla & Excel',
      category: 'VISUALIZACIÓN',
      badge: 'Pestaña',
      description: 'Permite ver la planilla quincenal y auditoría. Si se desactiva, la pestaña desaparece de la barra.',
      icon: History,
    },
    {
      key: 'canScanQR',
      title: 'Pestaña: Guardias & QR',
      category: 'VISUALIZACIÓN',
      badge: 'Pestaña',
      description: 'Permite ver la pestaña de garita, escáner QR satelital y registro de entradas y salidas.',
      icon: ShieldCheck,
    },

    // Operación y Gestión
    {
      key: 'canEditEmployees',
      title: 'Editar Colaboradores',
      category: 'OPERACIÓN',
      badge: 'Operación',
      description: 'Modificar nombres, DPI, cargo, fechas de inicio y fin (por defecto para invitados).',
      icon: Users,
    },
    {
      key: 'canCreateEmployees',
      title: 'Registrar Nuevos Colaboradores',
      category: 'OPERACIÓN',
      badge: 'Operación',
      description: 'Habilita el botón y formulario para dar de alta nuevos trabajadores en el sistema.',
      icon: Plus,
    },
    {
      key: 'canModifySalaries',
      title: 'Modificar Salarios Mensuales',
      category: 'OPERACIÓN',
      badge: 'Operación',
      description: 'Autoriza el cambio de salarios en Quetzales (solo si puede ver salarios).',
      icon: DollarSign,
    },
    {
      key: 'canDeleteEmployees',
      title: 'Eliminar Colaboradores',
      category: 'OPERACIÓN',
      badge: 'Operación',
      description: 'Permite borrar permanentemente trabajadores de la base de datos.',
      icon: Trash2,
    },
    {
      key: 'canManageCompanies',
      title: 'Gestionar Empresas',
      category: 'OPERACIÓN',
      badge: 'Operación',
      description: 'Permite registrar nuevas empresas, cambiar NIT, direcciones y datos corporativos.',
      icon: Building2,
    },
    {
      key: 'canExportExcel',
      title: 'Descargar Planilla en Excel',
      category: 'OPERACIÓN',
      badge: 'Operación',
      description: 'Autoriza la descarga del archivo Excel (.xlsx) con la planilla quincenal y auditoría.',
      icon: FileSpreadsheet,
    },
  ];

  const handleTogglePermission = async (targetUser: AppUser, permKey: keyof UserPermissions) => {
    if (!isAdmin) return;
    if (targetUser.role === 'ADMIN') return;

    const updated = {
      ...targetUser.permissions,
      [permKey]: !targetUser.permissions[permKey],
    };

    try {
      await onUpdatePermissions(targetUser.id, updated);
      setMessage(`Permiso "${permKey}" actualizado para ${targetUser.name}.`);
      setTimeout(() => setMessage(''), 3000);
    } catch (err: any) {
      alert(err.message || 'Error al actualizar permisos.');
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserData.name.trim() || !newUserData.email.trim()) return;

    const isGuard = newUserData.role === 'GUARD';

    try {
      setIsSubmitting(true);
      await onCreateUser?.({
        name: newUserData.name.trim(),
        email: newUserData.email.trim(),
        role: newUserData.role,
        permissions: {
          canViewCompanies: true,
          canViewEmployees: true,
          canViewSalaries: !isGuard,       // Los guardias NO pueden ver sueldos ni deducciones
          canViewAuditLog: false,
          canScanQR: isGuard,
          canEditEmployees: newUserData.role === 'GUEST',
          canCreateEmployees: false,
          canDeleteEmployees: false,
          canManageCompanies: false,
          canExportExcel: false,
          canModifySalaries: false,
        },
      });
      setIsAddUserModalOpen(false);
      setNewUserData({ name: '', email: '', role: 'GUEST' });
      setMessage(`Nuevo usuario ${isGuard ? 'guardia' : 'invitado'} creado exitosamente.`);
      setTimeout(() => setMessage(''), 3000);
    } catch (err: any) {
      alert(err.message || 'Error al crear usuario.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Title & Add Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Control de Acceso & Permisos Granulares
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Configura qué secciones del sistema puede gestionar cada usuario invitado (RBAC granular).
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setIsAddUserModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 rounded-xl hover:from-cyan-300 hover:to-blue-300 transition-all shadow-[0_0_20px_rgba(6,182,212,0.35)]"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>Crear Usuario Invitado</span>
          </button>
        )}
      </div>

      {message && (
        <div className="p-3 bg-emerald-500/15 text-emerald-300 text-xs rounded-2xl border border-emerald-500/30 flex items-center gap-2 shadow-[0_0_15px_rgba(16,185,129,0.2)]">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Guest View Notice */}
      {!isAdmin && (
        <div className="p-4 liquid-glass rounded-2xl border border-amber-500/30 text-xs text-amber-200 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-sm text-white">Navegando como Invitado: {currentUser.name}</p>
            <p className="mt-1 text-slate-300">
              Por defecto, los invitados tienen autorización para <strong>editar trabajadores</strong>. Solo el Administrador puede activar permisos adicionales para gestionar empresas, ver auditoría, modificar salarios o descargar la planilla. El acceso a cada cuenta es exclusivo mediante su PIN.
            </p>
          </div>
        </div>
      )}

      {/* Admin Access Codes Management (PINs de Inicio de Sesión) */}
      {isAdmin && (
        <div className="liquid-glass rounded-3xl p-5 border border-white/10 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Códigos de Inicio de Sesión de Roles (Editables por Administrador)
              </h3>
            </div>
            <span className="text-[11px] text-slate-400">
              PINs específicos para Administrador, Guardia e Invitados
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-snug">
            Configura los códigos que permitirán a los usuarios iniciar sesión en el sistema sin necesidad de contraseña compleja. Al introducir este código en la pantalla de acceso, el usuario entrará automáticamente con el rol y permisos correspondientes.
          </p>

          <form onSubmit={handleSaveAccessCodes} className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
            
            {/* Admin PIN */}
            <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-cyan-300">
                  Código de Administrador:
                </label>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300">
                  Total
                </span>
              </div>
              <input
                type="text"
                required
                value={adminCode}
                onChange={e => setAdminCode(e.target.value)}
                placeholder="2004"
                className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-cyan-300"
              />
              <span className="text-[10px] text-slate-400 block">
                Da acceso total como Administrador Principal.
              </span>
            </div>

            {/* Guard PIN */}
            <div className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-emerald-300">
                  Código de Guardia:
                </label>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300">
                  Garita QR
                </span>
              </div>
              <input
                type="text"
                required
                value={guardCode}
                onChange={e => setGuardCode(e.target.value)}
                placeholder="GUARDIA-7788"
                className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-emerald-300"
              />
              <span className="text-[10px] text-slate-400 block">
                Abre directamente la terminal de escaneo y marcaje.
              </span>
            </div>

            {/* Guest PIN */}
            <div className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-amber-300">
                  Código de Invitado:
                </label>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300">
                  Edición
                </span>
              </div>
              <input
                type="text"
                required
                value={guestCode}
                onChange={e => setGuestCode(e.target.value)}
                placeholder="INVITADO-1234"
                className="w-full px-3 py-2 rounded-xl liquid-glass-input text-xs font-mono font-bold text-amber-300"
              />
              <span className="text-[10px] text-slate-400 block">
                Acceso como invitado según permisos configurados.
              </span>
            </div>

            <div className="md:col-span-3 flex justify-end pt-2">
              <button
                type="submit"
                disabled={isSavingCodes}
                className="px-5 py-2 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 transition-all shadow-[0_0_15px_rgba(6,182,212,0.35)] flex items-center gap-1.5 disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{isSavingCodes ? 'Guardando Códigos...' : 'Guardar Nuevos Códigos de Acceso'}</span>
              </button>
            </div>

          </form>
        </div>
      )}

      {/* User Permission Cards */}
      <div className="space-y-6">
        {users.map(user => {
          const isUserAdmin = user.role === 'ADMIN';
          const isCurrentActive = user.id === currentUser.id;

          return (
            <div
              key={user.id}
              className={`liquid-glass rounded-3xl p-5 transition-all ${
                isCurrentActive ? 'border-cyan-400/40 shadow-[0_0_25px_rgba(6,182,212,0.15)]' : 'border-white/10'
              }`}
            >
              {/* User Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm ${
                    isUserAdmin 
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 shadow-[0_0_15px_rgba(6,182,212,0.3)]' 
                      : user.role === 'GUARD'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                  }`}>
                    {isUserAdmin ? 'ADM' : (user.role === 'GUARD' ? 'GUA' : 'INV')}
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-bold text-white">{user.name}</h3>
                      {user.role === 'GUARD' && (
                        <span className="text-[10px] font-bold text-purple-300 bg-purple-500/20 border border-purple-500/30 px-2 py-0.5 rounded-full flex items-center gap-1 shadow-[0_0_10px_rgba(168,85,247,0.2)]">
                          <Lock className="w-3 h-3 text-purple-400" />
                          Sueldos Protegidos
                        </span>
                      )}
                      {!user.permissions.canViewSalaries && user.role !== 'GUARD' && (
                        <span className="text-[10px] font-bold text-amber-300 bg-amber-500/20 border border-amber-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Lock className="w-3 h-3 text-amber-400" />
                          Sin acceso salarial
                        </span>
                      )}
                      {isCurrentActive && (
                        <span className="text-[10px] font-bold text-cyan-300 bg-cyan-500/20 border border-cyan-500/30 px-2 py-0.5 rounded-full">
                          Sesión Actual
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                      <span>{user.email}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-semibold text-slate-300">
                        {isUserAdmin ? 'Acceso Total (Super Admin)' : (user.role === 'GUARD' ? 'Guardia de Seguridad (Sin acceso a sueldos)' : 'Invitado con Permisos Granulares')}
                      </span>
                    </div>
                  </div>
                </div>

                {!isCurrentActive && (
                  <div className="flex items-center gap-2">
                    {isAdmin && user.id !== 'user-admin' && onDeleteUser && (
                      <button
                        onClick={async () => {
                          if (window.confirm(`¿Desea eliminar al usuario ${user.name}?`)) {
                            const reason = prompt(`¿Por qué desea eliminar al usuario ${user.name}? (Motivo obligatorio):`);
                            if (reason && reason.trim()) {
                              try {
                                await onDeleteUser(user.id, reason.trim());
                              } catch (err: any) {
                                alert(err.message || 'Error al eliminar usuario');
                              }
                            }
                          }
                        }}
                        className="p-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition-colors"
                        title="Eliminar usuario"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Admin Assignment of Role & Personal Access Code (Claves de Acceso) */}
              {isAdmin && !isUserAdmin && (
                <div className="mt-3.5 p-3.5 rounded-2xl bg-black/40 border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                  <div className="flex-1 space-y-1">
                    <span className="font-bold text-white flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Asignación de Clave de Acceso & Rol:</span>
                    </span>
                    <p className="text-[11px] text-slate-400">
                      Asigna la clave personal que este usuario utilizará para iniciar sesión en el sistema.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] text-slate-400 font-medium">Rol:</span>
                      <select
                        value={user.role}
                        onChange={async (e) => {
                          const newRole = e.target.value as 'ADMIN' | 'GUEST' | 'GUARD';
                          if (onUpdateUserRoleAndCode) {
                            await onUpdateUserRoleAndCode(user.id, { role: newRole });
                          }
                        }}
                        className="px-2.5 py-1.5 rounded-xl liquid-glass-input text-xs font-bold text-cyan-300 bg-black/60 border border-white/10"
                      >
                        <option value="GUARD" className="bg-slate-900 text-white">Guardia de Garita</option>
                        <option value="GUEST" className="bg-slate-900 text-white">Invitado General</option>
                        <option value="ADMIN" className="bg-slate-900 text-white">Administrador</option>
                      </select>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] text-slate-400 font-medium">Clave:</span>
                      <input
                        type="text"
                        placeholder="Ej. 1234 / PIN"
                        defaultValue={user.personalAccessCode || ''}
                        onBlur={async (e) => {
                          const val = e.target.value.trim();
                          if (val !== (user.personalAccessCode || '')) {
                            if (onUpdateUserRoleAndCode) {
                              await onUpdateUserRoleAndCode(user.id, { role: user.role, personalAccessCode: val });
                            }
                          }
                        }}
                        className="w-28 px-2.5 py-1.5 rounded-xl liquid-glass-input text-xs font-mono font-bold text-emerald-300 bg-black/60 border border-white/10"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Permissions Matrix */}
              <div className="mt-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Privilegios & Pestañas Habilitadas
                  </h4>
                  <span className="text-[10px] text-cyan-400 font-medium">
                    {user.role === 'GUARD' ? 'Guardia: Sueldos y descuentos estrictamente ocultos' : 'Al desmarcar una pestaña, se remueve de su barra de navegación'}
                  </span>
                </div>

                {isUserAdmin ? (
                  <div className="p-3 bg-black/40 rounded-2xl text-xs text-slate-300 border border-white/5 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>
                      El Administrador cuenta con permisos irrestrictos sobre todas las empresas, colaboradores, salarios, auditoría y descarga de planillas.
                    </span>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {permissionDefinitions.map(def => {
                      const isGranted = !!user.permissions[def.key];
                      const Icon = def.icon;

                      return (
                        <div
                          key={def.key}
                          className={`p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                            def.isSalaryPrivacy && !isGranted
                              ? 'bg-purple-950/20 border-purple-500/40 shadow-[0_0_15px_rgba(168,85,247,0.1)]'
                              : isGranted 
                              ? 'bg-emerald-500/10 border-emerald-500/30' 
                              : 'bg-black/30 border-white/5 opacity-70'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between mb-1.5 gap-2">
                              <div className="flex items-center gap-2">
                                <Icon className={`w-4 h-4 shrink-0 ${
                                  def.isSalaryPrivacy && !isGranted 
                                    ? 'text-purple-400' 
                                    : isGranted 
                                    ? 'text-emerald-400' 
                                    : 'text-slate-500'
                                }`} />
                                <span className={`text-xs font-bold leading-tight ${isGranted ? 'text-white' : 'text-slate-400'}`}>
                                  {def.title}
                                </span>
                              </div>
                              <span className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded border shrink-0 ${
                                def.isSalaryPrivacy
                                  ? 'text-purple-300 bg-purple-500/15 border-purple-500/30'
                                  : def.category === 'VISUALIZACIÓN'
                                  ? 'text-cyan-300 bg-cyan-500/15 border-cyan-500/30'
                                  : 'text-amber-300 bg-amber-500/15 border-amber-500/30'
                              }`}>
                                {def.badge}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 leading-snug">
                              {def.description}
                            </p>
                            {def.category === 'VISUALIZACIÓN' && !isGranted && (
                              <span className="text-[10px] text-rose-400 font-medium block mt-1.5">
                                🚫 Pestaña oculta en la barra de navegación
                              </span>
                            )}
                          </div>

                          {/* Toggle Button for Admin */}
                          {isAdmin && (
                            <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-between">
                              <span className="text-[10px] text-slate-500">
                                {isGranted ? 'Habilitado' : 'Deshabilitado'}
                              </span>
                              <button
                                onClick={() => handleTogglePermission(user, def.key)}
                                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                                  isGranted
                                    ? 'bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 border border-rose-500/30'
                                    : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/30'
                                }`}
                              >
                                {isGranted ? 'Revocar Permiso' : 'Conceder Permiso'}
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Create User Modal in Liquid Glass */}
      {isAddUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="liquid-glass-elevated rounded-3xl max-w-md w-full p-6 border border-white/15">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-lg font-bold text-white">Crear Nuevo Usuario</h3>
              <button
                onClick={() => setIsAddUserModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Nombre Completo
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Mario Roberto Lemus"
                  value={newUserData.name}
                  onChange={e => setNewUserData({ ...newUserData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Correo Electrónico
                </label>
                <input
                  type="email"
                  required
                  placeholder="mario.lemus@empresa.gt"
                  value={newUserData.email}
                  onChange={e => setNewUserData({ ...newUserData, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Tipo de Cuenta
                </label>
                <select
                  value={newUserData.role}
                  onChange={e => setNewUserData({ ...newUserData, role: e.target.value as any })}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                >
                  <option value="GUEST" className="bg-slate-900 text-white">Invitado (Por defecto: Solo editar empleados)</option>
                  <option value="GUARD" className="bg-slate-900 text-white">Guardia de Seguridad (Marcaje QR y Control GPS)</option>
                  <option value="ADMIN" className="bg-slate-900 text-white">Administrador (Acceso Total)</option>
                </select>
                <span className="text-[10px] text-slate-400 block mt-1">
                  Los guardias utilizan la cámara o escáner para registrar entradas y salidas con el código QR del administrador.
                </span>
              </div>

              <div className="pt-3 border-t border-white/10 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddUserModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 rounded-xl disabled:opacity-50 shadow-[0_0_15px_rgba(6,182,212,0.3)]"
                >
                  {isSubmitting ? 'Creando...' : 'Crear Usuario'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
