import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Building2, 
  History, 
  Calendar, 
  DollarSign, 
  Lock, 
  X, 
  Check, 
  AlertCircle,
  Phone,
  PhoneCall,
  MessageCircle,
  Eye,
  KeyRound,
  Copy,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  WifiOff,
  Shirt,
  Tag,
  Undo2,
  CreditCard,
  Printer,
  Download,
  FileText,
  FileDown,
  FileSpreadsheet,
  Layers,
  Filter,
  Loader2
} from 'lucide-react';
import { Company, Employee, AuditLog, AppUser, GuardCheckin, SystemSecurityConfig, GuardDiscount, GUATEMALA_BANKS, GuardPayment, PaymentReceipt } from '../types';
import { formatCurrencyGTQ, formatDate, formatDateTime, formatDPI } from '../utils/formatters';
import { 
  exportReceiptToPDF, 
  exportMultipleReceiptsOneByOne,
  exportQuincenaReceiptsToPDF, 
  exportReceiptsHistoryReportToPDF,
  exportEmployeePaymentsStatementToPDF 
} from '../utils/receiptPdfExport';
import { exportReceiptsHistoryToExcel } from '../utils/excelExport';
import { GuardDiscountsAndPaymentsTab } from './GuardDiscountsAndPaymentsTab';
import { PaymentReceiptModal } from './PaymentReceiptModal';
import { DocumentsTab } from './DocumentsTab';

interface EmployeesViewProps {
  employees: Employee[];
  companies: Company[];
  auditLogs: AuditLog[];
  currentUser: AppUser;
  selectedCompanyFilter: string;
  setSelectedCompanyFilter: (id: string) => void;
  onSaveEmployee: (employeeData: Partial<Employee>, isEdit: boolean) => Promise<void>;
  onDeleteEmployee: (employeeId: string) => Promise<void>;
  onViewAudit: (employeeId?: string) => void;
  guardCheckins?: GuardCheckin[];
  onAddDiscount?: (employeeId: string, data: { 
    amount: number; 
    reason: string; 
    description?: string; 
    period?: '1RA_QUINCENA' | '2DA_QUINCENA' | 'MENSUAL';
    discountType?: 'ANTICIPO' | 'UNIFORME' | 'OTRO';
    installments?: number;
    installmentAmount?: number;
    date?: string;
    startYear?: number;
    startMonth?: number;
    startQuincena?: 1 | 2;
    uniformItems?: string[];
    uniformItemIds?: string[];
    uniformQuantities?: Record<string, number>;
    uniformItemDetails?: { id: string; name: string; quantity: number; unitPrice: number; subtotal: number }[];
  }) => Promise<void>;
  onDeleteDiscount?: (employeeId: string, discountId: string, reason?: string) => Promise<void>;
  onUpdateDiscountStart?: (employeeId: string, discountId: string, data: { startYear: number; startMonth: number; startQuincena: 1 | 2; installments?: number }) => Promise<void>;
  securityConfig?: SystemSecurityConfig | null;
  payments?: GuardPayment[];
  onRecordPayment?: (paymentData: any) => Promise<void>;
  onAddBank?: (bankName: string) => Promise<void>;
  receipts?: PaymentReceipt[];
  onDeleteReceipt?: (receiptId: string) => Promise<void>;
}

export const EmployeesView: React.FC<EmployeesViewProps> = ({
  employees,
  companies,
  auditLogs,
  currentUser,
  selectedCompanyFilter,
  setSelectedCompanyFilter,
  onSaveEmployee,
  onDeleteEmployee,
  guardCheckins = [],
  onAddDiscount,
  onDeleteDiscount,
  onUpdateDiscountStart,
  securityConfig,
  payments = [],
  onRecordPayment,
  onAddBank,
  receipts = [],
  onDeleteReceipt,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVO' | 'DE_BAJA'>('ALL');
  
  // Modals state
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddBankModalOpen, setIsAddBankModalOpen] = useState(false);
  const [newBankName, setNewBankName] = useState('');
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [historyModalEmployee, setHistoryModalEmployee] = useState<Employee | null>(null);
  const [viewingEmployee, setViewingEmployee] = useState<Employee | null>(null);
  const [copiedPin, setCopiedPin] = useState(false);
  const [selectedReceiptForView, setSelectedReceiptForView] = useState<PaymentReceipt | null>(null);

  // Dynamic banks list
  const allBanks = [
    ...GUATEMALA_BANKS,
    ...(securityConfig?.customBanks || [])
  ];


  // Payment states for viewingEmployee (Exclusivo Administrador)
  const [paymentPeriod, setPaymentPeriod] = useState<'1RA_QUINCENA' | '2DA_QUINCENA'>('1RA_QUINCENA');
  const [paymentMonth, setPaymentMonth] = useState<number>(new Date().getMonth() + 1);
  const [paymentYear, setPaymentYear] = useState<number>(new Date().getFullYear());
  const [paymentBank, setPaymentBank] = useState<string>(allBanks[0]);
  const [paymentMethod, setPaymentMethod] = useState<'TRANSFERENCIA' | 'CHEQUE' | 'EFECTIVO'>('TRANSFERENCIA');
  const [paymentReference, setPaymentReference] = useState('');
  const [customPaymentAmount, setCustomPaymentAmount] = useState<string>('');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentSuccessMsg, setPaymentSuccessMsg] = useState<string | null>(null);

  // Filter for movements/discounts by month (Cualquier movimiento se queda en el mes)
  const [selectedHistoryMonth, setSelectedHistoryMonth] = useState<string>('ALL');
  const [workerModalTab, setWorkerModalTab] = useState<'INFO' | 'DESCUENTOS' | 'RECIBOS' | 'DOCUMENTOS' | 'HISTORIAL'>('INFO');

  // PDF Export states for worker receipts
  const [isExportingStatement, setIsExportingStatement] = useState(false);
  const [exportingReceiptId, setExportingReceiptId] = useState<string | null>(null);
  const [statementSuccessMsg, setStatementSuccessMsg] = useState<string | null>(null);

  const handleExportStatement = async () => {
    if (!viewingEmployee) return;
    try {
      setIsExportingStatement(true);
      const company = companyMap.get(viewingEmployee.companyId);
      await exportEmployeePaymentsStatementToPDF({
        employee: viewingEmployee,
        receipts,
        payments,
        month: paymentMonth,
        year: paymentYear,
        companyName: company?.name || 'GUARDIA REAL DE GUATEMALA',
        companyNit: company?.nit || 'NIT: 9812401-2',
        companyAddress: company?.address || 'Ciudad de Guatemala',
        generatedBy: currentUser.name || 'Administración Central',
      });
      setStatementSuccessMsg('¡Detalle PDF consolidado exportado y descargado exitosamente!');
      setTimeout(() => setStatementSuccessMsg(null), 3500);
    } catch (err) {
      console.error('Error al exportar detalle a PDF:', err);
      alert('Ocurrió un error al generar el PDF del detalle.');
    } finally {
      setIsExportingStatement(false);
    }
  };

  const handleDownloadSingleReceipt = async (receipt: PaymentReceipt) => {
    if (!viewingEmployee) return;
    try {
      setExportingReceiptId(receipt.id);
      const company = companyMap.get(viewingEmployee.companyId);
      await exportReceiptToPDF(
        receipt,
        company?.name || 'GUARDIA REAL DE GUATEMALA',
        company?.nit || 'NIT: 9812401-2'
      );
    } catch (err) {
      console.error('Error al exportar recibo a PDF:', err);
      alert('Ocurrió un error al generar el PDF del comprobante.');
    } finally {
      setExportingReceiptId(null);
    }
  };

  const handleExportQuincenaReceipts = async (periodFilter: '1RA_QUINCENA' | '2DA_QUINCENA' | 'ALL') => {
    if (!viewingEmployee) return;
    try {
      setIsExportingStatement(true);
      const company = companyMap.get(viewingEmployee.companyId);
      const allMonthReceipts = receipts.filter(
        r => r.employeeId === viewingEmployee.id && r.month === paymentMonth && r.year === paymentYear
      );

      let targetReceipts = allMonthReceipts;
      let label = `Mes ${paymentMonth}/${paymentYear}`;

      if (periodFilter === '1RA_QUINCENA') {
        targetReceipts = allMonthReceipts.filter(r => 
          (r.period && r.period.includes('1RA')) || 
          r.concept.toUpperCase().includes('1RA') || 
          r.concept.toUpperCase().includes('PRIMERA') ||
          r.day <= 15
        );
        label = `1ra Quincena (${paymentMonth}/${paymentYear})`;
      } else if (periodFilter === '2DA_QUINCENA') {
        targetReceipts = allMonthReceipts.filter(r => 
          (r.period && r.period.includes('2DA')) || 
          r.concept.toUpperCase().includes('2DA') || 
          r.concept.toUpperCase().includes('SEGUNDA') ||
          r.day > 15
        );
        label = `2da Quincena (${paymentMonth}/${paymentYear})`;
      }

      if (targetReceipts.length === 0) {
        alert(`No hay comprobantes emitidos para ${label}. Puedes generar el recibo registrando el pago en la pestaña Descuentos.`);
        return;
      }

      await exportQuincenaReceiptsToPDF({
        receipts: targetReceipts,
        employeeName: viewingEmployee.name,
        periodLabel: label,
        companyName: company?.name || 'GUARDIA REAL DE GUATEMALA',
        companyNit: company?.nit || 'NIT: 9812401-2',
      });

      setStatementSuccessMsg(`¡Recibos de ${label} exportados en Hoja Carta (2 por hoja) con éxito!`);
      setTimeout(() => setStatementSuccessMsg(null), 3500);
    } catch (err: any) {
      console.error('Error al exportar quincena a PDF:', err);
      alert(err.message || 'Error al exportar recibos en tamaño carta.');
    } finally {
      setIsExportingStatement(false);
    }
  };

  // Exportar todos los recibos del colaborador actual UNO POR UNO en Hoja Carta
  const handleExportCollaboratorReceiptsOneByOne = async () => {
    if (!viewingEmployee) return;
    try {
      setIsExportingStatement(true);
      const company = companyMap.get(viewingEmployee.companyId);
      const filtered = receipts.filter(
        r => r.employeeId === viewingEmployee.id && r.month === paymentMonth && r.year === paymentYear
      );
      if (filtered.length === 0) {
        alert('No hay comprobantes emitidos para este colaborador en el mes seleccionado.');
        return;
      }
      await exportMultipleReceiptsOneByOne(filtered, {
        employeeName: viewingEmployee.name,
        companyName: company?.name || 'GUARDIA REAL DE GUATEMALA',
        companyNit: company?.nit || 'NIT: 9812401-2',
        filePrefix: `Recibos_UnoPorUno_${paymentMonth}_${paymentYear}`
      });
      setStatementSuccessMsg('¡Recibos exportados en Hoja Carta (uno por uno) con éxito!');
      setTimeout(() => setStatementSuccessMsg(null), 3500);
    } catch (err: any) {
      console.error('Error al exportar recibos uno por uno:', err);
      alert(err.message || 'Error al exportar recibos uno por uno.');
    } finally {
      setIsExportingStatement(false);
    }
  };

  // Estados para el Histórico de Recibos en la pestaña de trabajadores
  const [isReceiptsHistoryModalOpen, setIsReceiptsHistoryModalOpen] = useState(false);
  const [historyQuincenaFilter, setHistoryQuincenaFilter] = useState<'ALL' | '1RA_QUINCENA' | '2DA_QUINCENA'>('ALL');
  const [historyMonthFilter, setHistoryMonthFilter] = useState<string>('ALL'); // 'ALL' or '1'..'12'
  const [historyYearFilter, setHistoryYearFilter] = useState<number>(new Date().getFullYear());
  const [historySearchTerm, setHistorySearchTerm] = useState<string>('');
  const [isExportingHistory, setIsExportingHistory] = useState(false);
  const [historySuccessMsg, setHistorySuccessMsg] = useState<string | null>(null);

  // Helper para filtrar los recibos del histórico según los criterios
  const getFilteredHistoryReceipts = () => {
    return receipts.filter(r => {
      // Filtro de Empresa (respeta el filtro de empresa de la pestaña de trabajadores)
      if (selectedCompanyFilter !== 'all') {
        const emp = employees.find(e => e.id === r.employeeId);
        if (emp && emp.companyId !== selectedCompanyFilter) return false;
      }
      // Filtro de Año
      if (r.year !== historyYearFilter) return false;
      // Filtro de Mes
      if (historyMonthFilter !== 'ALL' && r.month !== parseInt(historyMonthFilter)) return false;
      // Filtro de Quincena (1ra o 2da)
      if (historyQuincenaFilter === '1RA_QUINCENA') {
        const is1st = (r.period && r.period.includes('1RA')) || 
                      r.concept.toUpperCase().includes('1RA') || 
                      r.concept.toUpperCase().includes('PRIMERA') || 
                      r.day <= 15;
        if (!is1st) return false;
      } else if (historyQuincenaFilter === '2DA_QUINCENA') {
        const is2nd = (r.period && r.period.includes('2DA')) || 
                      r.concept.toUpperCase().includes('2DA') || 
                      r.concept.toUpperCase().includes('SEGUNDA') || 
                      r.day > 15;
        if (!is2nd) return false;
      }
      // Búsqueda por texto (nombre, DPI, concepto, boleta)
      if (historySearchTerm.trim()) {
        const term = historySearchTerm.toLowerCase();
        const matchesName = r.employeeName.toLowerCase().includes(term);
        const matchesConcept = r.concept.toLowerCase().includes(term);
        const matchesDpi = r.employeeDpi ? r.employeeDpi.includes(term) : false;
        const matchesRef = r.referenceNumber ? r.referenceNumber.toLowerCase().includes(term) : false;
        if (!matchesName && !matchesConcept && !matchesDpi && !matchesRef) return false;
      }
      return true;
    });
  };

  const getHistoryPeriodLabel = () => {
    const qLabel = historyQuincenaFilter === '1RA_QUINCENA' 
      ? '1ra Quincena' 
      : historyQuincenaFilter === '2DA_QUINCENA' 
      ? '2da Quincena' 
      : 'Todas las Quincenas';
    const mLabel = historyMonthFilter === 'ALL' 
      ? 'Todo el Año' 
      : new Date(2000, parseInt(historyMonthFilter) - 1).toLocaleString('es', { month: 'long' });
    return `${qLabel} - ${mLabel} ${historyYearFilter}`;
  };

  // Descargar Histórico en PDF (Reporte Consolidado Carta)
  const handleExportHistoryReportPDF = async () => {
    const targetReceipts = getFilteredHistoryReceipts();
    if (targetReceipts.length === 0) {
      alert('No se encontraron recibos con los filtros seleccionados.');
      return;
    }
    try {
      setIsExportingHistory(true);
      const company = selectedCompanyFilter !== 'all' ? companyMap.get(selectedCompanyFilter) : undefined;
      await exportReceiptsHistoryReportToPDF({
        receipts: targetReceipts,
        periodLabel: getHistoryPeriodLabel(),
        quincenaFilter: historyQuincenaFilter,
        month: historyMonthFilter === 'ALL' ? undefined : parseInt(historyMonthFilter),
        year: historyYearFilter,
        companyName: company?.name || 'GUARDIA REAL DE GUATEMALA',
        companyNit: company?.nit || 'NIT: 9812401-2',
        generatedBy: currentUser.name || 'Administración Central',
      });
      setHistorySuccessMsg('¡Histórico en PDF descargado exitosamente!');
      setTimeout(() => setHistorySuccessMsg(null), 3500);
    } catch (err: any) {
      console.error('Error al exportar histórico a PDF:', err);
      alert(err.message || 'Error al generar el PDF del histórico.');
    } finally {
      setIsExportingHistory(false);
    }
  };

  // Descargar todos los comprobantes del histórico en lote (Uno por uno en Hoja Carta)
  const handleExportHistoryVouchersOneByOne = async () => {
    const targetReceipts = getFilteredHistoryReceipts();
    if (targetReceipts.length === 0) {
      alert('No se encontraron recibos con los filtros seleccionados.');
      return;
    }
    try {
      setIsExportingHistory(true);
      const company = selectedCompanyFilter !== 'all' ? companyMap.get(selectedCompanyFilter) : undefined;
      await exportMultipleReceiptsOneByOne(targetReceipts, {
        employeeName: getHistoryPeriodLabel(),
        companyName: company?.name || 'GUARDIA REAL DE GUATEMALA',
        companyNit: company?.nit || 'NIT: 9812401-2',
        filePrefix: 'Lote_Comprobantes_UnoPorUno'
      });
      setHistorySuccessMsg('¡Comprobantes uno por uno descargados en Hoja Carta!');
      setTimeout(() => setHistorySuccessMsg(null), 3500);
    } catch (err: any) {
      console.error('Error al exportar comprobantes uno por uno:', err);
      alert(err.message || 'Error al generar los comprobantes.');
    } finally {
      setIsExportingHistory(false);
    }
  };

  // Descargar histórico a Excel (.xlsx)
  const handleExportHistoryExcel = () => {
    const targetReceipts = getFilteredHistoryReceipts();
    if (targetReceipts.length === 0) {
      alert('No se encontraron recibos con los filtros seleccionados.');
      return;
    }
    try {
      const company = selectedCompanyFilter !== 'all' ? companyMap.get(selectedCompanyFilter) : undefined;
      exportReceiptsHistoryToExcel(targetReceipts, {
        periodLabel: getHistoryPeriodLabel(),
        quincenaFilter: historyQuincenaFilter,
        companyName: company?.name || 'GUARDIA REAL DE GUATEMALA',
      });
      setHistorySuccessMsg('¡Histórico exportado a Excel con éxito!');
      setTimeout(() => setHistorySuccessMsg(null), 3500);
    } catch (err: any) {
      console.error('Error al exportar a Excel:', err);
      alert('Error al generar el archivo Excel.');
    }
  };

  // Keep viewingEmployee updated when employees prop updates
  useEffect(() => {
    if (viewingEmployee) {
      const refreshed = employees.find(e => e.id === viewingEmployee.id);
      if (refreshed && refreshed !== viewingEmployee) {
        setViewingEmployee(refreshed);
      }
    } else {
      setWorkerModalTab('INFO');
    }
  }, [employees, viewingEmployee]);

  // Synchronize payment bank with viewing employee
  useEffect(() => {
    if (viewingEmployee) {
      setPaymentBank(viewingEmployee.bankName || allBanks[0]);
      if (viewingEmployee.bankName === 'En efectivo') {
        setPaymentMethod('EFECTIVO');
      }
    }
  }, [viewingEmployee?.id]);

  // Form fields
  const [formData, setFormData] = useState({
    companyId: '',
    name: '',
    dpi: '',
    position: '',
    monthlySalary: '',
    appliesIGSS: true,
    startDate: '',
    endDate: '',
    phone: '',
    email: '',
    pinCode: '',
    bankName: allBanks[0] as string,
    bankAccountNumber: '',
    paymentMethodPreference: 'TRANSFERENCIA' as 'TRANSFERENCIA' | 'CHEQUE' | 'EFECTIVO',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Contact helper for WhatsApp
  const getWhatsAppUrl = (phone?: string, name?: string) => {
    if (!phone) return null;
    let digits = phone.replace(/\D/g, '');
    if (!digits) return null;
    if (digits.length === 8) {
      digits = `502${digits}`;
    }
    const text = encodeURIComponent(`Hola ${name || 'colaborador'}, te saludamos de Guardia Real.`);
    return `https://wa.me/${digits}?text=${text}`;
  };

  // Contact helper for Direct Phone Call
  const getPhoneCallUrl = (phone?: string) => {
    if (!phone) return null;
    const digits = phone.replace(/[^\d+]/g, '');
    return digits ? `tel:${digits}` : null;
  };

  // Copy PIN to clipboard
  const handleCopyPin = (pin?: string) => {
    if (!pin) return;
    navigator.clipboard?.writeText(pin);
    setCopiedPin(true);
    setTimeout(() => setCopiedPin(false), 2500);
  };

  // Generate random 4-digit PIN for Admin
  const generateRandomPin = () => {
    const randomPin = String(Math.floor(1000 + Math.random() * 9000));
    setFormData(prev => ({ ...prev, pinCode: randomPin }));
  };

  // Permissions
  const canEdit = currentUser.role === 'ADMIN' || currentUser.permissions.canEditEmployees || currentUser.role === 'GUEST';
  const canCreate = currentUser.role === 'ADMIN' || currentUser.permissions.canCreateEmployees;
  const canDelete = currentUser.role === 'ADMIN' || currentUser.permissions.canDeleteEmployees;
  const canViewSalaries = currentUser.role === 'ADMIN' || (currentUser.role !== 'GUARD' && currentUser.permissions?.canViewSalaries !== false);
  const canModifySalaries = currentUser.role === 'ADMIN' || (currentUser.permissions.canModifySalaries && canViewSalaries);
  const isAdmin = currentUser.role === 'ADMIN';

  const companyMap = new Map<string, Company>();
  companies.forEach(c => companyMap.set(c.id, c));

  // Filtered employees
  const filteredEmployees = employees.filter(emp => {
    if (selectedCompanyFilter && selectedCompanyFilter !== 'all') {
      if (emp.companyId !== selectedCompanyFilter) return false;
    }
    if (statusFilter !== 'ALL' && emp.status !== statusFilter) {
      return false;
    }
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const matchName = emp.name.toLowerCase().includes(q);
      const matchDpi = emp.dpi.replace(/\s+/g, '').includes(q.replace(/\s+/g, ''));
      const matchPos = emp.position.toLowerCase().includes(q);
      const matchPin = emp.pinCode ? emp.pinCode.includes(q) : false;
      const compName = companyMap.get(emp.companyId)?.name.toLowerCase() || '';
      const matchComp = compName.includes(q);
      return matchName || matchDpi || matchPos || matchComp || matchPin;
    }
    return true;
  });

  const handleOpenAddModal = () => {
    setEditingEmployee(null);
    setFormData({
      companyId: selectedCompanyFilter && selectedCompanyFilter !== 'all' ? selectedCompanyFilter : (companies[0]?.id || ''),
      name: '',
      dpi: '',
      position: '',
      monthlySalary: '',
      appliesIGSS: true,
      startDate: new Date().toISOString().slice(0, 10),
      endDate: '',
      phone: '',
      email: '',
      pinCode: String(Math.floor(1000 + Math.random() * 9000)),
      bankName: GUATEMALA_BANKS[0] as string,
      bankAccountNumber: '',
      paymentMethodPreference: 'TRANSFERENCIA',
    });
    setErrorMessage('');
    setIsEditModalOpen(true);
  };

  const handleOpenEditModal = (emp: Employee) => {
    setEditingEmployee(emp);
    setFormData({
      companyId: emp.companyId,
      name: emp.name,
      dpi: emp.dpi,
      position: emp.position,
      monthlySalary: emp.monthlySalary.toString(),
      appliesIGSS: emp.appliesIGSS !== false,
      startDate: emp.startDate || '',
      endDate: emp.endDate || '',
      phone: emp.phone || '',
      email: emp.email || '',
      pinCode: emp.pinCode || '',
      bankName: emp.bankName || GUATEMALA_BANKS[0],
      bankAccountNumber: emp.bankAccountNumber || '',
      paymentMethodPreference: emp.paymentMethodPreference || (emp.bankName === 'En efectivo' ? 'EFECTIVO' : 'TRANSFERENCIA'),
    });
    setErrorMessage('');
    setIsEditModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      setErrorMessage('El nombre del colaborador es obligatorio.');
      return;
    }
    if (!formData.dpi.trim()) {
      setErrorMessage('El número de DPI es obligatorio.');
      return;
    }
    if (!formData.position.trim()) {
      setErrorMessage('El puesto / cargo es obligatorio.');
      return;
    }
    if (!formData.companyId) {
      setErrorMessage('Debe seleccionar la empresa a la que pertenece.');
      return;
    }

    const salaryNumber = parseFloat(formData.monthlySalary) || 0;

    try {
      setIsSubmitting(true);
      setErrorMessage('');
      await onSaveEmployee(
        {
          ...(editingEmployee ? { id: editingEmployee.id } : {}),
          companyId: formData.companyId,
          name: formData.name.trim(),
          dpi: formData.dpi.trim(),
          position: formData.position.trim(),
          monthlySalary: salaryNumber,
          appliesIGSS: formData.appliesIGSS,
          startDate: formData.startDate,
          endDate: formData.endDate ? formData.endDate : null,
          phone: formData.phone.trim(),
          email: formData.email.trim(),
          bankName: formData.bankName,
          bankAccountNumber: formData.bankAccountNumber.trim(),
          paymentMethodPreference: formData.bankName === 'En efectivo' ? 'EFECTIVO' : formData.paymentMethodPreference,
          pinCode: isAdmin ? (formData.pinCode.trim() || undefined) : (editingEmployee?.pinCode || formData.pinCode.trim() || undefined),
        },
        !!editingEmployee
      );
      setIsEditModalOpen(false);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error al procesar colaborador.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Title & Primary Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Colaboradores & Nómina
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Registro completo de trabajadores, salarios mensuales/quincenales, DPI y control de altas y bajas laborales.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Botón Principal: Histórico de Recibos */}
          <button
            onClick={() => setIsReceiptsHistoryModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-cyan-300 bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 rounded-xl transition-all shadow-sm active:scale-95"
            title="Descargar histórico de recibos emitidos (1ra Quincena, 2da Quincena o Todas)"
          >
            <History className="w-4 h-4 text-cyan-400" />
            <span>Histórico de Recibos</span>
            {receipts.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-cyan-500/30 text-cyan-200 font-mono font-bold">
                {receipts.length}
              </span>
            )}
          </button>

          {canCreate ? (
            <button
              onClick={handleOpenAddModal}
              disabled={companies.length === 0}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 rounded-xl hover:from-cyan-300 hover:to-blue-300 transition-all shadow-[0_0_20px_rgba(6,182,212,0.35)] whitespace-nowrap disabled:opacity-50"
            >
              <Plus className="w-4 h-4 text-slate-950" />
              <span>Registrar Colaborador</span>
            </button>
          ) : (
            <div className="text-xs text-slate-400 liquid-glass px-3 py-1.5 rounded-xl border border-white/5">
              Invitado: Solo edición permitida
            </div>
          )}
        </div>
      </div>

      {/* Barra de Histórico de Recibos y Elección de Quincena en la Pestaña de Trabajadores */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-slate-900/95 via-cyan-950/40 to-slate-900/95 border border-cyan-500/30 shadow-[0_4px_20px_rgba(6,182,212,0.1)] flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/40 shrink-0">
            <History className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-white">
                Histórico de Recibos Emitidos
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                {getFilteredHistoryReceipts().length} Comprobantes
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Elige entre 1ra o 2da quincena para descargar comprobantes en Hoja Carta o informe consolidado
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Selector de Quincena: 1ra Quincena / 2da Quincena / Todas */}
          <div className="flex items-center bg-black/50 p-1 rounded-xl border border-white/10 text-xs font-semibold">
            <button
              onClick={() => setHistoryQuincenaFilter('ALL')}
              className={`px-2.5 py-1 rounded-lg transition-all text-xs ${
                historyQuincenaFilter === 'ALL'
                  ? 'bg-white/15 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Todas
            </button>
            <button
              onClick={() => setHistoryQuincenaFilter('1RA_QUINCENA')}
              className={`px-2.5 py-1 rounded-lg transition-all text-xs ${
                historyQuincenaFilter === '1RA_QUINCENA'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-cyan-400 hover:text-white'
              }`}
            >
              1ra Quincena
            </button>
            <button
              onClick={() => setHistoryQuincenaFilter('2DA_QUINCENA')}
              className={`px-2.5 py-1 rounded-lg transition-all text-xs ${
                historyQuincenaFilter === '2DA_QUINCENA'
                  ? 'bg-blue-500 text-white font-bold shadow-sm'
                  : 'text-blue-400 hover:text-white'
              }`}
            >
              2da Quincena
            </button>
          </div>

          {/* Selector de Mes */}
          <select
            value={historyMonthFilter}
            onChange={(e) => setHistoryMonthFilter(e.target.value)}
            className="bg-black/60 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white capitalize focus:outline-none focus:border-cyan-500/50"
          >
            <option value="ALL" className="bg-slate-900 text-white">Todo el año</option>
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(m => (
              <option key={m} value={m} className="bg-slate-900 text-white">
                {new Date(2000, m - 1).toLocaleString('es', { month: 'long' })}
              </option>
            ))}
          </select>

          {/* Año */}
          <input
            type="number"
            value={historyYearFilter}
            onChange={(e) => setHistoryYearFilter(parseInt(e.target.value) || new Date().getFullYear())}
            className="bg-black/60 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white w-20 font-mono focus:outline-none focus:border-cyan-500/50"
          />

          {/* Botón: Descargar Histórico en PDF */}
          <button
            onClick={handleExportHistoryReportPDF}
            disabled={isExportingHistory || getFilteredHistoryReceipts().length === 0}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 disabled:opacity-50"
            title="Descargar Reporte Histórico en Hoja Tamaño Carta"
          >
            {isExportingHistory ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Generando...</span>
              </>
            ) : (
              <>
                <FileDown className="w-3.5 h-3.5 text-slate-950" />
                <span>Descargar Histórico (PDF)</span>
              </>
            )}
          </button>

          {/* Botón: Descargar Comprobantes en Lote (1 por Hoja Carta) */}
          <button
            onClick={handleExportHistoryVouchersOneByOne}
            disabled={isExportingHistory || getFilteredHistoryReceipts().length === 0}
            className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
            title="Descargar todos los comprobantes de la quincena (uno por uno en Hoja Carta)"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Recibos (1 x Hoja)</span>
          </button>

          {/* Botón: Exportar a Excel */}
          <button
            onClick={handleExportHistoryExcel}
            disabled={getFilteredHistoryReceipts().length === 0}
            className="p-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 transition-all disabled:opacity-50"
            title="Exportar histórico de recibos a Excel (.xlsx)"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
          </button>

          {/* Botón: Abrir Histórico Completo */}
          <button
            onClick={() => setIsReceiptsHistoryModalOpen(true)}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all"
            title="Abrir explorador detallado del histórico de recibos"
          >
            <Eye className="w-4 h-4 text-slate-300" />
          </button>
        </div>
      </div>

      {/* Mensaje de Confirmación de Histórico */}
      {historySuccessMsg && (
        <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{historySuccessMsg}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="liquid-glass p-4 rounded-2xl border border-white/10 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          
          {/* Text Search */}
          <div className="sm:col-span-5 relative flex items-center">
            <Search className="w-4 h-4 text-slate-500 absolute left-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Buscar por nombre, DPI (CUI) o cargo..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl liquid-glass-input"
            />
          </div>

          {/* Company Filter Dropdown */}
          <div className="sm:col-span-4">
            <select
              value={selectedCompanyFilter}
              onChange={e => setSelectedCompanyFilter(e.target.value)}
              aria-label="Filtrar por empresa"
              className="w-full py-2 px-3 text-xs rounded-xl liquid-glass-input"
            >
              <option value="all" className="bg-slate-900 text-white">Todas las empresas ({companies.length})</option>
              {companies.map(c => (
                <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter Segmented Control */}
          <div className="sm:col-span-3 flex items-center bg-black/40 p-1 rounded-xl border border-white/5">
            <button
              onClick={() => setStatusFilter('ALL')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                statusFilter === 'ALL'
                  ? 'bg-white/15 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Todos
            </button>
            <button
              onClick={() => setStatusFilter('ACTIVO')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                statusFilter === 'ACTIVO'
                  ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Activos
            </button>
            <button
              onClick={() => setStatusFilter('DE_BAJA')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                statusFilter === 'DE_BAJA'
                  ? 'bg-rose-500/25 text-rose-300 border border-rose-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              De Baja
            </button>
          </div>

        </div>

        {/* Informative counter */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-white/5">
          <div>
            Mostrando <span className="font-semibold text-white">{filteredEmployees.length}</span> colaboradores
            {selectedCompanyFilter !== 'all' && (
              <span> en <span className="font-medium text-cyan-300">{companyMap.get(selectedCompanyFilter)?.name}</span></span>
            )}
          </div>
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-xs text-slate-400 hover:text-white"
            >
              Limpiar búsqueda
            </button>
          )}
        </div>
      </div>

      {/* Employees Table (Liquid Glass Dark Desktop & Mobile) */}
      {filteredEmployees.length === 0 ? (
        <div className="liquid-glass rounded-2xl p-12 text-center border border-white/10">
          <Users className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-200">No se encontraron colaboradores</h3>
          <p className="text-sm text-slate-400 max-w-sm mx-auto mt-1">
            {searchTerm || selectedCompanyFilter !== 'all' || statusFilter !== 'ALL'
              ? 'Intenta modificando los filtros o el término de búsqueda.'
              : 'Agrega a tu primer trabajador para comenzar a gestionar la nómina.'}
          </p>
          {canCreate && companies.length > 0 && !searchTerm && (
            <button
              onClick={handleOpenAddModal}
              className="mt-4 px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] inline-flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Registrar Primer Trabajador
            </button>
          )}
        </div>
      ) : (
        <div className="liquid-glass rounded-2xl overflow-hidden border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
          
          {/* Desktop Table View */}
          <div className="hidden lg:block overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-black/40 text-slate-400 text-[11px] font-semibold uppercase tracking-wider border-b border-white/10">
                <tr>
                  <th className="py-3.5 px-4">Colaborador & DPI</th>
                  <th className="py-3.5 px-4">Puesto & Empresa</th>
                  {canViewSalaries && <th className="py-3.5 px-4 text-right">Salario Mensual</th>}
                  {canViewSalaries && <th className="py-3.5 px-4 text-right">Quincena (50%)</th>}
                  <th className="py-3.5 px-4">Fechas (Inicio / Baja)</th>
                  <th className="py-3.5 px-4">Estado</th>
                  <th className="py-3.5 px-4 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredEmployees.map(emp => {
                  const comp = companyMap.get(emp.companyId);
                  const isDischarged = emp.status === 'DE_BAJA';
                  const quincenal = (emp.monthlySalary || 0) / 2;

                  return (
                    <tr 
                      key={emp.id} 
                      className={`hover:bg-white/5 transition-colors ${
                        isDischarged ? 'bg-black/20 text-slate-400' : ''
                      }`}
                    >
                      {/* Name & DPI */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-white flex items-center gap-2">
                          <span>{emp.name}</span>
                          {isAdmin && emp.pinCode && (
                            <span 
                              className="inline-flex items-center gap-1 font-mono text-[10px] bg-cyan-950/50 border border-cyan-400/30 text-cyan-300 px-1.5 py-0.2 rounded-md font-bold"
                              title="PIN único de acceso asignado por Administración"
                            >
                              <KeyRound className="w-2.5 h-2.5 text-cyan-400" />
                              PIN: {emp.pinCode}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                          <span className="font-mono text-cyan-400">DPI: {formatDPI(emp.dpi)}</span>
                          {canViewSalaries ? (
                            <>
                              <span aria-hidden="true">·</span>
                              {emp.appliesIGSS !== false ? (
                                <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/15 border border-emerald-500/25 px-1.5 py-0.2 rounded-md">
                                  IGSS 4.83%
                                </span>
                              ) : (
                                <span className="text-[10px] font-semibold text-amber-400 bg-amber-500/15 border border-amber-500/25 px-1.5 py-0.2 rounded-md">
                                  Exento IGSS
                                </span>
                              )}
                            </>
                          ) : (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-[10px] font-medium text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.2 rounded-md">
                                Sueldo Confidencial
                              </span>
                            </>
                          )}
                          {emp.phone && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-[10px] text-slate-400 font-mono">{emp.phone}</span>
                            </>
                          )}
                        </div>
                      </td>

                      {/* Position & Company */}
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-slate-200">
                          {emp.position}
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Building2 className="w-3 h-3 text-slate-500" />
                          <span className="truncate max-w-[200px]">{comp?.name || 'Sin empresa'}</span>
                        </div>
                      </td>

                      {/* Monthly Salary (Only if permitted) */}
                      {canViewSalaries && (
                        <td className="py-3.5 px-4 text-right">
                          <div className="font-bold text-white tabular-nums">
                            {formatCurrencyGTQ(emp.monthlySalary)}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            Base mensual
                          </div>
                        </td>
                      )}

                      {/* Quincenal Estimate (Only if permitted) */}
                      {canViewSalaries && (
                        <td className="py-3.5 px-4 text-right">
                          <div className="font-bold text-cyan-300 tabular-nums">
                            {formatCurrencyGTQ(quincenal)}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            Bruto quincenal
                          </div>
                        </td>
                      )}

                      {/* Dates */}
                      <td className="py-3.5 px-4">
                        <div className="text-slate-300 text-[11px]">
                          Inicio: <span className="font-medium">{formatDate(emp.startDate)}</span>
                        </div>
                        <div className="text-slate-400 text-[11px] mt-0.5">
                          {isDischarged ? (
                            <span className="text-rose-400 font-medium">Baja: {formatDate(emp.endDate)}</span>
                          ) : (
                            <span className="text-slate-400">Sin baja</span>
                          )}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        {isDischarged ? (
                          <span className="inline-flex items-center gap-1.5 text-[11px] text-rose-300 font-semibold bg-rose-500/15 border border-rose-500/30 px-2 py-0.5 rounded-full">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                            De Baja
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 text-[11px] text-emerald-300 font-semibold bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.2)]">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                            Activo
                          </span>
                        )}
                        <div className="text-[10px] text-slate-400 mt-1 truncate max-w-[130px]">
                          Por: {emp.lastModifiedBy || 'Admin'}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          
                          {/* Visualizar perfil completo, contacto y PIN */}
                          <button
                            onClick={() => setViewingEmployee(emp)}
                            title="Visualizar información completa, contacto y PIN de guardia"
                            className="p-1.5 text-cyan-300 hover:text-white bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded-lg transition-all"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* WhatsApp Direct Action */}
                          {emp.phone && (
                            <a
                              href={getWhatsAppUrl(emp.phone, emp.name)!}
                              target="_blank"
                              rel="noopener noreferrer"
                              title={`Enviar mensaje de WhatsApp a ${emp.phone}`}
                              className="p-1.5 text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-lg transition-all"
                            >
                              <MessageCircle className="w-4 h-4" />
                            </a>
                          )}

                          {/* Phone Call Direct Action */}
                          {emp.phone && (
                            <a
                              href={getPhoneCallUrl(emp.phone)!}
                              title={`Llamar por teléfono a ${emp.phone}`}
                              className="p-1.5 text-sky-400 hover:text-sky-300 bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 rounded-lg transition-all"
                            >
                              <PhoneCall className="w-4 h-4" />
                            </a>
                          )}

                          {/* View Audit History */}
                          <button
                            onClick={() => setHistoryModalEmployee(emp)}
                            title="Ver historial detallado de cambios"
                            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                          >
                            <History className="w-4 h-4" />
                          </button>

                          {/* Edit Employee */}
                          {canEdit && (
                            <button
                              onClick={() => handleOpenEditModal(emp)}
                              title="Editar datos, DPI, puesto o salario"
                              className="p-1.5 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10 rounded-lg transition-colors"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                          )}

                          {/* Delete */}
                          {canDelete && (
                            <button
                              onClick={() => {
                                if (window.confirm(`¿Estás seguro de eliminar permanentemente a ${emp.name}? Esta acción quedará auditada.`)) {
                                  onDeleteEmployee(emp.id);
                                }
                              }}
                              title="Eliminar colaborador"
                              className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile Card Layout */}
          <div className="lg:hidden divide-y divide-white/5">
            {filteredEmployees.map(emp => {
              const comp = companyMap.get(emp.companyId);
              const isDischarged = emp.status === 'DE_BAJA';
              const quincenal = (emp.monthlySalary || 0) / 2;

              return (
                <div key={emp.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-bold text-white text-sm">
                        {emp.name}
                      </h3>
                      <p className="text-xs text-slate-400 font-medium">
                        {emp.position} · {comp?.name}
                      </p>
                      <div className="flex flex-wrap items-center gap-2 mt-1">
                        <span className="text-xs font-mono text-cyan-400">
                          DPI: {formatDPI(emp.dpi)}
                        </span>
                        {isAdmin && emp.pinCode && (
                          <span className="inline-flex items-center gap-1 font-mono text-[10px] bg-cyan-950/60 border border-cyan-400/40 text-cyan-300 px-1.5 py-0.5 rounded-md font-bold">
                            <KeyRound className="w-2.5 h-2.5 text-cyan-400" />
                            PIN: {emp.pinCode}
                          </span>
                        )}
                      </div>
                    </div>

                    {isDischarged ? (
                      <span className="text-[10px] font-semibold text-rose-300 bg-rose-500/15 border border-rose-500/30 px-2 py-0.5 rounded-full shrink-0">
                        De Baja
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold text-emerald-300 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded-full shrink-0">
                        Activo
                      </span>
                    )}
                  </div>

                  {canViewSalaries ? (
                    <div className="grid grid-cols-2 gap-2 p-2.5 bg-black/40 border border-white/5 rounded-xl text-xs">
                      <div>
                        <span className="text-slate-400 text-[10px] uppercase block">Salario Mensual</span>
                        <span className="font-bold text-white tabular-nums">
                          {formatCurrencyGTQ(emp.monthlySalary)}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[10px] uppercase block">Quincena Aprox</span>
                        <span className="font-bold text-cyan-300 tabular-nums">
                          {formatCurrencyGTQ(quincenal)}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="p-2.5 bg-black/40 border border-white/5 rounded-xl text-xs flex items-center justify-between text-slate-400">
                      <span className="text-[11px] flex items-center gap-1.5">
                        <Lock className="w-3.5 h-3.5 text-cyan-400" />
                        Salario y retenciones confidenciales
                      </span>
                      <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/40">
                        {currentUser.role === 'GUARD' ? 'Rol Guardia' : 'Restringido'}
                      </span>
                    </div>
                  )}

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/5">
                    {/* Botones de Comunicación Directa WhatsApp y Llamada */}
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setViewingEmployee(emp)}
                        className="px-2.5 py-1 text-xs text-cyan-300 bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-400/30 rounded-lg font-semibold flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Ver Perfil</span>
                      </button>

                      {emp.phone && (
                        <a
                          href={getWhatsAppUrl(emp.phone, emp.name)!}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 rounded-lg"
                          title="WhatsApp"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                        </a>
                      )}

                      {emp.phone && (
                        <a
                          href={getPhoneCallUrl(emp.phone)!}
                          className="p-1.5 text-sky-400 bg-sky-500/15 border border-sky-500/30 rounded-lg"
                          title="Llamar"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setHistoryModalEmployee(emp)}
                        className="p-1.5 text-slate-400 hover:text-white bg-white/5 rounded-lg"
                        title="Historial de cambios"
                      >
                        <History className="w-3.5 h-3.5" />
                      </button>

                      {canEdit && (
                        <button
                          onClick={() => handleOpenEditModal(emp)}
                          className="px-2.5 py-1 text-xs text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg font-semibold flex items-center gap-1 shadow-[0_0_10px_rgba(6,182,212,0.3)]"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Editar</span>
                        </button>
                      )}

                      {canDelete && (
                        <button
                          onClick={() => {
                            if (window.confirm(`¿Eliminar permanentemente a ${emp.name}?`)) {
                              onDeleteEmployee(emp.id);
                            }
                          }}
                          className="p-1 text-rose-400 hover:bg-rose-500/10 rounded-lg"
                          title="Eliminar"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* Edit / Create Employee Modal in Liquid Glass */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="liquid-glass-elevated rounded-3xl max-w-xl w-full p-6 border border-white/15 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div>
                <h3 className="text-lg font-bold text-white">
                  {editingEmployee ? 'Editar Colaborador' : 'Registrar Nuevo Colaborador'}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Toda modificación quedará asentada en la auditoría del sistema con tu usuario actual.
                </p>
              </div>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
              {errorMessage && (
                <div className="p-3 bg-rose-500/15 text-rose-300 text-xs rounded-xl border border-rose-500/30 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Company selection */}
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Empresa Perteneciente <span className="text-rose-400">*</span>
                </label>
                <select
                  required
                  value={formData.companyId}
                  onChange={e => setFormData({ ...formData, companyId: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                >
                  <option value="" className="bg-slate-900 text-white">Selecciona una empresa...</option>
                  {companies.map(c => (
                    <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                      {c.name} (NIT: {c.nit})
                    </option>
                  ))}
                </select>
              </div>

              {/* Name & DPI */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Nombre Completo <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. Juan Carlos López Pérez"
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    DPI (CUI Guatemala - 13 dígitos) <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="2489 12345 0101"
                    value={formData.dpi}
                    onChange={e => setFormData({ ...formData, dpi: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs font-mono"
                  />
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    Ej: 2489 19283 0101
                  </span>
                </div>
              </div>

              {/* Position & Monthly Salary */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Puesto o Cargo <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. Analista Contable, Supervisor"
                    value={formData.position}
                    onChange={e => setFormData({ ...formData, position: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                  />
                </div>

                {canViewSalaries ? (
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-semibold text-slate-300">
                        Salario Mensual (GTQ - Q) <span className="text-rose-400">*</span>
                      </label>
                      {!canModifySalaries && (
                        <span className="text-[10px] text-amber-400 font-medium flex items-center gap-1">
                          <Lock className="w-3 h-3" /> Solo lectura
                        </span>
                      )}
                    </div>
                    <div className="relative">
                      <span className="absolute left-3.5 top-2.5 text-cyan-400 font-bold text-xs">
                        Q
                      </span>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        required
                        disabled={!canModifySalaries}
                        placeholder="8500.00"
                        value={formData.monthlySalary}
                        onChange={e => setFormData({ ...formData, monthlySalary: e.target.value })}
                        className="w-full pl-8 pr-3.5 py-2.5 rounded-xl liquid-glass-input text-xs font-semibold tabular-nums disabled:opacity-50"
                      />
                    </div>
                    {!canModifySalaries && (
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        Tu usuario invitado no tiene permisos para cambiar salarios.
                      </span>
                    )}
                  </div>
                ) : (
                  <div className="p-3 bg-black/40 rounded-xl border border-white/10 flex items-center gap-2 text-xs text-slate-400">
                    <Lock className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span>Los salarios y deducciones son confidenciales para tu perfil.</span>
                  </div>
                )}
              </div>

              {/* Configuración de Retención IGSS */}
              {canViewSalaries && (
                <div className="p-3 bg-black/40 rounded-2xl border border-white/10 flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="appliesIGSS"
                    checked={formData.appliesIGSS}
                    onChange={e => setFormData({ ...formData, appliesIGSS: e.target.checked })}
                    className="mt-0.5 w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400 cursor-pointer"
                  />
                  <label htmlFor="appliesIGSS" className="cursor-pointer text-xs">
                    <span className="font-bold text-white block">Calcular Retención Laboral IGSS (4.83%)</span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      {formData.appliesIGSS 
                        ? 'Se aplicará 4.83% de descuento en la planilla quincenal/mensual.' 
                        : 'Colaborador EXENTO de IGSS (servicios profesionales, facturación o exención legal). Descuento = Q0.00.'}
                    </span>
                  </label>
                </div>
              )}

              {/* Start Date & End Date (Baja) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Fecha de Inicio / Contratación
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.startDate}
                    onChange={e => setFormData({ ...formData, startDate: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-semibold text-slate-300">
                      Fecha de Baja (Opcional)
                    </label>
                    {formData.endDate && (
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, endDate: '' })}
                        className="text-[10px] text-cyan-400 hover:text-cyan-300"
                      >
                        Quitar baja (Reactivar)
                      </button>
                    )}
                  </div>
                  <input
                    type="date"
                    value={formData.endDate}
                    onChange={e => setFormData({ ...formData, endDate: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                  />
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {formData.endDate 
                      ? 'El colaborador se marcará automáticamente como DE BAJA.' 
                      : 'Dejar vacío si el colaborador sigue activo.'}
                  </span>
                </div>
              </div>

              {/* Optional Contact Phone & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Teléfono
                  </label>
                  <input
                    type="text"
                    placeholder="+502 5555-5555"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Correo Electrónico
                  </label>
                  <input
                    type="email"
                    placeholder="colaborador@empresa.gt"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                  />
                </div>
              </div>

              {/* BANCO DE PAGO O MEDIO EN EFECTIVO (GUATEMALA) */}
              <div className="p-3.5 bg-black/40 rounded-2xl border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-slate-200 flex items-center gap-1.5 text-xs">
                    <Building2 className="w-4 h-4 text-cyan-400" />
                    <span>Banco de Pago o Medio de Cobro (Guatemala):</span>
                    <span className="text-rose-400">*</span>
                  </label>
                  <span className="text-[10px] text-cyan-300 font-mono font-bold bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                    Planilla
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-300 mb-1">
                      Seleccionar Banco o Efectivo:
                    </label>
                    <select
                      value={formData.bankName}
                      onChange={e => {
                        const val = e.target.value;
                        if (val === 'ADD_NEW') {
                          setIsAddBankModalOpen(true);
                          return;
                        }
                        setFormData({
                          ...formData,
                          bankName: val,
                          paymentMethodPreference: val === 'En efectivo' ? 'EFECTIVO' : 'TRANSFERENCIA',
                        });
                      }}
                      className="w-full px-3 py-2.5 rounded-xl liquid-glass-input text-xs font-semibold text-cyan-200 bg-slate-900 border border-white/15"
                    >
                      {allBanks.map(bank => (
                        <option key={bank} value={bank} className="bg-slate-900 text-white">
                          {bank}
                        </option>
                      ))}
                      <option value="ADD_NEW" className="text-cyan-400 font-bold bg-slate-900">+ Agregar banco...</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-300 mb-1">
                      {formData.bankName === 'En efectivo' ? 'Medio de Cobro:' : 'No. Cuenta Bancaria (Opcional):'}
                    </label>
                    <input
                      type="text"
                      disabled={formData.bankName === 'En efectivo'}
                      placeholder={formData.bankName === 'En efectivo' ? 'Pago en efectivo' : 'Ej. 00-1234567-8'}
                      value={formData.bankName === 'En efectivo' ? 'Entrega en Efectivo' : formData.bankAccountNumber}
                      onChange={e => setFormData({ ...formData, bankAccountNumber: e.target.value })}
                      className="w-full px-3 py-2.5 rounded-xl liquid-glass-input text-xs font-mono disabled:opacity-50"
                    />
                  </div>
                </div>

                <p className="text-[10px] text-slate-400 leading-tight">
                  {formData.bankName === 'En efectivo' 
                    ? 'Este trabajador recibirá su pago quincenal directamente en efectivo contra firma de boleta.' 
                    : `Las transferencias y depósitos de quincena se acreditarán a través de ${formData.bankName}.`}
                </p>
              </div>

              {/* CÓDIGO PIN ÚNICO (EDITABLE SOLO POR ADMINISTRADOR PRINCIPAL) */}
              <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Código PIN Único de Acceso a Garita</span>
                    {isAdmin && <span className="text-rose-400">*</span>}
                  </label>
                  {isAdmin ? (
                    <button
                      type="button"
                      onClick={generateRandomPin}
                      className="text-[10px] text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 bg-cyan-500/10 hover:bg-cyan-500/20 px-2 py-0.5 rounded-lg border border-cyan-500/20"
                    >
                      <Sparkles className="w-3 h-3 text-cyan-400" />
                      <span>Generar PIN Aleatorio</span>
                    </button>
                  ) : (
                    <span className="text-[10px] text-amber-400 flex items-center gap-1 font-medium">
                      <Lock className="w-3 h-3" /> Solo configurable por Administrador
                    </span>
                  )}
                </div>

                <div className="relative">
                  <input
                    type="text"
                    required={isAdmin}
                    disabled={!isAdmin}
                    maxLength={8}
                    placeholder="Ej. 4421"
                    value={formData.pinCode}
                    onChange={e => setFormData({ ...formData, pinCode: e.target.value.replace(/\D/g, '') })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs font-mono font-bold tracking-widest text-cyan-300 disabled:opacity-60"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {isAdmin
                    ? 'Este PIN de 4-6 dígitos es requerido cuando el guardia inicia sesión (con Google o directo). Al ingresarlo, el sistema reconocerá a este colaborador y guardará sus entradas/salidas en su historial oficial.'
                    : 'Código PIN asignado por el Administrador General para el acceso a garita y control de asistencia.'}
                </p>
              </div>

              {/* Modal Buttons */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 rounded-xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] disabled:opacity-50"
                >
                  {isSubmitting ? 'Guardando...' : (editingEmployee ? 'Guardar Cambios' : 'Registrar Colaborador')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Individual Employee Audit History Modal in Liquid Glass */}
      {historyModalEmployee && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="liquid-glass-elevated rounded-3xl max-w-2xl w-full p-6 border border-white/15 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <History className="w-5 h-5 text-cyan-400" />
                  Historial de Cambios: {historyModalEmployee.name}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  DPI: {formatDPI(historyModalEmployee.dpi)} · Puesto: {historyModalEmployee.position}
                </p>
              </div>
              <button
                onClick={() => setHistoryModalEmployee(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 max-h-96 overflow-y-auto space-y-3">
              {(() => {
                const empLogs = auditLogs.filter(
                  l => l.entityId === historyModalEmployee.id || (l.summary && l.summary.includes(historyModalEmployee.name))
                );

                if (empLogs.length === 0) {
                  return (
                    <div className="text-center py-8 text-xs text-slate-400">
                      No se han registrado modificaciones adicionales para este colaborador desde su registro inicial.
                    </div>
                  );
                }

                return empLogs.map(log => (
                  <div key={log.id} className="p-3.5 bg-black/40 rounded-2xl border border-white/10 text-xs">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="font-semibold text-white block">
                          {log.summary}
                        </span>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                          <span>Usuario: <strong className="text-cyan-300">{log.userName}</strong> ({log.userRole})</span>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">{formatDateTime(log.timestamp)}</span>
                        </div>
                      </div>
                      {log.isCritical && (
                        <span className="text-[10px] font-bold text-amber-300 bg-amber-500/20 border border-amber-500/30 px-2 py-0.5 rounded-full shrink-0">
                          Crítico
                        </span>
                      )}
                    </div>

                    {/* Detailed changes */}
                    {log.changes && log.changes.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-white/5 space-y-1 text-[11px]">
                        {log.changes.map((ch, idx) => {
                          const isFinancialField = ch.field === 'monthlySalary' || ch.field === 'appliesIGSS' || (ch.label && ch.label.toLowerCase().includes('salario'));
                          if (!canViewSalaries && isFinancialField) {
                            return (
                              <div key={idx} className="flex items-center justify-between text-slate-400 bg-white/5 p-1.5 rounded-xl border border-white/5">
                                <span className="font-medium text-slate-400">{ch.label || ch.field}:</span>
                                <span className="text-cyan-400 font-mono text-[10px] flex items-center gap-1">
                                  <Lock className="w-3 h-3" /> [Dato salarial confidencial]
                                </span>
                              </div>
                            );
                          }

                          return (
                            <div key={idx} className="flex items-center justify-between text-slate-300 bg-white/5 p-1.5 rounded-xl border border-white/5">
                              <span className="font-medium text-slate-300">{ch.label || ch.field}:</span>
                              <div className="flex items-center gap-2 font-mono">
                                <span className="text-rose-400 line-through">
                                  {ch.oldValue !== null && ch.oldValue !== undefined ? String(ch.oldValue) : '(Vacío)'}
                                </span>
                                <span>→</span>
                                <span className="text-emerald-400 font-bold">
                                  {ch.newValue !== null && ch.newValue !== undefined ? String(ch.newValue) : '(Vacío)'}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                ));
              })()}
            </div>

            <div className="mt-4 pt-3 border-t border-white/10 flex justify-end">
              <button
                onClick={() => setHistoryModalEmployee(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-300 bg-white/10 hover:bg-white/15 rounded-xl transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal para Visualizar Colaborador, Comunicación (WhatsApp / Llamar), PIN y Marcajes */}
      {viewingEmployee && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in custom-scrollbar">
          <div className="liquid-glass-elevated rounded-3xl max-w-4xl w-full p-5 sm:p-6 border border-white/15 my-auto max-h-[92vh] flex flex-col space-y-4 shadow-2xl">
            
            {/* Header del Perfil */}
            <div className="flex items-start justify-between pb-4 border-b border-white/10 shrink-0">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-400/20 to-blue-500/20 border border-cyan-400/40 text-cyan-300 flex items-center justify-center shadow-lg font-black text-lg">
                  {viewingEmployee.name.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black text-white tracking-tight">
                      {viewingEmployee.name}
                    </h3>
                    {viewingEmployee.status === 'DE_BAJA' ? (
                      <span className="text-[10px] font-bold text-rose-300 bg-rose-500/20 border border-rose-500/30 px-2 py-0.5 rounded-full">
                        De Baja
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-300 bg-emerald-500/20 border border-emerald-500/30 px-2 py-0.5 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.3)]">
                        Activo
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-300 font-medium mt-0.5">
                    {viewingEmployee.position} · {companyMap.get(viewingEmployee.companyId)?.name || 'Empresa'}
                  </p>
                  <p className="text-xs font-mono text-cyan-400 mt-0.5">
                    DPI: {formatDPI(viewingEmployee.dpi)}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setViewingEmployee(null)}
                className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex items-center gap-1 p-1 rounded-2xl bg-black/40 border border-white/10 shrink-0">
              {(['INFO', 'DESCUENTOS', 'RECIBOS', 'DOCUMENTOS', 'HISTORIAL'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setWorkerModalTab(tab)}
                  className={`flex-1 px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                    workerModalTab === tab
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {tab === 'INFO' ? 'Información' : tab === 'DESCUENTOS' ? 'Descuentos' : tab === 'RECIBOS' ? 'Recibos' : tab === 'DOCUMENTOS' ? 'Documentos' : 'Historial'}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="flex-1 overflow-y-auto custom-scrollbar pr-1.5 space-y-4 min-h-[300px]">
              {workerModalTab === 'INFO' && (
                <div className="space-y-4">
                  {/* SECCIÓN DE COMUNICACIÓN DIRECTA */}
                  <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                        <Phone className="w-4 h-4 text-emerald-400" />
                        Contacto & Comunicación Directa:
                      </span>
                      {viewingEmployee.phone && (
                        <span className="text-xs font-mono font-bold text-white bg-white/5 px-2.5 py-1 rounded-lg border border-white/10">
                          {viewingEmployee.phone}
                        </span>
                      )}
                    </div>
                    {viewingEmployee.phone ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <a
                          href={getWhatsAppUrl(viewingEmployee.phone, viewingEmployee.name)!}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-3 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-2.5 transition-all shadow-[0_0_15px_rgba(16,185,129,0.2)] active:scale-98"
                        >
                          <MessageCircle className="w-4 h-4 text-emerald-400" />
                          <span>Enviar Mensaje de WhatsApp</span>
                        </a>
                        <a
                          href={getPhoneCallUrl(viewingEmployee.phone)!}
                          className="p-3 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-bold text-xs flex items-center justify-center gap-2.5 transition-all shadow-[0_0_15px_rgba(6,182,212,0.2)] active:scale-98"
                        >
                          <PhoneCall className="w-4 h-4 text-cyan-400" />
                          <span>Llamar al Teléfono</span>
                        </a>
                      </div>
                    ) : (
                      <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-center text-xs text-slate-400 flex items-center justify-between">
                        <span>No tiene número telefónico registrado.</span>
                        {canEdit && (
                          <button
                            onClick={() => {
                              const target = viewingEmployee;
                              setViewingEmployee(null);
                              handleOpenEditModal(target);
                            }}
                            className="text-cyan-400 hover:text-cyan-300 font-semibold underline"
                          >
                            Agregar Teléfono
                          </button>
                        )}
                      </div>
                    )}
                    {viewingEmployee.email && (
                      <p className="text-[11px] text-slate-400">
                        Correo Electrónico: <span className="text-slate-200 font-mono">{viewingEmployee.email}</span>
                      </p>
                    )}
                  </div>
                  {/* SECCIÓN DEL CÓDIGO PIN ÚNICO DE GUARDIA */}
                  <div className="p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/40 space-y-3 shadow-[0_0_20px_rgba(6,182,212,0.15)]">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <KeyRound className="w-4 h-4 text-cyan-400" />
                        <span className="text-xs font-bold uppercase tracking-wider text-cyan-200">
                          Código PIN Único de Acceso a Garita
                        </span>
                      </div>
                      {isAdmin && (
                        <span className="text-[10px] font-mono text-cyan-300 bg-cyan-500/20 px-2 py-0.5 rounded border border-cyan-400/30">
                          Solo editable por Administrador
                        </span>
                      )}
                    </div>
                    {isAdmin ? (
                      <div className="flex items-center justify-between bg-black/60 p-3.5 rounded-xl border border-white/10">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">
                            PIN Asignado al Colaborador:
                          </span>
                          <span className="text-2xl font-black font-mono tracking-widest text-cyan-300">
                            {viewingEmployee.pinCode || 'Sin PIN'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          {viewingEmployee.pinCode && (
                            <button
                              type="button"
                              onClick={() => handleCopyPin(viewingEmployee.pinCode)}
                              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
                            >
                              {copiedPin ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-300" />}
                              <span>{copiedPin ? '¡Copiado!' : 'Copiar PIN'}</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              const target = viewingEmployee;
                              setViewingEmployee(null);
                              handleOpenEditModal(target);
                            }}
                            className="px-3 py-2 rounded-xl bg-cyan-400 text-slate-950 text-xs font-bold hover:bg-cyan-300 transition-colors"
                          >
                            Editar PIN
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 p-3 bg-black/40 rounded-xl border border-white/5 text-xs text-slate-400">
                        <Lock className="w-4 h-4 text-slate-500 shrink-0" />
                        <span>Credenciales confidenciales.</span>
                      </div>
                    )}
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      Este PIN vincula al colaborador cuando inicia sesión.
                    </p>
                  </div>

              {workerModalTab === 'HISTORIAL' && (
                <div className="space-y-4 p-4 rounded-2xl bg-black/40 border border-white/10">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-rose-400" />
                    Historial de Entradas, Salidas & Ubicación:
                  </span>
                  <div className="max-h-96 overflow-y-auto space-y-2 pr-1">
                    {(() => {
                      const empCheckins = guardCheckins.filter(c => 
                        c.employeeId === viewingEmployee.id || 
                        c.guardName === viewingEmployee.name ||
                        (viewingEmployee.pinCode && c.guardPinCode === viewingEmployee.pinCode)
                      );
                      if (empCheckins.length === 0) return <p className="text-xs text-slate-500 italic p-4 text-center">No hay registros de marcaje para este colaborador.</p>;
                      return empCheckins.map(chk => (
                        <div key={chk.id} className="p-3 bg-white/5 rounded-xl border border-white/10 flex items-center justify-between gap-3 text-xs">
                          <div className="flex items-center gap-2.5">
                            <span className={`px-2 py-0.5 rounded-lg font-black text-[10px] ${chk.type === 'ENTRADA' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : chk.type === 'SALIDA' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'}`}>
                              {chk.type === 'REPORTE_UBICACION' ? 'UBICACIÓN' : chk.type}
                            </span>
                            <div>
                              <p className="font-bold text-white">{chk.checkpointName}</p>
                              <p className="text-[10px] text-slate-400">{new Date(chk.timestamp).toLocaleString()}</p>
                            </div>
                          </div>
                          {chk.googleMapsUrl && (
                            <a href={chk.googleMapsUrl} target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:text-cyan-300 text-[10px] font-bold">Ver Mapa</a>
                          )}
                        </div>
                      ));
                    })()}
                  </div>
                </div>
              )}
              {/* SECCIÓN DE VISUALIZACIÓN DE DOCUMENTOS (Solo lectura para todos) */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-purple-400" />
                  Documentación del Colaborador:
                </span>
                {viewingEmployee.documents && (viewingEmployee.documents.personalInfo || viewingEmployee.documents.resignationForm || viewingEmployee.documents.fingerprints || viewingEmployee.documents.contract || (viewingEmployee.documents.others && viewingEmployee.documents.others.length > 0)) ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {viewingEmployee.documents.personalInfo && <a href={viewingEmployee.documents.personalInfo} download="Ficha_Personal.pdf" className="p-2 rounded-lg bg-white/5 text-xs text-slate-300 hover:text-white hover:bg-white/10 border border-white/10">Ficha Personal</a>}
                    {viewingEmployee.documents.resignationForm && <a href={viewingEmployee.documents.resignationForm} download="Formulario_Baja.pdf" className="p-2 rounded-lg bg-white/5 text-xs text-slate-300 hover:text-white hover:bg-white/10 border border-white/10">Formulario de Baja</a>}
                    {viewingEmployee.documents.fingerprints && <a href={viewingEmployee.documents.fingerprints} download="Huellas.pdf" className="p-2 rounded-lg bg-white/5 text-xs text-slate-300 hover:text-white hover:bg-white/10 border border-white/10">Huellas</a>}
                    {viewingEmployee.documents.contract && <a href={viewingEmployee.documents.contract} download="Contrato.pdf" className="p-2 rounded-lg bg-white/5 text-xs text-slate-300 hover:text-white hover:bg-white/10 border border-white/10">Contrato</a>}
                    {viewingEmployee.documents.others?.map((doc, idx) => (
                      <a key={idx} href={doc.url} download={doc.name} className="p-2 rounded-lg bg-white/5 text-xs text-slate-300 hover:text-white hover:bg-white/10 border border-white/10">{doc.name}</a>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic">No hay documentos registrados para este colaborador.</p>
                )}
              </div>
                </div>
              )}

              {workerModalTab === 'DESCUENTOS' && (
                <GuardDiscountsAndPaymentsTab
                  viewingEmployee={viewingEmployee}
                  isAdmin={isAdmin}
                  canEdit={canEdit}
                  securityConfig={securityConfig}
                  payments={payments}
                  onAddDiscount={onAddDiscount}
                  onDeleteDiscount={onDeleteDiscount}
                  onUpdateDiscountStart={onUpdateDiscountStart}
                  onRecordPayment={onRecordPayment}
                  onOpenAddBankModal={() => setIsAddBankModalOpen(true)}
                />
              )}

              {workerModalTab === 'DOCUMENTOS' && (
                <DocumentsTab 
                  viewingEmployee={viewingEmployee}
                  isAdmin={isAdmin} 
                  onUpdateEmployee={(updated) => {
                    // Update employees list locally to reflect changes
                    const updatedEmployees = employees.map(e => e.id === updated.id ? updated : e);
                    // This assumes onSaveEmployee is available, or we might need a prop to update it.
                    // For now, I'll assume we can trigger a re-render by updating local state or props if needed.
                    // Actually, I need to pass a callback from EmployeesView parent.
                    // I'll update the parent's employees state if possible.
                    // Assuming onSaveEmployee exists and can be used to update.
                    onSaveEmployee(updated, true);
                  }} 
                />
              )}

              {workerModalTab === 'RECIBOS' && (
                <div className="space-y-4">
                  {/* Barra de Filtro y Exportación de Detalle a PDF */}
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-3.5 rounded-2xl bg-black/40 border border-white/10">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold uppercase tracking-wider text-white block">
                          Comprobantes & Recibos de Pago
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {new Date(2000, paymentMonth - 1).toLocaleString('es', { month: 'long' })} {paymentYear}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="flex items-center gap-1.5">
                        <select
                          className="bg-black/60 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white capitalize focus:outline-none focus:border-cyan-500/50"
                          value={paymentMonth}
                          onChange={(e) => setPaymentMonth(parseInt(e.target.value))}
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(m => (
                            <option key={m} value={m} className="bg-slate-900 text-white">
                              {new Date(2000, m - 1).toLocaleString('es', { month: 'long' })}
                            </option>
                          ))}
                        </select>
                        <input
                          type="number"
                          className="bg-black/60 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white w-20 font-mono focus:outline-none focus:border-cyan-500/50"
                          value={paymentYear}
                          onChange={(e) => setPaymentYear(parseInt(e.target.value))}
                        />
                      </div>

                      {/* Botón Principal: Exportar Recibos del Mes UNO POR UNO en Hoja Carta */}
                      <button
                        onClick={handleExportCollaboratorReceiptsOneByOne}
                        disabled={isExportingStatement}
                        className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 disabled:opacity-50"
                        title="Descargar todos los comprobantes de este colaborador uno por uno (cada recibo en su propia hoja carta)"
                      >
                        {isExportingStatement ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            <span>Generando...</span>
                          </>
                        ) : (
                          <>
                            <FileDown className="w-3.5 h-3.5" />
                            <span>Descargar Recibos (1 x Hoja)</span>
                          </>
                        )}
                      </button>

                      {/* Botón: Exportar Detalle Consolidado a PDF */}
                      <button
                        onClick={handleExportStatement}
                        disabled={isExportingStatement}
                        className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
                        title="Exportar y descargar estado de cuenta consolidado en PDF tamaño Carta"
                      >
                        <FileText className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Estado Consolidado</span>
                      </button>

                      {/* Botón: Opción Compacta (2 por Hoja) */}
                      <button
                        onClick={() => handleExportQuincenaReceipts('ALL')}
                        disabled={isExportingStatement}
                        className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-medium flex items-center gap-1 transition-all active:scale-95 disabled:opacity-50"
                        title="Opción de ahorro: unificar 2 recibos por cada hoja tamaño carta"
                      >
                        <span>2 x Hoja</span>
                      </button>
                    </div>
                  </div>

                  {/* Mensaje de Confirmación de Exportación Exitosa */}
                  {statementSuccessMsg && (
                    <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{statementSuccessMsg}</span>
                    </div>
                  )}

                  {/* Resumen del Período */}
                  {(() => {
                    const filtered = receipts.filter(r => r.employeeId === viewingEmployee.id && r.month === paymentMonth && r.year === paymentYear);
                    const totalMonth = filtered.reduce((sum, r) => sum + r.amount, 0);

                    return (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Liquidado:</span>
                            <span className="text-base font-black font-mono text-cyan-300">Q{totalMonth.toFixed(2)}</span>
                          </div>
                          <DollarSign className="w-4 h-4 text-cyan-400 opacity-60" />
                        </div>
                        <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">Recibos Emitidos:</span>
                            <span className="text-base font-black font-mono text-white">{filtered.length}</span>
                          </div>
                          <FileText className="w-4 h-4 text-emerald-400 opacity-60" />
                        </div>
                        <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">Salario Base:</span>
                            <span className="text-base font-black font-mono text-white">Q{(viewingEmployee.monthlySalary || 0).toFixed(2)}</span>
                          </div>
                          <CreditCard className="w-4 h-4 text-amber-400 opacity-60" />
                        </div>
                      </div>
                    );
                  })()}

                  {receipts.filter(r => r.employeeId === viewingEmployee.id && r.month === paymentMonth && r.year === paymentYear).length === 0 ? (
                    <div className="text-center py-10 px-4 bg-white/5 rounded-2xl border border-white/5 space-y-2">
                      <FileText className="w-8 h-8 text-slate-500 mx-auto" />
                      <p className="text-xs text-slate-300 font-semibold">
                        No hay recibos generados para {new Date(2000, paymentMonth - 1).toLocaleString('es', { month: 'long' })} {paymentYear}.
                      </p>
                      <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                        Al liquidar una quincena o registrar pagos en la pestaña de Descuentos, podrás generar y descargar comprobantes aquí.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2.5 max-h-80 overflow-y-auto custom-scrollbar pr-1">
                      {receipts.filter(r => r.employeeId === viewingEmployee.id && r.month === paymentMonth && r.year === paymentYear).map(receipt => {
                        const isDownloadingThis = exportingReceiptId === receipt.id;

                        return (
                          <div key={receipt.id} className="p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition-all">
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-black text-cyan-300 text-sm">Q{receipt.amount.toFixed(2)}</span>
                                <span className="font-bold text-white">{receipt.concept}</span>
                                <span className="text-[10px] font-mono text-slate-400 bg-white/10 px-1.5 py-0.5 rounded">
                                  #{receipt.id.slice(0, 8).toUpperCase()}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-400">
                                Fecha: {String(receipt.day).padStart(2, '0')}/{String(receipt.month).padStart(2, '0')}/{receipt.year} · Método: {receipt.paymentMethod || 'TRANSFERENCIA'} {receipt.referenceNumber ? `(Ref: ${receipt.referenceNumber})` : ''}
                              </p>
                              {receipt.observations && (
                                <p className="text-[11px] text-slate-300 italic">
                                  Nota: "{receipt.observations}"
                                </p>
                              )}
                            </div>
                            <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                              <button 
                                onClick={() => setSelectedReceiptForView(receipt)}
                                className="px-2.5 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 font-semibold flex items-center gap-1 transition-colors"
                                title="Visualizar Comprobante Completo"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>Ver</span>
                              </button>
                              <button 
                                onClick={() => handleDownloadSingleReceipt(receipt)}
                                disabled={isDownloadingThis}
                                className="px-2.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 font-semibold flex items-center gap-1 transition-colors disabled:opacity-50"
                                title="Descargar comprobante en Hoja Tamaño Carta (1 por Hoja)"
                              >
                                {isDownloadingThis ? (
                                  <>
                                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                    <span>Generando...</span>
                                  </>
                                ) : (
                                  <>
                                    <Download className="w-3.5 h-3.5" />
                                    <span>Descargar PDF</span>
                                  </>
                                )}
                              </button>
                              <button 
                                onClick={() => {
                                  setSelectedReceiptForView(receipt);
                                  setTimeout(() => window.print(), 300);
                                }}
                                className="px-2.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 font-semibold flex items-center gap-1 transition-colors"
                                title="Imprimir Comprobante"
                              >
                                <Printer className="w-3.5 h-3.5" />
                                <span>Imprimir</span>
                              </button>
                              {onDeleteReceipt && (
                                <button 
                                  onClick={() => {
                                    if (window.confirm('¿Deseas eliminar este comprobante de pago emitido?')) {
                                      onDeleteReceipt(receipt.id);
                                    }
                                  }}
                                  className="p-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition-colors"
                                  title="Eliminar Comprobante"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 shrink-0">
              <span className="text-[11px] text-slate-400">
                Registrado por: <strong>{viewingEmployee.lastModifiedBy || 'Administrador'}</strong>
              </span>
              <div className="flex items-center gap-2">
                {canDelete && (
                  <button
                    onClick={async () => {
                      if (window.confirm(`¿Estás seguro de eliminar a ${viewingEmployee.name}? Esta acción eliminará su registro permanentemente.`)) {
                        const empId = viewingEmployee.id;
                        setViewingEmployee(null);
                        try {
                          await onDeleteEmployee(empId);
                        } catch (err: any) {
                          alert(err.message || 'Error al eliminar trabajador');
                        }
                      }
                    }}
                    className="px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 transition-all"
                    title="Eliminar registro del trabajador"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Eliminar Trabajador</span>
                  </button>
                )}
                <button
                  onClick={() => setViewingEmployee(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 rounded-xl transition-all shadow-md"
                >
                  Cerrar Perfil
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Modal para Visualizar e Imprimir Comprobante Oficial de Pago */}
      {selectedReceiptForView && (
        <PaymentReceiptModal
          receipt={selectedReceiptForView}
          onClose={() => setSelectedReceiptForView(null)}
          companyName={viewingEmployee ? companyMap.get(viewingEmployee.companyId)?.name : undefined}
          companyNit={viewingEmployee ? companyMap.get(viewingEmployee.companyId)?.nit : undefined}
        />
      )}

      {/* Modal para Agregar Banco */}
      {isAddBankModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="liquid-glass w-full max-w-sm p-6 rounded-3xl border border-white/10 shadow-2xl">
            <h2 className="text-lg font-bold text-white mb-4">Agregar Nuevo Banco</h2>
            <input
              type="text"
              value={newBankName}
              onChange={(e) => setNewBankName(e.target.value)}
              placeholder="Nombre del banco"
              className="w-full px-4 py-3 mb-4 rounded-xl liquid-glass-input text-sm text-white placeholder:text-slate-500"
            />
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setIsAddBankModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={async () => {
                  if (onAddBank) {
                    await onAddBank(newBankName);
                    setNewBankName('');
                    setIsAddBankModalOpen(false);
                  }
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 rounded-xl hover:bg-cyan-300 transition-all"
              >
                Guardar Banco
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Completo: Histórico de Recibos Emitidos */}
      {isReceiptsHistoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in custom-scrollbar">
          <div className="liquid-glass-elevated w-full max-w-4xl p-5 sm:p-7 rounded-3xl border border-white/20 shadow-2xl relative my-auto space-y-5">
            {/* Cabecera del Modal */}
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/40">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                    Histórico de Recibos y Comprobantes Emitidos
                  </h2>
                  <p className="text-xs text-slate-400">
                    Control general de liquidaciones salariales · Elige entre 1ra Quincena o 2da Quincena para exportar
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsReceiptsHistoryModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mensaje de Éxito */}
            {historySuccessMsg && (
              <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{historySuccessMsg}</span>
              </div>
            )}

            {/* Filtros del Histórico */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                
                {/* Selector Quincena */}
                <div className="sm:col-span-5 flex items-center bg-black/50 p-1 rounded-xl border border-white/10">
                  <button
                    onClick={() => setHistoryQuincenaFilter('ALL')}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                      historyQuincenaFilter === 'ALL'
                        ? 'bg-white/15 text-white font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Todas las Qnas
                  </button>
                  <button
                    onClick={() => setHistoryQuincenaFilter('1RA_QUINCENA')}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                      historyQuincenaFilter === '1RA_QUINCENA'
                        ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                        : 'text-cyan-400 hover:text-white'
                    }`}
                  >
                    1ra Quincena
                  </button>
                  <button
                    onClick={() => setHistoryQuincenaFilter('2DA_QUINCENA')}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                      historyQuincenaFilter === '2DA_QUINCENA'
                        ? 'bg-blue-500 text-white font-bold shadow-sm'
                        : 'text-blue-400 hover:text-white'
                    }`}
                  >
                    2da Quincena
                  </button>
                </div>

                {/* Mes */}
                <div className="sm:col-span-4">
                  <select
                    value={historyMonthFilter}
                    onChange={(e) => setHistoryMonthFilter(e.target.value)}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white capitalize focus:outline-none focus:border-cyan-500/50"
                  >
                    <option value="ALL" className="bg-slate-900 text-white">Todo el año</option>
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(m => (
                      <option key={m} value={m} className="bg-slate-900 text-white">
                        {new Date(2000, m - 1).toLocaleString('es', { month: 'long' })}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Año */}
                <div className="sm:col-span-3">
                  <input
                    type="number"
                    value={historyYearFilter}
                    onChange={(e) => setHistoryYearFilter(parseInt(e.target.value) || new Date().getFullYear())}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500/50"
                    placeholder="Año"
                  />
                </div>

              </div>

              {/* Búsqueda por texto */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={historySearchTerm}
                  onChange={(e) => setHistorySearchTerm(e.target.value)}
                  placeholder="Filtrar por nombre de colaborador, DPI o boleta de pago..."
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl liquid-glass-input"
                />
              </div>
            </div>

            {/* Resumen Métrico del Histórico */}
            {(() => {
              const histReceipts = getFilteredHistoryReceipts();
              const histTotal = histReceipts.reduce((sum, r) => sum + r.amount, 0);
              const histGuards = new Set(histReceipts.map(r => r.employeeId)).size;

              return (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-cyan-300 block">Total Liquidado:</span>
                      <span className="text-xl font-black font-mono text-cyan-200">Q{histTotal.toFixed(2)}</span>
                    </div>
                    <DollarSign className="w-6 h-6 text-cyan-400 opacity-60" />
                  </div>
                  <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-emerald-300 block">Comprobantes:</span>
                      <span className="text-xl font-black font-mono text-emerald-200">{histReceipts.length}</span>
                    </div>
                    <FileText className="w-6 h-6 text-emerald-400 opacity-60" />
                  </div>
                  <div className="p-3.5 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-purple-300 block">Colaboradores:</span>
                      <span className="text-xl font-black font-mono text-purple-200">{histGuards}</span>
                    </div>
                    <Users className="w-6 h-6 text-purple-400 opacity-60" />
                  </div>
                </div>
              );
            })()}

            {/* Barra de Acciones de Exportación */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-white/10">
              <span className="text-xs text-slate-400">
                Mostrando <strong className="text-white">{getFilteredHistoryReceipts().length}</strong> recibos en el período
              </span>

              <div className="flex flex-wrap items-center gap-2">
                {/* Botón: Descargar Histórico PDF */}
                <button
                  onClick={handleExportHistoryReportPDF}
                  disabled={isExportingHistory || getFilteredHistoryReceipts().length === 0}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 disabled:opacity-50"
                  title="Descargar Reporte Histórico en Hoja Tamaño Carta"
                >
                  {isExportingHistory ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Generando PDF...</span>
                    </>
                  ) : (
                    <>
                      <FileDown className="w-3.5 h-3.5 text-slate-950" />
                      <span>Descargar Histórico (PDF)</span>
                    </>
                  )}
                </button>

                {/* Botón: Descargar Comprobantes en Lote (1 por Hoja Carta) */}
                <button
                  onClick={handleExportHistoryVouchersOneByOne}
                  disabled={isExportingHistory || getFilteredHistoryReceipts().length === 0}
                  className="px-3 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
                  title="Descargar todos los comprobantes uno por uno (cada recibo en su propia hoja carta)"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Comprobantes (1 x Hoja)</span>
                </button>

                {/* Botón: Exportar a Excel */}
                <button
                  onClick={handleExportHistoryExcel}
                  disabled={getFilteredHistoryReceipts().length === 0}
                  className="px-3 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
                  title="Exportar a planilla Excel (.xlsx)"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Excel</span>
                </button>
              </div>
            </div>

            {/* Tabla de Recibos */}
            <div className="max-h-80 overflow-y-auto custom-scrollbar rounded-2xl border border-white/10">
              {getFilteredHistoryReceipts().length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400 space-y-1">
                  <FileText className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <p className="font-semibold text-slate-300">No se encontraron recibos con los filtros actuales.</p>
                  <p className="text-[11px] text-slate-500">Prueba cambiando la quincena o el mes seleccionado.</p>
                </div>
              ) : (
                <table className="w-full text-left text-xs">
                  <thead className="bg-black/60 text-slate-400 text-[10px] uppercase font-bold sticky top-0 border-b border-white/10 z-10 backdrop-blur-md">
                    <tr>
                      <th className="py-2.5 px-3">No. Recibo</th>
                      <th className="py-2.5 px-3">Fecha</th>
                      <th className="py-2.5 px-3">Colaborador</th>
                      <th className="py-2.5 px-3">DPI</th>
                      <th className="py-2.5 px-3">Concepto / Quincena</th>
                      <th className="py-2.5 px-3">Método / Ref</th>
                      <th className="py-2.5 px-3 text-right">Monto</th>
                      <th className="py-2.5 px-3 text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 bg-black/20">
                    {getFilteredHistoryReceipts().map(receipt => (
                      <tr key={receipt.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-2.5 px-3 font-mono font-bold text-cyan-300">
                          #{receipt.id.slice(0, 8).toUpperCase()}
                        </td>
                        <td className="py-2.5 px-3 text-slate-400">
                          {String(receipt.day).padStart(2, '0')}/{String(receipt.month).padStart(2, '0')}/{receipt.year}
                        </td>
                        <td className="py-2.5 px-3 font-bold text-white">
                          {receipt.employeeName}
                        </td>
                        <td className="py-2.5 px-3 text-slate-400 font-mono">
                          {receipt.employeeDpi ? formatDPI(receipt.employeeDpi) : '—'}
                        </td>
                        <td className="py-2.5 px-3 text-slate-300 max-w-xs truncate" title={receipt.concept}>
                          {receipt.concept}
                        </td>
                        <td className="py-2.5 px-3 text-slate-400">
                          <span className="block">{receipt.paymentMethod || 'TRANSF'}</span>
                          {receipt.referenceNumber && (
                            <span className="text-[10px] font-mono text-cyan-400">Ref: {receipt.referenceNumber}</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-black text-cyan-300">
                          Q{receipt.amount.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => setSelectedReceiptForView(receipt)}
                              className="px-2 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 font-semibold text-[11px] flex items-center gap-1"
                              title="Ver Comprobante"
                            >
                              <Eye className="w-3 h-3" />
                              <span>Ver</span>
                            </button>
                            <button
                              onClick={() => handleDownloadSingleReceipt(receipt)}
                              className="p-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300"
                              title="Descargar Comprobante en Hoja Carta (1 por Hoja)"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            {/* Footer */}
            <div className="flex justify-end pt-2 border-t border-white/10">
              <button
                onClick={() => setIsReceiptsHistoryModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-300 bg-white/10 hover:bg-white/15 rounded-xl transition-colors"
              >
                Cerrar Histórico
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
