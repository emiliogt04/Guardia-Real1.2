import React, { useState } from 'react';
import { 
  DollarSign, 
  CreditCard, 
  Building, 
  CheckCircle2, 
  Send, 
  Edit3, 
  FileText, 
  Search, 
  Check, 
  AlertCircle,
  Building2,
  Calendar,
  Lock
} from 'lucide-react';
import { AppUser, Company, Employee, GuardPayment, GUATEMALA_BANKS } from '../types';
import { formatCurrencyGTQ, formatDate } from '../utils/formatters';

interface PaymentsViewProps {
  employees: Employee[];
  companies: Company[];
  payments: GuardPayment[];
  currentUser: AppUser;
  onRecordPayment: (paymentData: {
    employeeId: string;
    period: '1RA_QUINCENA' | '2DA_QUINCENA' | 'MENSUAL' | 'MES_COMPLETO';
    year: number;
    month: number;
    calculatedAmount: number;
    paidAmount: number;
    paymentMethod: 'TRANSFERENCIA' | 'CHEQUE' | 'EFECTIVO';
    bankName: string;
    referenceNumber?: string;
    notes?: string;
    notifyGuard: boolean;
  }) => Promise<void>;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  employees,
  companies,
  payments,
  currentUser,
  onRecordPayment,
}) => {
  const isAdmin = currentUser.role === 'ADMIN';
  const isGuard = currentUser.role === 'GUARD';

  const [selectedPeriod, setSelectedPeriod] = useState<'1RA_QUINCENA' | '2DA_QUINCENA' | 'MENSUAL' | 'MES_COMPLETO'>('1RA_QUINCENA');
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [searchTerm, setSearchTerm] = useState('');

  // Payment Modal State
  const [activeModalEmployee, setActiveModalEmployee] = useState<Employee | null>(null);
  const [paymentForm, setPaymentForm] = useState({
    paidAmount: '',
    paymentMethod: 'TRANSFERENCIA' as 'TRANSFERENCIA' | 'CHEQUE' | 'EFECTIVO',
    bankName: GUATEMALA_BANKS[0] as string,
    referenceNumber: '',
    notes: '',
    notifyGuard: true,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const companyMap = new Map<string, Company>();
  companies.forEach(c => companyMap.set(c.id, c));

  // If guard, only show their own employee record / payments
  const targetEmployees = employees.filter(emp => {
    if (isGuard) {
      return emp.id === currentUser.employeeId || emp.email?.toLowerCase() === currentUser.email.toLowerCase() || emp.pinCode === currentUser.pinCode;
    }
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return emp.name.toLowerCase().includes(q) || emp.position.toLowerCase().includes(q) || (emp.pinCode && emp.pinCode.includes(q));
    }
    return true;
  });

  const handleOpenPaymentModal = (emp: Employee) => {
    setActiveModalEmployee(emp);
    const monthly = emp.monthlySalary || 0;
    const calc = selectedPeriod === 'MES_COMPLETO' ? monthly : (monthly / 2);
    
    // subtract discounts if any
    const totalDiscounts = (emp.discounts || []).reduce((sum, d) => sum + d.amount, 0);
    // IGSS if applies
    const igss = emp.appliesIGSS !== false ? (calc * 0.0483) : 0;
    const net = Math.max(0, Math.round((calc + 125 - igss - totalDiscounts) * 100) / 100);

    setPaymentForm({
      paidAmount: String(net),
      paymentMethod: emp.paymentMethodPreference || 'TRANSFERENCIA',
      bankName: emp.bankName || GUATEMALA_BANKS[0],
      referenceNumber: '',
      notes: `Pago de ${selectedPeriod === '1RA_QUINCENA' ? '1ra Quincena' : '2da Quincena'}`,
      notifyGuard: true,
    });
    setSuccessMessage(null);
  };

  const handlePaySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeModalEmployee) return;

    const monthly = activeModalEmployee.monthlySalary || 0;
    const calc = selectedPeriod === 'MES_COMPLETO' ? monthly : (monthly / 2);
    const totalDiscounts = (activeModalEmployee.discounts || []).reduce((sum, d) => sum + d.amount, 0);
    const igss = activeModalEmployee.appliesIGSS !== false ? (calc * 0.0483) : 0;
    const calculatedAmount = Math.max(0, Math.round((calc + 125 - igss - totalDiscounts) * 100) / 100);

    try {
      setIsSubmitting(true);
      await onRecordPayment({
        employeeId: activeModalEmployee.id,
        period: selectedPeriod,
        year: selectedYear,
        month: selectedMonth,
        calculatedAmount,
        paidAmount: Number(paymentForm.paidAmount) || calculatedAmount,
        paymentMethod: paymentForm.paymentMethod,
        bankName: paymentForm.bankName,
        referenceNumber: paymentForm.referenceNumber.trim(),
        notes: paymentForm.notes.trim(),
        notifyGuard: paymentForm.notifyGuard,
      });

      setSuccessMessage('¡Pago registrado con éxito y notificación enviada al guardia!');
      setTimeout(() => {
        setActiveModalEmployee(null);
        setSuccessMessage(null);
      }, 1500);
    } catch (err: any) {
      alert(err.message || 'Error al registrar el pago.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-black tracking-tight flex items-center gap-2.5">
            <DollarSign className="w-6 h-6 text-emerald-600" />
            <span>Módulo de Pagos & Notificación de Quincenas (0Pagos)</span>
          </h1>
          <p className="text-sm text-slate-700 mt-0.5 font-medium">
            Registra y notifica el pago de la primera y segunda quincena a los guardias de seguridad mediante transferencia o cheque en bancos de Guatemala.
          </p>
        </div>

        {/* Period Selector */}
        <div className="flex items-center gap-2 bg-black/5 p-1.5 rounded-2xl border border-black/10 shrink-0">
          {(['1RA_QUINCENA', '2DA_QUINCENA', 'MES_COMPLETO'] as const).map(p => (
            <button
              key={p}
              onClick={() => setSelectedPeriod(p)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedPeriod === p
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md'
                  : 'text-slate-700 hover:text-black'
              }`}
            >
              {p === '1RA_QUINCENA' ? '1ra Quincena' : (p === '2DA_QUINCENA' ? '2da Quincena' : 'Mes Completo')}
            </button>
          ))}
        </div>
      </div>

      {/* Search & Filter */}
      {!isGuard && (
        <div className="liquid-glass p-4 rounded-2xl border border-black/10 flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Buscar guardia por nombre, puesto o PIN..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl liquid-glass-input text-xs font-medium text-black"
            />
          </div>
        </div>
      )}

      {/* Guard Payments List */}
      <div className="liquid-glass rounded-3xl overflow-hidden border border-black/15 shadow-xl">
        <div className="p-4 border-b border-black/10 flex items-center justify-between">
          <h3 className="font-black text-black text-xs uppercase tracking-wider">
            Listado de Guardias & Estado de Pagos ({targetEmployees.length})
          </h3>
          <span className="text-xs text-slate-700 font-semibold">
            {selectedPeriod === '1RA_QUINCENA' ? 'Primera Quincena' : 'Segunda Quincena'} · {selectedYear}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black/10 text-black text-[11px] font-black uppercase tracking-wider border-b border-black/15">
              <tr>
                <th className="py-3 px-4">Guardia de Seguridad</th>
                <th className="py-3 px-4">Empresa / Sucursal</th>
                <th className="py-3 px-4 text-right">Sueldo Base</th>
                <th className="py-3 px-4 text-right">Cálculo Período</th>
                <th className="py-3 px-4">Estado de Pago</th>
                <th className="py-3 px-4 text-center">Acciones / Notificar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/10">
              {targetEmployees.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-700">
                    No hay guardias de seguridad registrados en el sistema.
                  </td>
                </tr>
              ) : (
                targetEmployees.map(emp => {
                  const monthly = emp.monthlySalary || 0;
                  const calc = selectedPeriod === 'MES_COMPLETO' ? monthly : (monthly / 2);
                  const totalDiscounts = (emp.discounts || []).reduce((sum, d) => sum + d.amount, 0);
                  const igss = emp.appliesIGSS !== false ? (calc * 0.0483) : 0;
                  const netPay = Math.max(0, Math.round((calc + 125 - igss - totalDiscounts) * 100) / 100);

                  // Check if payment already recorded for this period/month/year
                  const existingPayment = payments.find(p => 
                    p.employeeId === emp.id && 
                    p.period === selectedPeriod && 
                    p.year === selectedYear && 
                    p.month === selectedMonth
                  );

                  return (
                    <tr key={emp.id} className="hover:bg-black/5 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-black">{emp.name}</div>
                        <div className="text-[10px] text-slate-700 font-mono">PIN: {emp.pinCode || 'N/A'} · {emp.position}</div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-800">
                        {companyMap.get(emp.companyId)?.name || 'Empresa Central'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-black">
                        {formatCurrencyGTQ(monthly)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-black text-cyan-700 text-sm">
                        {formatCurrencyGTQ(netPay)}
                      </td>
                      <td className="py-3.5 px-4">
                        {existingPayment ? (
                          <div className="space-y-0.5">
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-800 bg-emerald-500/20 px-2.5 py-0.5 rounded-full border border-emerald-500/40">
                              <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                              PAGADO ({existingPayment.paymentMethod})
                            </span>
                            <div className="text-[10px] text-slate-700 font-mono">
                              {existingPayment.bankName} {existingPayment.referenceNumber ? `(Ref: ${existingPayment.referenceNumber})` : ''}
                            </div>
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-500/20 px-2.5 py-0.5 rounded-full border border-amber-500/40">
                            Pendiente de Pago
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {isAdmin ? (
                          <button
                            onClick={() => handleOpenPaymentModal(emp)}
                            className="px-3 py-1.5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 shadow-md transition-all flex items-center justify-center gap-1.5 mx-auto"
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                            <span>{existingPayment ? 'Editar / Repagar' : 'Pagar & Notificar'}</span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-600">
                            {existingPayment ? 'Cancelado' : 'Pendiente'}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Processing Modal */}
      {activeModalEmployee && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in overflow-y-auto">
          <div className="liquid-glass-elevated rounded-3xl max-w-lg w-full p-6 border border-black/20 my-8 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-black/10">
              <div>
                <h3 className="text-base font-black text-black">
                  Registrar Pago & Notificar a Guardia
                </h3>
                <p className="text-xs text-slate-700 mt-0.5">
                  {activeModalEmployee.name} · {selectedPeriod === '1RA_QUINCENA' ? '1ra Quincena' : '2da Quincena'}
                </p>
              </div>
              <button
                onClick={() => setActiveModalEmployee(null)}
                className="text-slate-600 hover:text-black p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handlePaySubmit} className="space-y-4 text-xs">
              
              {successMessage && (
                <div className="p-3 bg-emerald-500/20 text-emerald-900 rounded-xl border border-emerald-500/40 font-bold flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>{successMessage}</span>
                </div>
              )}

              {/* Amount */}
              <div>
                <label className="block font-bold text-black mb-1">
                  Monto a Pagar (GTQ - Q):
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-600">Q</span>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={paymentForm.paidAmount}
                    onChange={e => setPaymentForm({ ...paymentForm, paidAmount: e.target.value })}
                    className="w-full pl-8 pr-4 py-2.5 rounded-xl liquid-glass-input font-mono font-black text-sm text-black"
                  />
                </div>
                <span className="text-[10px] text-slate-700 block mt-1">
                  Puedes pagar el monto calculado por el sistema o editarlo según corresponda.
                </span>
              </div>

              {/* Method: Transferencia o Cheque */}
              <div>
                <label className="block font-bold text-black mb-1">
                  Medio de Pago:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['TRANSFERENCIA', 'CHEQUE', 'EFECTIVO'] as const).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setPaymentForm({ 
                        ...paymentForm, 
                        paymentMethod: m,
                        bankName: m === 'EFECTIVO' ? 'En efectivo' : paymentForm.bankName 
                      })}
                      className={`py-2 px-2.5 rounded-xl font-bold text-xs border transition-all ${
                        paymentForm.paymentMethod === m
                          ? 'bg-cyan-600 text-white border-cyan-500 shadow-md'
                          : 'bg-black/5 text-slate-800 border-black/10 hover:bg-black/10'
                      }`}
                    >
                      {m === 'TRANSFERENCIA' ? 'Transferencia' : m === 'CHEQUE' ? 'Cheque' : 'En efectivo'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Bank Name from Guatemala Banks */}
              <div>
                <label className="block font-bold text-black mb-1">
                  Banco de Guatemala Disponible:
                </label>
                <select
                  value={paymentForm.bankName}
                  onChange={e => setPaymentForm({ ...paymentForm, bankName: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs font-semibold text-black"
                >
                  {GUATEMALA_BANKS.map(bank => (
                    <option key={bank} value={bank} className="bg-white text-black">
                      {bank}
                    </option>
                  ))}
                </select>
              </div>

              {/* Reference Number / Check Number */}
              <div>
                <label className="block font-bold text-black mb-1">
                  Número de Referencia / Boleta / Cheque:
                </label>
                <input
                  type="text"
                  placeholder="Ej. REF-981240 o CHQ-4412"
                  value={paymentForm.referenceNumber}
                  onChange={e => setPaymentForm({ ...paymentForm, referenceNumber: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs font-mono text-black"
                />
              </div>

              {/* Notes */}
              <div>
                <label className="block font-bold text-black mb-1">
                  Notas / Observaciones del Pago:
                </label>
                <input
                  type="text"
                  placeholder="Ej. Quincena abonada puntualmente"
                  value={paymentForm.notes}
                  onChange={e => setPaymentForm({ ...paymentForm, notes: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs text-black"
                />
              </div>

              {/* Notify Guard Checkbox */}
              <div className="p-3 bg-black/5 rounded-2xl border border-black/10 flex items-center gap-3">
                <input
                  type="checkbox"
                  id="notifyGuard"
                  checked={paymentForm.notifyGuard}
                  onChange={e => setPaymentForm({ ...paymentForm, notifyGuard: e.target.checked })}
                  className="w-4 h-4 rounded text-cyan-600 focus:ring-cyan-500 cursor-pointer"
                />
                <label htmlFor="notifyGuard" className="text-xs text-black font-bold cursor-pointer">
                  Notificar inmediatamente al guardia en su panel de la aplicación
                </label>
              </div>

              <div className="pt-3 border-t border-black/10 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModalEmployee(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-700 hover:text-black rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 text-xs font-black text-white bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 rounded-xl shadow-md disabled:opacity-50 flex items-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Procesando Pago...' : 'Confirmar Pago & Notificar'}</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
