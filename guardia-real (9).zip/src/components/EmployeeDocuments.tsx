import React, { useRef } from 'react';
import { Employee, Company } from '../types';

interface DocumentProps {
  employee: Employee;
  company?: Company;
}

const DocumentsContent = React.forwardRef<HTMLDivElement, DocumentProps>(({ employee, company }, ref) => (
  <div ref={ref} className="p-8 text-black bg-white" style={{ fontFamily: 'Arial, sans-serif' }}>
    {/* Formulario de Entrada */}
    <div className="mb-12">
      <h2 className="text-xl font-bold mb-4 text-center">SERVICIOS DE SEGURIDAD CORPORATIVA GUARDIA REAL, S.A.</h2>
      <h3 className="text-lg font-bold mb-6 text-center underline">FICHA DE INFORMACIÓN PERSONAL DE GUARDIAS</h3>
      <div className="grid grid-cols-2 gap-4 text-sm">
        <p><strong>Nombre:</strong> {employee.name}</p>
        <p><strong>Puesto:</strong> {employee.position}</p>
        <p><strong>Fecha de Alta:</strong> {employee.startDate}</p>
        <p><strong>DPI:</strong> {employee.dpi}</p>
        <p><strong>Residencia:</strong> ____________________</p>
        <p><strong>Teléfono:</strong> {employee.phone}</p>
      </div>
    </div>

    {/* Formato de Huellas */}
    <div className="mb-12">
      <h2 className="text-xl font-bold mb-4 text-center">EJERCITO DE GUATEMALA - INSTITUTO ADOLFO V</h2>
      <h3 className="text-lg font-bold mb-6 text-center underline">HUELLAS DACTILARES</h3>
      <p className="mb-4"><strong>Nombres y Apellidos:</strong> {employee.name}</p>
      <div className="space-y-4">
        <p>MANO IZQUIERDA: PULGAR | INDICE | MEDIO | ANULAR | MEÑIQUE</p>
        <p>MANO DERECHA: PULGAR | INDICE | MEDIO | ANULAR | MEÑIQUE</p>
      </div>
      <p className="mt-8">Quetzaltenango, ____ de ________________________ de 2026.</p>
      <p className="mt-4">Firma: ___________________________</p>
    </div>

    {/* Contrato (Placeholder) */}
    <div>
      <h3 className="text-lg font-bold mb-4 text-center underline">CONTRATO DE TRABAJO</h3>
      <p className="text-sm">Contenido del contrato de trabajo para {employee.name}...</p>
    </div>
  </div>
));

export const PrintEmployeeDocuments: React.FC<DocumentProps> = ({ employee, company }) => {
  const componentRef = useRef<HTMLDivElement>(null);
  
  const handlePrint = () => {
    const printContent = componentRef.current;
    if (printContent) {
      const originalContents = document.body.innerHTML;
      document.body.innerHTML = printContent.innerHTML;
      window.print();
      document.body.innerHTML = originalContents;
      window.location.reload(); // To restore React app state
    }
  };

  return (
    <>
      <button 
        onClick={handlePrint}
        className="px-3 py-1.5 rounded-xl bg-cyan-600 text-white text-xs font-bold hover:bg-cyan-500"
      >
        Imprimir Documentos
      </button>
      <div className="hidden">
        <DocumentsContent ref={componentRef} employee={employee} company={company} />
      </div>
    </>
  );
};
