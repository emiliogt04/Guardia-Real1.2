import React, { useState } from 'react';
import { 
  Building2, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Phone, 
  MapPin, 
  Lock, 
  X,
  ArrowRight,
  ShieldAlert
} from 'lucide-react';
import { Company, Employee, AppUser } from '../types';
import { formatCurrencyGTQ } from '../utils/formatters';

interface CompaniesViewProps {
  companies: Company[];
  employees: Employee[];
  currentUser: AppUser;
  onSaveCompany: (companyData: Partial<Company>, isEdit: boolean) => Promise<void>;
  onDeleteCompany: (companyId: string) => Promise<void>;
  onSelectCompanyForEmployees: (companyId: string) => void;
}

export const CompaniesView: React.FC<CompaniesViewProps> = ({
  companies,
  employees,
  currentUser,
  onSaveCompany,
  onDeleteCompany,
  onSelectCompanyForEmployees,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Company | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    nit: '',
    industry: '',
    address: '',
    phone: '',
    email: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const canManageCompanies = currentUser.role === 'ADMIN' || currentUser.permissions.canManageCompanies;
  const canViewSalaries = currentUser.role === 'ADMIN' || (currentUser.role !== 'GUARD' && currentUser.permissions?.canViewSalaries !== false);
  const canViewEmployees = currentUser.role === 'ADMIN' || currentUser.permissions?.canViewEmployees !== false;

  const filteredCompanies = companies.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.nit.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.industry.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenAddModal = () => {
    setEditingCompany(null);
    setFormData({
      name: '',
      nit: '',
      industry: '',
      address: '',
      phone: '',
      email: '',
    });
    setErrorMsg('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (comp: Company) => {
    setEditingCompany(comp);
    setFormData({
      name: comp.name,
      nit: comp.nit,
      industry: comp.industry,
      address: comp.address,
      phone: comp.phone,
      email: comp.email || '',
    });
    setErrorMsg('');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.nit.trim()) {
      setErrorMsg('El nombre de la empresa y el NIT son requeridos.');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg('');
      await onSaveCompany(
        {
          ...(editingCompany ? { id: editingCompany.id } : {}),
          name: formData.name.trim(),
          nit: formData.nit.trim(),
          industry: formData.industry.trim() || 'Comercio General',
          address: formData.address.trim() || 'Guatemala',
          phone: formData.phone.trim(),
          email: formData.email.trim(),
        },
        !!editingCompany
      );
      setIsModalOpen(false);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al guardar la empresa.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Gestión de Empresas
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Empresas registradas, información fiscal (NIT) y vinculación de colaboradores.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {canManageCompanies ? (
            <button
              onClick={handleOpenAddModal}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 rounded-xl hover:from-cyan-300 hover:to-blue-300 transition-all shadow-[0_0_20px_rgba(6,182,212,0.35)] whitespace-nowrap"
            >
              <Plus className="w-4 h-4 text-slate-950" />
              <span>Registrar Empresa</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 px-3 py-1.5 liquid-glass text-slate-400 text-xs rounded-xl">
              <Lock className="w-3.5 h-3.5 text-slate-500" />
              <span>Modo Invitado (Solo lectura de empresas)</span>
            </div>
          )}
        </div>
      </div>

      {/* Search Bar */}
      <div className="liquid-glass p-3 rounded-2xl flex items-center gap-3 border border-white/10">
        <Search className="w-4 h-4 text-slate-400 shrink-0 ml-1.5" />
        <input
          type="text"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          placeholder="Buscar por nombre, NIT o giro empresarial..."
          className="w-full text-sm bg-transparent text-white placeholder:text-slate-500 focus:outline-none"
        />
        {searchTerm && (
          <button 
            onClick={() => setSearchTerm('')} 
            className="text-xs text-slate-400 hover:text-white px-2 py-1"
          >
            Limpiar
          </button>
        )}
      </div>

      {/* Company Cards Grid */}
      {filteredCompanies.length === 0 ? (
        <div className="liquid-glass rounded-2xl p-12 text-center border border-white/10">
          <Building2 className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-200">No se encontraron empresas</h3>
          <p className="text-sm text-slate-400 max-w-sm mx-auto mt-1">
            {searchTerm 
              ? 'Intenta modificando los términos de búsqueda.' 
              : 'Agrega tu primera empresa para comenzar a asignarle trabajadores.'}
          </p>
          {canManageCompanies && !searchTerm && (
            <button
              onClick={handleOpenAddModal}
              className="mt-4 px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] inline-flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Registrar Primera Empresa
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredCompanies.map(comp => {
            const compEmployees = employees.filter(e => e.companyId === comp.id);
            const activeEmps = compEmployees.filter(e => e.status === 'ACTIVO');
            const totalMonthly = activeEmps.reduce((sum, e) => sum + e.monthlySalary, 0);
            const quincenalEst = totalMonthly / 2;

            return (
              <div 
                key={comp.id}
                className="liquid-glass-interactive rounded-2xl p-5 flex flex-col justify-between group"
              >
                <div>
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h2 className="text-base font-bold text-white leading-snug line-clamp-1 group-hover:text-cyan-300 transition-colors">
                        {comp.name}
                      </h2>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                        <span className="font-mono text-cyan-400 font-medium">NIT: {comp.nit}</span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate text-slate-300">{comp.industry}</span>
                      </div>
                    </div>

                    {/* Company Edit / Delete Actions */}
                    {canManageCompanies && (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => handleOpenEditModal(comp)}
                          className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                          title="Editar empresa"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        {currentUser.role === 'ADMIN' && (
                          <button
                            onClick={() => {
                              if (window.confirm(`¿Seguro que deseas eliminar la empresa "${comp.name}"? Los trabajadores quedarán sin empresa asignada.`)) {
                                onDeleteCompany(comp.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                            title="Eliminar empresa"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Card Details */}
                  <div className="mt-4 pt-3 border-t border-white/5 space-y-2 text-xs text-slate-300">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span className="truncate">{comp.address || 'Guatemala'}</span>
                    </div>
                    {comp.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <span>{comp.phone}</span>
                      </div>
                    )}
                  </div>

                  {/* Operational Stats with Glass Background */}
                  <div className="mt-4 grid grid-cols-2 gap-2 p-3 bg-black/30 border border-white/5 rounded-xl">
                    <div>
                      <span className="text-[10px] uppercase font-semibold text-slate-400 block">Colaboradores</span>
                      <span className="text-sm font-bold text-emerald-400 mt-0.5 block tabular-nums">
                        {activeEmps.length} activos
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-semibold text-slate-400 block">
                        {canViewSalaries ? 'Quincena Aprox.' : 'Privacidad'}
                      </span>
                      {canViewSalaries ? (
                        <span className="text-sm font-bold text-cyan-300 mt-0.5 block tabular-nums">
                          {formatCurrencyGTQ(quincenalEst)}
                        </span>
                      ) : (
                        <span className="text-xs font-semibold text-purple-300 mt-0.5 block">
                          Sueldos Protegidos
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Footer Action */}
                {canViewEmployees && (
                  <div className="mt-4 pt-3 border-t border-white/5">
                    <button
                      onClick={() => onSelectCompanyForEmployees(comp.id)}
                      className="w-full flex items-center justify-between text-xs font-semibold text-slate-300 hover:text-cyan-300 py-1 transition-colors"
                    >
                      <span>Ver colaboradores ({compEmployees.length})</span>
                      <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Modal in Liquid Glass Elevated */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="liquid-glass-elevated rounded-3xl max-w-lg w-full p-6 border border-white/15 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <h3 className="text-lg font-bold text-white">
                {editingCompany ? 'Editar Empresa' : 'Registrar Nueva Empresa'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
              {errorMsg && (
                <div className="p-3 bg-rose-500/10 text-rose-300 rounded-xl border border-rose-500/30">
                  {errorMsg}
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Nombre o Razón Social <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Distribuidora del Norte, S.A."
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    NIT <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. 1234567-8"
                    value={formData.nit}
                    onChange={e => setFormData({ ...formData, nit: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Giro / Industria
                  </label>
                  <input
                    type="text"
                    placeholder="Ej. Manufactura, Servicios"
                    value={formData.industry}
                    onChange={e => setFormData({ ...formData, industry: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Dirección Fiscal / Sede
                </label>
                <input
                  type="text"
                  placeholder="Ej. Calzada Roosevelt 15-40, Zona 11, Guatemala"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Teléfono
                  </label>
                  <input
                    type="text"
                    placeholder="Ej. +502 2345-6789"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Correo Electrónico
                  </label>
                  <input
                    type="email"
                    placeholder="contacto@empresa.gt"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-glass-input text-xs"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 rounded-xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] disabled:opacity-50"
                >
                  {isSubmitting ? 'Guardando...' : (editingCompany ? 'Guardar Cambios' : 'Crear Empresa')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
