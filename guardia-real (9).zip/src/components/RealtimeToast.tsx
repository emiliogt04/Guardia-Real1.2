import React, { useEffect } from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { RealtimeNotification } from '../types';

interface RealtimeToastProps {
  notification: RealtimeNotification | null;
  onClose: () => void;
  onClickNotification?: (tab: string) => void;
}

export const RealtimeToast: React.FC<RealtimeToastProps> = ({
  notification,
  onClose,
  onClickNotification,
}) => {
  useEffect(() => {
    if (!notification) return;
    const timer = setTimeout(() => {
      onClose();
    }, 6000);
    return () => clearTimeout(timer);
  }, [notification, onClose]);

  if (!notification) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 max-w-sm w-full animate-in fade-in slide-in-from-bottom-5 duration-300">
      <div className="liquid-glass-elevated text-white p-4 rounded-3xl border border-white/20 shadow-[0_16px_48px_rgba(0,0,0,0.7)] flex items-start gap-3 backdrop-blur-2xl">
        <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 shrink-0 mt-0.5 border border-amber-400/30 shadow-[0_0_15px_rgba(245,158,11,0.25)]">
          <AlertTriangle className="w-5 h-5" />
        </div>

        <div className="flex-1 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-[10px] uppercase tracking-wider text-amber-300">
              Alerta en Tiempo Real
            </span>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-0.5 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <h4 className="font-bold text-sm text-white mt-1 leading-snug">
            {notification.title}
          </h4>
          <p className="text-slate-300 mt-1 leading-normal text-[11px]">
            {notification.message}
          </p>

          <div className="mt-2.5 flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-white/10">
            <span>Actor: <strong className="text-cyan-300">{notification.actorName}</strong></span>
            {notification.linkTab && onClickNotification && (
              <button
                onClick={() => {
                  onClickNotification(notification.linkTab!);
                  onClose();
                }}
                className="text-cyan-400 hover:text-cyan-300 font-semibold underline"
              >
                Ver auditoría
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
