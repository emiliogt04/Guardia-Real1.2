import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import { formatCurrencyGTQ } from './formatters';

const safeFileName = (label: string) => label.replace(/[^\w\-áéíóúÁÉÍÓÚñÑ]+/g, '_');

export async function exportPayrollSummaryToPDF(options: {
  rows: any[],
  periodLabel: string,
  companyName: string
}) {
  const doc = new jsPDF();
  const pageBottom = 280;

  const drawHeader = (y: number) => {
    doc.setFontSize(10);
    doc.text('Colaborador', 14, y);
    doc.text('Sueldo Base', 90, y);
    doc.text('Descuentos', 135, y);
    doc.text('Neto', 175, y);
    doc.line(14, y + 2, 195, y + 2);
    return y + 8;
  };

  doc.setFontSize(16);
  doc.text(`Resumen de Nómina: ${options.periodLabel}`, 14, 20);
  doc.setFontSize(10);
  doc.text(`Empresa: ${options.companyName}`, 14, 30);

  let y = drawHeader(40);
  let totalNet = 0;

  options.rows.forEach(row => {
    const detail: string[] = (row.appliedDiscounts || []).map((d: any) =>
      `- ${d.reason}: ${formatCurrencyGTQ(d.amountToCharge ?? d.installmentAmount ?? d.amount)}${d.totalInstallments > 1 ? ` (cuota ${d.currentInstallment}/${d.totalInstallments})` : ''}`
    );
    const needed = 7 + detail.length * 4 + (row.periodLabel ? 4 : 0);
    if (y + needed > pageBottom) {
      doc.addPage();
      y = drawHeader(20);
    }
    doc.setFontSize(10);
    doc.text(String(row.employeeName || ''), 14, y);
    doc.text(formatCurrencyGTQ(row.quincenalBase), 90, y);
    doc.text(formatCurrencyGTQ(row.discountsTotal), 135, y);
    doc.text(formatCurrencyGTQ(row.netAmount), 175, y);
    totalNet += row.netAmount || 0;
    doc.setFontSize(7);
    if (row.periodLabel) {
      y += 4;
      doc.text(row.periodLabel, 14, y);
    }
    detail.forEach(line => {
      y += 4;
      doc.text(line, 18, y);
    });
    y += 7;
  });

  if (y + 10 > pageBottom) {
    doc.addPage();
    y = 20;
  }
  doc.setFontSize(10);
  doc.line(14, y - 3, 195, y - 3);
  doc.text('Total neto', 14, y + 2);
  doc.text(formatCurrencyGTQ(totalNet), 175, y + 2);

  doc.save(`Resumen_Nomina_${safeFileName(options.periodLabel)}.pdf`);
}

export function exportPayrollSummaryToExcel(options: {
  rows: any[],
  periodLabel: string
}) {
  const ws = XLSX.utils.json_to_sheet(options.rows.map(row => ({
    'Período': row.periodLabel || options.periodLabel,
    'Colaborador': row.employeeName,
    'Sueldo Base': row.quincenalBase,
    'IGSS': row.igssDeduction || 0,
    'Descuentos': row.discountsTotal,
    'Detalle de descuentos': (row.appliedDiscounts || []).map((d: any) =>
      `${d.reason}: ${d.amountToCharge ?? d.installmentAmount ?? d.amount}${d.totalInstallments > 1 ? ` (cuota ${d.currentInstallment}/${d.totalInstallments})` : ''}`
    ).join(' | '),
    'Neto': row.netAmount
  })));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Resumen');
  XLSX.writeFile(wb, `Resumen_Nomina_${safeFileName(options.periodLabel)}.xlsx`);
}
