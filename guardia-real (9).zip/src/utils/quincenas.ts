// Lógica compartida (servidor + interfaz) para trabajar con quincenas y cuotas de descuentos.
// Una quincena se identifica por año, mes (1-12) y número (1 = primera, 2 = segunda).
// Las quincenas se cuentan en orden consecutivo: 1ra del mes, 2da del mes, 1ra del mes siguiente...
// El cálculo SOLO depende de la quincena que se evalúa, nunca de la fecha de hoy ni de contadores.

export type QuincenaNum = 1 | 2;

export interface QuincenaRef {
  year: number;
  month: number; // 1-12
  quincena: QuincenaNum;
}

export const MONTH_NAMES_ES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre',
];

const pad2 = (n: number) => String(n).padStart(2, '0');

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/** Índice absoluto y consecutivo de una quincena (sirve para comparar y contar). */
export function quincenaIndex(q: QuincenaRef): number {
  return q.year * 24 + (q.month - 1) * 2 + (q.quincena - 1);
}

export function quincenaFromIndex(index: number): QuincenaRef {
  const year = Math.floor(index / 24);
  const rest = index - year * 24;
  return { year, month: Math.floor(rest / 2) + 1, quincena: ((rest % 2) + 1) as QuincenaNum };
}

/** Clave canónica de una quincena, p. ej. "2026-10-Q2". */
export function quincenaKey(q: QuincenaRef): string {
  return `${q.year}-${pad2(q.month)}-Q${q.quincena}`;
}

export function quincenaLabel(q: QuincenaRef): string {
  return `${q.quincena === 1 ? '1ra' : '2da'} quincena de ${MONTH_NAMES_ES[q.month - 1]} ${q.year}`;
}

/** Acepta 10, "10", "Octubre", "octubre". Devuelve 1-12 o null. */
export function parseMonth(value: unknown): number | null {
  if (typeof value === 'number' && Number.isInteger(value) && value >= 1 && value <= 12) return value;
  if (typeof value !== 'string') return null;
  const text = value.trim();
  if (/^\d{1,2}$/.test(text)) {
    const n = Number(text);
    return n >= 1 && n <= 12 ? n : null;
  }
  const normalized = text.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const idx = MONTH_NAMES_ES.findIndex(
    m => m.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase() === normalized
  );
  return idx >= 0 ? idx + 1 : null;
}

/** Acepta 1, 2, "1RA_QUINCENA", "2da Quincena", "1", etc. */
export function parseQuincena(value: unknown): QuincenaNum | null {
  if (value === 1 || value === 2) return value;
  if (typeof value !== 'string') return null;
  const m = value.trim().match(/^([12])/);
  return m ? (Number(m[1]) as QuincenaNum) : null;
}

export function parseQuincenaRef(year: unknown, month: unknown, quincena: unknown): QuincenaRef | null {
  const y = Number(year);
  const m = parseMonth(month);
  const q = parseQuincena(quincena);
  if (!Number.isInteger(y) || y < 2000 || y > 2200 || m === null || q === null) return null;
  return { year: y, month: m, quincena: q };
}

/** Quincena en la que cae una fecha YYYY-MM-DD (solo para valores por defecto del formulario). */
export function quincenaFromDate(date: string | Date): QuincenaRef {
  const text = typeof date === 'string' ? date.slice(0, 10) : date.toISOString().slice(0, 10);
  const [y, m, d] = text.split('-').map(Number);
  return { year: y, month: m, quincena: d <= 15 ? 1 : 2 };
}

export function currentQuincena(now: Date = new Date()): QuincenaRef {
  return { year: now.getFullYear(), month: now.getMonth() + 1, quincena: now.getDate() <= 15 ? 1 : 2 };
}

/** Convierte claves antiguas ("2026-10-1ra Quincena", "2026-Octubre-1RA_QUINCENA") a la clave canónica. */
export function normalizePeriodKey(key: string): string {
  const parts = String(key).split('-');
  if (parts.length >= 3) {
    const ref = parseQuincenaRef(parts[0], parts[1], parts.slice(2).join('-').replace(/^Q/i, ''));
    if (ref) return quincenaKey(ref);
  }
  return key;
}

// ---------------------------------------------------------------------------
// Descuentos en cuotas
// ---------------------------------------------------------------------------

export interface InstallmentDiscountLike {
  id?: string;
  amount: number;
  installments?: number;
  startYear?: number;
  startMonth?: number;
  startQuincena?: number;
  paidPeriods?: string[];
  status?: string;
}

export const INACTIVE_DISCOUNT_STATUSES = ['FINALIZADO', 'CANCELADO', 'ELIMINADO'];

export function getTotalInstallments(d: InstallmentDiscountLike): number {
  const n = Math.floor(Number(d.installments));
  return Number.isFinite(n) && n >= 1 ? n : 1;
}

export function getStartQuincena(d: InstallmentDiscountLike): QuincenaRef | null {
  return parseQuincenaRef(d.startYear, d.startMonth, d.startQuincena);
}

/** Última quincena en la que se cobra el descuento. */
export function getEndQuincena(d: InstallmentDiscountLike): QuincenaRef | null {
  const start = getStartQuincena(d);
  if (!start) return null;
  return quincenaFromIndex(quincenaIndex(start) + getTotalInstallments(d) - 1);
}

/** Número de cuota (1..N) que corresponde a la quincena indicada, o null si queda fuera del rango. */
export function getInstallmentNumber(d: InstallmentDiscountLike, target: QuincenaRef): number | null {
  const start = getStartQuincena(d);
  if (!start) return null;
  const n = quincenaIndex(target) - quincenaIndex(start) + 1;
  return n >= 1 && n <= getTotalInstallments(d) ? n : null;
}

/** Monto de una cuota concreta. La última cuota absorbe el residuo del redondeo. */
export function getInstallmentAmount(d: InstallmentDiscountLike, installmentNumber: number): number {
  const total = getTotalInstallments(d);
  const base = round2(d.amount / total);
  return installmentNumber >= total ? round2(d.amount - base * (total - 1)) : base;
}

/** Monto "tipo" por cuota para mostrar en listas. */
export function getPerInstallmentAmount(d: InstallmentDiscountLike): number {
  return getInstallmentAmount(d, 1);
}

/**
 * ¿Se aplica el descuento en la quincena indicada?
 * Solo depende del rango [inicio, inicio + cuotas - 1] y del estado; no usa fecha de hoy ni contadores.
 */
export function isDiscountApplicable(d: InstallmentDiscountLike, target: QuincenaRef): boolean {
  if (d.status && INACTIVE_DISCOUNT_STATUSES.includes(d.status)) return false;
  return getInstallmentNumber(d, target) !== null;
}

export function getPaidCount(d: InstallmentDiscountLike): number {
  return new Set((d.paidPeriods || []).map(normalizePeriodKey)).size;
}

export interface DiscountProgress {
  total: number;
  applied: number;
  remaining: number;
  perInstallment: number;
  remainingAmount: number;
  start: QuincenaRef | null;
  end: QuincenaRef | null;
  finished: boolean;
}

export function getDiscountProgress(d: InstallmentDiscountLike): DiscountProgress {
  const total = getTotalInstallments(d);
  const applied = Math.min(getPaidCount(d), total);
  const remaining = Math.max(0, total - applied);
  const perInstallment = getPerInstallmentAmount(d);
  const remainingAmount = Math.max(0, round2(d.amount - perInstallment * applied));
  return {
    total,
    applied,
    remaining,
    perInstallment,
    remainingAmount: remaining === 0 ? 0 : remainingAmount,
    start: getStartQuincena(d),
    end: getEndQuincena(d),
    finished: d.status === 'FINALIZADO' || remaining === 0,
  };
}
