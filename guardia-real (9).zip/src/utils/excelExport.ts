import * as XLSX from 'xlsx';
import { AuditLog, Company, Employee, PaymentReceipt } from '../types';
import { formatCurrencyGTQ, formatDate, formatDateTime, formatDPI } from './formatters';

export type PayrollPeriodType = '1RA_QUINCENA' | '2DA_QUINCENA' | 'MES_COMPLETO' | 'RANGO_PERSONALIZADO';

export interface PayrollExportOptions {
  periodType: PayrollPeriodType;
  year: number;
  month: number; // 1-12
  customStartDate?: string;
  customEndDate?: string;
  companyId?: string;
  generatedBy: string;
  includeBonificacion?: boolean; // Bonificación incentivo Dto 37-2001
  applyIGSS?: boolean;           // Descuento laboral IGSS 4.83%
}

export function calculatePayrollRow(
  emp: Employee,
  periodType: PayrollPeriodType,
  year: number,
  month: number,
  customStart?: string,
  customEnd?: string,
  includeBonificacion: boolean = true,
  applyIGSS: boolean = true
) {
  // Days calculation
  let daysInPeriod = 15;
  let periodLabel = '';

  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];
  const monthName = monthNames[month - 1] || 'Mes';

  // Total days in this month
  const lastDayOfMonth = new Date(year, month, 0).getDate();

  if (periodType === '1RA_QUINCENA') {
    daysInPeriod = 15;
    periodLabel = `1ra Quincena (01 al 15 de ${monthName} ${year})`;
  } else if (periodType === '2DA_QUINCENA') {
    daysInPeriod = lastDayOfMonth - 15; // 15 or 16 (or 13/14 for feb)
    periodLabel = `2da Quincena (16 al ${lastDayOfMonth} de ${monthName} ${year})`;
  } else if (periodType === 'MES_COMPLETO') {
    daysInPeriod = 30; // standard commercial month
    periodLabel = `Mes Completo (01 al ${lastDayOfMonth} de ${monthName} ${year})`;
  } else if (periodType === 'RANGO_PERSONALIZADO' && customStart && customEnd) {
    const d1 = new Date(customStart);
    const d2 = new Date(customEnd);
    const diffTime = Math.abs(d2.getTime() - d1.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    daysInPeriod = Math.max(1, Math.min(31, diffDays));
    periodLabel = `Período Personalizado (${formatDate(customStart)} al ${formatDate(customEnd)})`;
  }

  // Check if employee started after or was terminated before
  let effectiveDays = daysInPeriod;

  // Base monthly salary
  const monthlySalary = emp.monthlySalary || 0;

  // Ordinary salary for the period
  let ordinarySalary = 0;
  if (periodType === '1RA_QUINCENA' || periodType === '2DA_QUINCENA') {
    ordinarySalary = Math.round((monthlySalary / 2) * 100) / 100;
  } else if (periodType === 'MES_COMPLETO') {
    ordinarySalary = monthlySalary;
  } else {
    ordinarySalary = Math.round(((monthlySalary / 30) * effectiveDays) * 100) / 100;
  }

  // Bonificación Incentivo Decreto 37-2001 (Q250 mensual -> Q125 quincenal)
  let bonificacionIncentivo = 0;
  if (includeBonificacion) {
    if (periodType === '1RA_QUINCENA' || periodType === '2DA_QUINCENA') {
      bonificacionIncentivo = 125.00;
    } else if (periodType === 'MES_COMPLETO') {
      bonificacionIncentivo = 250.00;
    } else {
      bonificacionIncentivo = Math.round(((250.00 / 30) * effectiveDays) * 100) / 100;
    }
  }

  // Total Devengado
  const totalDevengado = Math.round((ordinarySalary + bonificacionIncentivo) * 100) / 100;

  // Retención Laboral IGSS 4.83% sobre el salario ordinario (Solo si el empleado tiene activado appliesIGSS)
  const shouldCalculateIGSS = applyIGSS && (emp.appliesIGSS !== false);
  const descuentoIGSS = shouldCalculateIGSS ? Math.round((ordinarySalary * 0.0483) * 100) / 100 : 0;

  // Filtrar descuentos del guardia según el período (1ra Quincena, 2da Quincena o Mes Completo)
  const guardDiscounts = (emp.discounts || []).filter(d => {
    if (!d.period || d.period === 'MENSUAL') return true;
    if (periodType === '1RA_QUINCENA' && d.period === '1RA_QUINCENA') return true;
    if (periodType === '2DA_QUINCENA' && d.period === '2DA_QUINCENA') return true;
    if (periodType === 'MES_COMPLETO') return true;
    return false;
  });
  const customDiscountsAmount = guardDiscounts.reduce((sum, d) => sum + d.amount, 0);

  // Total Descuentos
  const totalDescuentos = Math.round((descuentoIGSS + customDiscountsAmount) * 100) / 100;

  // Líquido a Pagar / Salario Neto
  const liquidoAPagar = Math.round((totalDevengado - totalDescuentos) * 100) / 100;

  return {
    employee: emp,
    periodLabel,
    effectiveDays,
    monthlySalary,
    ordinarySalary,
    bonificacionIncentivo,
    totalDevengado,
    appliesIGSS: emp.appliesIGSS !== false,
    descuentoIGSS,
    totalDescuentos,
    liquidoAPagar,
  };
}

export function generateExcelReport(
  employees: Employee[],
  auditLogs: AuditLog[],
  companies: Company[],
  options: {
    startDate?: string;
    endDate?: string;
    companyId?: string;
    userId?: string;
    generatedBy: string;
    periodType?: PayrollPeriodType;
    year?: number;
    month?: number;
  }
) {
  const wb = XLSX.utils.book_new();

  const companyMap = new Map<string, string>();
  companies.forEach(c => companyMap.set(c.id, c.name));

  // Determine period parameters
  const now = new Date();
  const year = options.year || now.getFullYear();
  const month = options.month || (now.getMonth() + 1);
  const periodType = options.periodType || (options.startDate && options.endDate ? 'RANGO_PERSONALIZADO' : '1RA_QUINCENA');

  // Filter employees
  const targetEmployees = employees.filter(emp => {
    if (options.companyId && options.companyId !== 'all') {
      if (emp.companyId !== options.companyId) return false;
    }
    // Only active employees in payroll
    return emp.status === 'ACTIVO';
  });

  // Calculate payroll rows
  const calculatedRows = targetEmployees.map(emp =>
    calculatePayrollRow(
      emp,
      periodType,
      year,
      month,
      options.startDate,
      options.endDate,
      true,
      true
    )
  );

  const selectedCompanyName = options.companyId && options.companyId !== 'all'
    ? (companyMap.get(options.companyId) || 'Empresa Seleccionada')
    : 'Todas las Empresas (Consolidado)';

  // ==========================================
  // SHEET 1: PLANILLA DE PAGOS QUINCENAL / MENSUAL
  // ==========================================
  const headerData: any[][] = [
    ['SISTEMA DE NÓMINA Y GESTIÓN LABORAL - GUATEMALA'],
    [`PLANILLA DE PAGOS DE SUELDOS Y SALARIOS (${periodType.replace(/_/g, ' ')})`],
    [`EMPRESA: ${selectedCompanyName.toUpperCase()}`],
    [`PERÍODO: ${calculatedRows[0]?.periodLabel || `${year}-${month}`} | FECHA DE GENERACIÓN: ${new Date().toLocaleDateString('es-GT')}`],
    [`GENERADO POR: ${options.generatedBy}`],
    [''],
    [
      'No.',
      'Empresa',
      'Nombre del Colaborador',
      'DPI (CUI)',
      'Puesto / Cargo',
      'Salario Base Mensual (Q)',
      'Días Período',
      'Sueldo Ordinario (Q)',
      'Bonif. Dto. 37-2001 (Q)',
      'Total Devengado (Q)',
      'Cuota IGSS 4.83% (Q)',
      'Total Descuentos (Q)',
      'LÍQUIDO A RECIBIR (Q)',
      'Firma de Recibido / Boleta',
    ],
  ];

  let sumBase = 0;
  let sumOrdinario = 0;
  let sumBonif = 0;
  let sumDevengado = 0;
  let sumIGSS = 0;
  let sumDescuentos = 0;
  let sumLiquido = 0;

  calculatedRows.forEach((r, idx) => {
    sumBase += r.monthlySalary;
    sumOrdinario += r.ordinarySalary;
    sumBonif += r.bonificacionIncentivo;
    sumDevengado += r.totalDevengado;
    sumIGSS += r.descuentoIGSS;
    sumDescuentos += r.totalDescuentos;
    sumLiquido += r.liquidoAPagar;

    headerData.push([
      idx + 1,
      companyMap.get(r.employee.companyId) || 'N/A',
      r.employee.name,
      formatDPI(r.employee.dpi),
      r.employee.position,
      r.monthlySalary,
      r.effectiveDays,
      r.ordinarySalary,
      r.bonificacionIncentivo,
      r.totalDevengado,
      r.descuentoIGSS,
      r.totalDescuentos,
      r.liquidoAPagar,
      '', // Espacio para firma
    ]);
  });

  // TOTALS ROW
  headerData.push([
    '',
    '',
    'TOTALES GENERALES DE LA PLANILLA',
    '',
    `${calculatedRows.length} Colaboradores`,
    sumBase,
    '',
    sumOrdinario,
    sumBonif,
    sumDevengado,
    sumIGSS,
    sumDescuentos,
    sumLiquido,
    '',
  ]);

  const wsPayroll = XLSX.utils.aoa_to_sheet(headerData);
  wsPayroll['!cols'] = [
    { wch: 6 },
    { wch: 32 },
    { wch: 32 },
    { wch: 18 },
    { wch: 28 },
    { wch: 22 },
    { wch: 12 },
    { wch: 20 },
    { wch: 22 },
    { wch: 20 },
    { wch: 20 },
    { wch: 20 },
    { wch: 24 },
    { wch: 26 },
  ];
  XLSX.utils.book_append_sheet(wb, wsPayroll, 'Planilla de Pagos');

  // ==========================================
  // SHEET 2: DISPERSIÓN BANCARIA / TRANSFERENCIAS
  // ==========================================
  const bankRows = calculatedRows.map((r, idx) => ({
    'No.': idx + 1,
    'Beneficiario': r.employee.name,
    'DPI': formatDPI(r.employee.dpi),
    'Empresa Emisora': companyMap.get(r.employee.companyId) || '',
    'Puesto': r.employee.position,
    'Monto Neto a Transferir (Q)': r.liquidoAPagar,
    'Formato Moneda': formatCurrencyGTQ(r.liquidoAPagar),
    'Concepto': `Pago ${r.periodLabel}`,
  }));

  const wsBank = XLSX.utils.json_to_sheet(bankRows);
  wsBank['!cols'] = [
    { wch: 6 },
    { wch: 32 },
    { wch: 18 },
    { wch: 32 },
    { wch: 26 },
    { wch: 26 },
    { wch: 22 },
    { wch: 40 },
  ];
  XLSX.utils.book_append_sheet(wb, wsBank, 'Dispersión Bancaria');

  // ==========================================
  // SHEET 3: HISTORIAL DE AUDITORÍA
  // ==========================================
  const filteredLogs = auditLogs.filter(log => {
    if (options.startDate && log.timestamp < options.startDate) return false;
    if (options.endDate) {
      const endISO = `${options.endDate}T23:59:59.999Z`;
      if (log.timestamp > endISO) return false;
    }
    if (options.companyId && options.companyId !== 'all') {
      if (log.companyId !== options.companyId) return false;
    }
    if (options.userId && options.userId !== 'all') {
      if (log.userId !== options.userId) return false;
    }
    return true;
  });

  const auditRows = filteredLogs.map((log, index) => ({
    'No.': index + 1,
    'Fecha y Hora': formatDateTime(log.timestamp),
    'Usuario': log.userName,
    'Rol': log.userRole,
    'Acción': log.action.replace(/_/g, ' '),
    'Entidad': `${log.entityType}: ${log.entityName}`,
    'Empresa': log.companyName || 'General',
    'Resumen': log.summary,
    'Crítico': log.isCritical ? 'SÍ' : 'NO',
    'Cambios Detectados': log.changes.map(c => `${c.label || c.field}: ${c.oldValue ?? ''} -> ${c.newValue ?? ''}`).join(' | '),
  }));

  const wsAudit = XLSX.utils.json_to_sheet(auditRows);
  wsAudit['!cols'] = [
    { wch: 6 },
    { wch: 20 },
    { wch: 26 },
    { wch: 10 },
    { wch: 22 },
    { wch: 32 },
    { wch: 32 },
    { wch: 42 },
    { wch: 10 },
    { wch: 45 },
  ];
  XLSX.utils.book_append_sheet(wb, wsAudit, 'Auditoría de Cambios');

  // Write Excel file
  const dateStr = new Date().toISOString().slice(0, 10);
  const fileName = `Planilla_Pagos_${periodType}_${year}_M${month}_${dateStr}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

export interface ReceiptsHistoryExcelOptions {
  periodLabel: string;
  quincenaFilter?: 'ALL' | '1RA_QUINCENA' | '2DA_QUINCENA';
  companyName?: string;
}

export function exportReceiptsHistoryToExcel(
  receipts: PaymentReceipt[],
  options: ReceiptsHistoryExcelOptions
) {
  const { periodLabel, companyName = 'Guardia Real' } = options;

  const rows = receipts.map((r, index) => {
    const formattedDate = `${String(r.day).padStart(2, '0')}/${String(r.month).padStart(2, '0')}/${r.year}`;
    return {
      'No.': index + 1,
      'No. Comprobante': `#${r.id.slice(0, 8).toUpperCase()}`,
      'Fecha Emisión': formattedDate,
      'Mes': r.month,
      'Año': r.year,
      'Colaborador': r.employeeName,
      'DPI (CUI)': r.employeeDpi ? formatDPI(r.employeeDpi) : 'No Registrado',
      'Monto Liquidado (Q)': Number(r.amount.toFixed(2)),
      'Cantidad en Letras': r.amountInWords || `${r.amount.toFixed(2)} QUETZALES`,
      'Concepto de Pago': r.concept,
      'Método de Pago': r.paymentMethod,
      'No. Boleta / Referencia': r.referenceNumber || 'N/A',
      'Observaciones': r.observations || '',
      'Emitido Por': r.issuedBy || 'Administración',
      'ID Transacción': r.id,
    };
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);

  ws['!cols'] = [
    { wch: 6 },
    { wch: 16 },
    { wch: 14 },
    { wch: 6 },
    { wch: 8 },
    { wch: 28 },
    { wch: 18 },
    { wch: 20 },
    { wch: 36 },
    { wch: 34 },
    { wch: 16 },
    { wch: 22 },
    { wch: 30 },
    { wch: 20 },
    { wch: 24 },
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Histórico de Recibos');

  const cleanPeriod = periodLabel.replace(/[^a-zA-Z0-9]/g, '_');
  const dateStr = new Date().toISOString().slice(0, 10);
  const fileName = `Historico_Recibos_${cleanPeriod}_${dateStr}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

