import jsPDF from 'jspdf';
import { PaymentReceipt, GuardPayment, Employee } from '../types';
import { formatCurrencyGTQ, formatDPI, formatDate, formatDateTime } from './formatters';
import { GUARDIA_REAL_LOGO_BASE64 } from '../assets/logoBase64';

export interface EmployeeStatementExportOptions {
  employee: Employee;
  receipts: PaymentReceipt[];
  payments?: GuardPayment[];
  month: number;
  year: number;
  companyName?: string;
  companyNit?: string;
  companyAddress?: string;
  generatedBy?: string;
}

export interface QuincenaExportOptions {
  receipts: PaymentReceipt[];
  employeeName?: string;
  periodLabel: string;
  companyName?: string;
  companyNit?: string;
}

export interface ReceiptsHistoryReportOptions {
  receipts: PaymentReceipt[];
  periodLabel: string;
  quincenaFilter?: 'ALL' | '1RA_QUINCENA' | '2DA_QUINCENA';
  month?: number;
  year?: number;
  companyName?: string;
  companyNit?: string;
  generatedBy?: string;
}

const MONTH_NAMES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

// Medidas de hoja tamaño Carta (Letter) en milímetros
export const LETTER_WIDTH_MM = 215.9;
export const LETTER_HEIGHT_MM = 279.4;
export const VOUCHER_MARGIN_X = 9;
export const VOUCHER_WIDTH = LETTER_WIDTH_MM - (VOUCHER_MARGIN_X * 2); // 197.9 mm
export const VOUCHER_HEIGHT = 126; // Media carta

/**
 * Dibuja un comprobante de pago COMPLETO que ocupa toda una Hoja Tamaño Carta (Letter: 215.9 x 279.4 mm).
 * Cumple con el requisito del usuario: "solo colocar los recibos uno por uno, al visualizar al colaborador".
 * Incorpora el logo oficial de Guardia Real, valor en Quetzales, desglose y ÚNICAMENTE la firma de recibido del colaborador.
 */
export function drawSingleVoucherLetterPage(
  doc: jsPDF,
  receipt: PaymentReceipt,
  companyName: string = 'GUARDIA REAL DE GUATEMALA',
  companyNit: string = 'NIT: 9812401-2'
) {
  const margin = 14;
  const contentWidth = LETTER_WIDTH_MM - (margin * 2); // 187.9 mm
  const cardHeight = LETTER_HEIGHT_MM - (margin * 2); // 251.4 mm

  // Fondo blanco de la hoja carta
  doc.setFillColor(255, 255, 255);
  doc.rect(0, 0, LETTER_WIDTH_MM, LETTER_HEIGHT_MM, 'F');

  // Marca de agua / Fondo con el logo institucional sutil
  try {
    // @ts-ignore
    doc.saveGraphicsState();
    // @ts-ignore
    doc.setGState(new (doc as any).GState({ opacity: 0.05 }));
    const wmSize = 110;
    const wmX = margin + (contentWidth / 2) - (wmSize / 2);
    const wmY = margin + (cardHeight / 2) - (wmSize / 2);
    doc.addImage(GUARDIA_REAL_LOGO_BASE64, 'JPEG', wmX, wmY, wmSize, wmSize);
    // @ts-ignore
    doc.restoreGraphicsState();
  } catch (e) {
    // Fallback if GState not supported
  }

  // Marco exterior decorativo
  doc.setDrawColor(203, 213, 225); // slate-300
  doc.setLineWidth(0.6);
  doc.roundedRect(margin, margin, contentWidth, cardHeight, 3.5, 3.5, 'S');

  // Barra superior institucional: Azul marino slate-900 con línea de acento cian
  doc.setFillColor(15, 23, 42); // slate-900
  doc.roundedRect(margin, margin, contentWidth, 36, 3, 3, 'F');
  doc.setFillColor(6, 182, 212); // cyan-500
  doc.rect(margin, margin, contentWidth, 2.5, 'F');

  // --- 1. ENCABEZADO CON LOGO OFICIAL GUARDIA REAL ---
  const logoSize = 25; // mm
  try {
    doc.addImage(GUARDIA_REAL_LOGO_BASE64, 'JPEG', margin + 5, margin + 5.5, logoSize, logoSize);
  } catch (err) {
    doc.setFillColor(6, 182, 212);
    doc.roundedRect(margin + 5, margin + 5.5, logoSize, logoSize, 2, 2, 'F');
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('GR', margin + 17.5, margin + 19, { align: 'center' });
  }

  // Textos Institucionales
  const textLeftX = margin + logoSize + 9;
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text(companyName.toUpperCase(), textLeftX, margin + 12);

  doc.setTextColor(148, 163, 184); // slate-400
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.8);
  doc.text('SEGURIDAD PRIVADA & SERVICIOS ESPECIALIZADOS DE VIGILANCIA CORPORATIVA', textLeftX, margin + 18);

  doc.setTextColor(203, 213, 225); // slate-300
  doc.setFontSize(7.2);
  doc.text(`${companyNit} · República de Guatemala · Nómina & Liquidaciones`, textLeftX, margin + 23.5);
  doc.text('PBX: (502) 2200-0000 · operaciones@guardiareal.gt · Ciudad de Guatemala', textLeftX, margin + 28.5);

  // Badge derecho de Comprobante
  const badgeWidth = 58;
  const badgeX = margin + contentWidth - badgeWidth - 4;
  doc.setFillColor(30, 41, 59); // slate-800
  doc.setDrawColor(6, 182, 212); // cyan-500
  doc.setLineWidth(0.5);
  doc.roundedRect(badgeX, margin + 5.5, badgeWidth, 25, 2, 2, 'FD');

  doc.setTextColor(6, 182, 212);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('COMPROBANTE DE PAGO', badgeX + (badgeWidth / 2), margin + 11.5, { align: 'center' });

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(`NO. #${receipt.id.slice(0, 8).toUpperCase()}`, badgeX + (badgeWidth / 2), margin + 18, { align: 'center' });

  doc.setTextColor(148, 163, 184);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  const formattedDate = `${String(receipt.day).padStart(2, '0')}/${String(receipt.month).padStart(2, '0')}/${receipt.year}`;
  doc.text(`Fecha: ${formattedDate}`, badgeX + (badgeWidth / 2), margin + 23.5, { align: 'center' });
  doc.text('ORIGINAL', badgeX + (badgeWidth / 2), margin + 27.5, { align: 'center' });

  let currentY = margin + 41;

  // --- 2. CUADRO DE MONTO LIQUIDADO (QUETZALES) ---
  const amountBoxH = 22;
  doc.setFillColor(236, 254, 255); // cyan-50
  doc.setDrawColor(6, 182, 212); // cyan-500
  doc.setLineWidth(0.6);
  doc.roundedRect(margin + 4, currentY, contentWidth - 8, amountBoxH, 2.5, 2.5, 'FD');

  doc.setTextColor(14, 116, 144); // cyan-700
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('VALOR TOTAL LIQUIDADO (QUETZALES):', margin + 9, currentY + 7);

  doc.setFontSize(18);
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text(`Q ${receipt.amount.toFixed(2)}`, margin + 9, currentY + 16.5);

  // Cantidad en letras
  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text('CANTIDAD EN LETRAS:', margin + contentWidth - 9, currentY + 7, { align: 'right' });

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  const words = receipt.amountInWords || `${receipt.amount.toFixed(2)} QUETZALES EXACTOS`;
  const splitWords = doc.splitTextToSize(words.toUpperCase(), 115);
  doc.text(splitWords, margin + contentWidth - 9, currentY + 13.5, { align: 'right' });

  currentY += amountBoxH + 5;

  // --- 3. DATOS DEL COLABORADOR Y DETALLES DE PAGO (2 COLUMNAS AMPLIAS) ---
  const colW = (contentWidth - 12) / 2;
  const colBoxH = 34;

  // Columna Izquierda: Datos del Colaborador
  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.setLineWidth(0.4);
  doc.roundedRect(margin + 4, currentY, colW, colBoxH, 2, 2, 'FD');

  doc.setFillColor(6, 182, 212); // cyan-500
  doc.rect(margin + 4, currentY, 2.5, colBoxH, 'F');

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text('DATOS DEL COLABORADOR / BENEFICIARIO:', margin + 10, currentY + 7);

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.text(receipt.employeeName, margin + 10, currentY + 14);

  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  const dpiText = receipt.employeeDpi ? `DPI (CUI): ${formatDPI(receipt.employeeDpi)}` : 'DPI: Registrado en expediente laboral';
  doc.text(dpiText, margin + 10, currentY + 20.5);
  doc.text(`Código de Registro: #${receipt.employeeId.slice(0, 10).toUpperCase()}`, margin + 10, currentY + 26);
  doc.text('Cargo: Guardia de Seguridad / Personal Operativo', margin + 10, currentY + 31);

  // Columna Derecha: Método y Referencia de Pago
  const col2X = margin + 4 + colW + 4;
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(col2X, currentY, colW, colBoxH, 2, 2, 'FD');

  doc.setFillColor(16, 185, 129); // emerald-500
  doc.rect(col2X, currentY, 2.5, colBoxH, 'F');

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text('DETALLES DE LA TRANSACCIÓN Y PAGO:', col2X + 6, currentY + 7);

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text(`Forma: ${receipt.paymentMethod || 'TRANSFERENCIA BANCARIA'}`, col2X + 6, currentY + 14);

  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  const refText = receipt.referenceNumber ? `Boleta / Referencia: ${receipt.referenceNumber}` : 'Liquidación Directa de Sueldo';
  doc.text(refText, col2X + 6, currentY + 20.5);
  doc.text(`Período Correspondiente: Mes ${receipt.month}/${receipt.year}`, col2X + 6, currentY + 26);
  doc.text('Estado: Pago Realizado y Registrado', col2X + 6, currentY + 31);

  currentY += colBoxH + 5;

  // --- 4. CONCEPTO DE PAGO Y OBSERVACIONES (ÁREA EXPANDIDA) ---
  const conceptBoxH = 32;
  doc.setFillColor(241, 245, 249); // slate-100
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.4);
  doc.roundedRect(margin + 4, currentY, contentWidth - 8, conceptBoxH, 2, 2, 'FD');

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('POR CONCEPTO DE:', margin + 9, currentY + 7);

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  const splitConcept = doc.splitTextToSize(receipt.concept, contentWidth - 22);
  doc.text(splitConcept, margin + 9, currentY + 14);

  if (receipt.observations) {
    doc.setTextColor(71, 85, 105);
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(8);
    const splitObs = doc.splitTextToSize(`Observaciones / Notas: ${receipt.observations}`, contentWidth - 22);
    doc.text(splitObs, margin + 9, currentY + 24);
  }

  currentY += conceptBoxH + 16;

  // --- 5. FIRMA EXCLUSIVA DEL COLABORADOR (SOLO FIRMA DE RECIBIDO) ---
  // Requisito expreso del usuario: Solo firme de recibido el colaborador
  const sigLineWidth = 110;
  const sigStartX = margin + (contentWidth / 2) - (sigLineWidth / 2);

  // Línea de firma centrada
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.8);
  doc.line(sigStartX, currentY + 28, sigStartX + sigLineWidth, currentY + 28);

  // Nombre del colaborador
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.text(receipt.employeeName.toUpperCase(), margin + (contentWidth / 2), currentY + 34.5, { align: 'center' });

  // DPI y Etiqueta de recibido
  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  if (receipt.employeeDpi) {
    doc.text(`DPI (CUI): ${formatDPI(receipt.employeeDpi)}`, margin + (contentWidth / 2), currentY + 39.5, { align: 'center' });
  }

  doc.setTextColor(8, 145, 178); // cyan-600
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('FIRMA DE CONFORME / RECIBIDO (COLABORADOR)', margin + (contentWidth / 2), currentY + (receipt.employeeDpi ? 45 : 42), { align: 'center' });

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.2);
  doc.text('Recibí a mi entera satisfacción y conformidad el valor liquidado correspondiente.', margin + (contentWidth / 2), currentY + (receipt.employeeDpi ? 49.5 : 46.5), { align: 'center' });

  // Nota legal inferior
  const footerY = margin + cardHeight - 5;
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.4);
  doc.line(margin + 4, footerY - 3, margin + contentWidth - 4, footerY - 3);

  doc.setTextColor(148, 163, 184);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  doc.text('Este documento constituye comprobante oficial de liquidación salarial emitido conforme a la legislación laboral de Guatemala.', margin + 6, footerY);
  doc.text(`ID Único: ${receipt.id} · Hoja Tamaño Carta (1 por Hoja)`, margin + contentWidth - 6, footerY, { align: 'right' });
}

/**
 * Dibuja un comprobante de pago en media carta (para opciones compactas de 2 por hoja).
 */
function drawVoucherOnDoc(
  doc: jsPDF,
  receipt: PaymentReceipt,
  yTop: number,
  voucherHeight: number = VOUCHER_HEIGHT,
  copyLabel: string = 'ORIGINAL - ARCHIVO ADMINISTRACIÓN',
  companyName: string = 'GUARDIA REAL DE GUATEMALA',
  companyNit: string = 'NIT: 9812401-2'
) {
  const x = VOUCHER_MARGIN_X;
  const w = VOUCHER_WIDTH;

  doc.setFillColor(255, 255, 255);
  doc.roundedRect(x, yTop, w, voucherHeight, 2, 2, 'F');

  // Marca de agua / Fondo con el logo institucional sutil
  try {
    // @ts-ignore
    doc.saveGraphicsState();
    // @ts-ignore
    doc.setGState(new (doc as any).GState({ opacity: 0.05 }));
    const wmSize = 75;
    const wmX = x + (w / 2) - (wmSize / 2);
    const wmY = yTop + (voucherHeight / 2) - (wmSize / 2);
    doc.addImage(GUARDIA_REAL_LOGO_BASE64, 'JPEG', wmX, wmY, wmSize, wmSize);
    // @ts-ignore
    doc.restoreGraphicsState();
  } catch (e) {}

  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.4);
  doc.roundedRect(x, yTop, w, voucherHeight, 2, 2, 'S');

  doc.setFillColor(15, 23, 42);
  doc.roundedRect(x, yTop, w, 4, 1.5, 1.5, 'F');
  doc.setFillColor(6, 182, 212);
  doc.rect(x, yTop, w, 1.2, 'F');

  const logoSize = 18;
  try {
    doc.addImage(GUARDIA_REAL_LOGO_BASE64, 'JPEG', x + 3.5, yTop + 5.5, logoSize, logoSize);
  } catch {
    doc.setFillColor(6, 182, 212);
    doc.roundedRect(x + 3.5, yTop + 5.5, logoSize, logoSize, 2, 2, 'F');
  }

  const textLeftX = x + logoSize + 6;
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.text(companyName.toUpperCase(), textLeftX, yTop + 10.5);

  doc.setTextColor(51, 65, 85);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  doc.text('SEGURIDAD PRIVADA & SERVICIOS ESPECIALIZADOS DE VIGILANCIA CORPORATIVA', textLeftX, yTop + 15);
  
  doc.setTextColor(100, 116, 139);
  doc.setFontSize(6.2);
  doc.text(`${companyNit} · República de Guatemala · Nómina & Liquidaciones`, textLeftX, yTop + 19);

  const badgeWidth = 56;
  const badgeX = x + w - badgeWidth - 3.5;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(8, 145, 178);
  doc.setLineWidth(0.4);
  doc.roundedRect(badgeX, yTop + 5.5, badgeWidth, 18.5, 1.5, 1.5, 'FD');

  doc.setTextColor(8, 145, 178);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.5);
  doc.text('COMPROBANTE DE PAGO', badgeX + (badgeWidth / 2), yTop + 9.5, { align: 'center' });

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(`NO. #${receipt.id.slice(0, 8).toUpperCase()}`, badgeX + (badgeWidth / 2), yTop + 14.5, { align: 'center' });

  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(5.5);
  doc.text(copyLabel.toUpperCase(), badgeX + (badgeWidth / 2), yTop + 18, { align: 'center' });

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6);
  const formattedDate = `${String(receipt.day).padStart(2, '0')}/${String(receipt.month).padStart(2, '0')}/${receipt.year}`;
  doc.text(`Fecha: ${formattedDate}`, badgeX + (badgeWidth / 2), yTop + 22, { align: 'center' });

  const amountY = yTop + 25.5;
  doc.setFillColor(236, 254, 255);
  doc.setDrawColor(6, 182, 212);
  doc.setLineWidth(0.5);
  doc.roundedRect(x + 3.5, amountY, w - 7, 13, 1.5, 1.5, 'FD');

  doc.setTextColor(14, 116, 144);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.text('VALOR TOTAL LIQUIDADO:', x + 6.5, amountY + 4.5);

  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text(`Q ${receipt.amount.toFixed(2)}`, x + 6.5, amountY + 10.5);

  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6);
  doc.text('CANTIDAD EN LETRAS:', x + w - 6.5, amountY + 4.5, { align: 'right' });

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  const words = receipt.amountInWords || `${receipt.amount.toFixed(2)} QUETZALES EXACTOS`;
  const splitWords = doc.splitTextToSize(words.toUpperCase(), 110);
  doc.text(splitWords, x + w - 6.5, amountY + 9, { align: 'right' });

  const detailsY = yTop + 40;
  const colW = (w - 10) / 2;

  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(x + 3.5, detailsY, colW, 20.5, 1.5, 1.5, 'FD');

  doc.setFillColor(6, 182, 212);
  doc.rect(x + 3.5, detailsY, 1.8, 20.5, 'F');

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6);
  doc.text('DATOS DEL COLABORADOR / GUARDIA:', x + 7.5, detailsY + 4.5);

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text(receipt.employeeName, x + 7.5, detailsY + 9.5);

  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  const dpiText = receipt.employeeDpi ? `DPI: ${formatDPI(receipt.employeeDpi)}` : 'DPI: Registrado en expediente';
  doc.text(dpiText, x + 7.5, detailsY + 14.5);
  doc.text(`Código ID: #${receipt.employeeId.slice(0, 10).toUpperCase()}`, x + 7.5, detailsY + 18.5);

  const col2X = x + 3.5 + colW + 3;
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(col2X, detailsY, colW, 20.5, 1.5, 1.5, 'FD');

  doc.setFillColor(16, 185, 129);
  doc.rect(col2X, detailsY, 1.8, 20.5, 'F');

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6);
  doc.text('DETALLES DEL PAGO Y TRANSACCIÓN:', col2X + 4, detailsY + 4.5);

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text(`Forma: ${receipt.paymentMethod || 'TRANSFERENCIA BANCARIA'}`, col2X + 4, detailsY + 9.5);

  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  const refText = receipt.referenceNumber ? `Boleta / Ref: ${receipt.referenceNumber}` : 'Liquidación Directa de Sueldo';
  doc.text(refText, col2X + 4, detailsY + 14.5);
  doc.text(`Período / Emisión: Mes ${receipt.month}/${receipt.year}`, col2X + 4, detailsY + 18.5);

  const conceptY = yTop + 62;
  doc.setFillColor(241, 245, 249);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(x + 3.5, conceptY, w - 7, 14, 1.5, 1.5, 'FD');

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6);
  doc.text('POR CONCEPTO DE:', x + 6.5, conceptY + 4);

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  const splitConcept = doc.splitTextToSize(receipt.concept, w - 16);
  doc.text(splitConcept, x + 6.5, conceptY + 8);

  if (receipt.observations) {
    doc.setTextColor(71, 85, 105);
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(6.2);
    const splitObs = doc.splitTextToSize(`Nota: ${receipt.observations}`, w - 16);
    doc.text(splitObs, x + 6.5, conceptY + 12);
  }

  // FIRMA EXCLUSIVA DEL COLABORADOR
  const sigY = yTop + 78;
  const sigLineWidth = 90;
  const sigStartX = x + (w / 2) - (sigLineWidth / 2);

  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.6);
  doc.line(sigStartX, sigY + 24, sigStartX + sigLineWidth, sigY + 24);

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text(receipt.employeeName.toUpperCase(), x + (w / 2), sigY + 28, { align: 'center' });

  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  if (receipt.employeeDpi) {
    doc.text(`DPI: ${formatDPI(receipt.employeeDpi)}`, x + (w / 2), sigY + 31.5, { align: 'center' });
  }

  doc.setTextColor(8, 145, 178);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.text('FIRMA DE CONFORME / RECIBIDO (COLABORADOR)', x + (w / 2), sigY + (receipt.employeeDpi ? 35.5 : 33), { align: 'center' });

  const footerY = yTop + voucherHeight - 4;
  doc.setTextColor(148, 163, 184);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(5.5);
  doc.text('Este documento constituye comprobante oficial de liquidación salarial emitido conforme a la legislación laboral de Guatemala.', x + 6, footerY);
  doc.text(`ID: ${receipt.id}`, x + w - 6, footerY, { align: 'right' });
}

/**
 * Exporta un recibo individual en Hoja Tamaño Carta COMPLETA (1 por Hoja Carta).
 * Requisito: "solo colocar los recibos uno por uno, al visualizar al colaborador".
 */
export async function exportReceiptToPDF(
  receipt: PaymentReceipt,
  companyName: string = 'GUARDIA REAL DE GUATEMALA',
  companyNit: string = 'NIT: 9812401-2'
): Promise<void> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'letter', // 215.9 x 279.4 mm
  });

  drawSingleVoucherLetterPage(doc, receipt, companyName, companyNit);

  const cleanEmpName = receipt.employeeName.replace(/[^a-zA-Z0-9]/g, '_');
  const fileName = `Recibo_Carta_${cleanEmpName}_${receipt.id.slice(0, 8)}.pdf`;
  doc.save(fileName);
}

/**
 * Exporta múltiples recibos en un único PDF, pero colocando CADA RECIBO UNO POR UNO en su propia hoja carta.
 * Requisito: "solo colocar los recibos uno por uno, al visualizar al colaborador".
 */
export async function exportMultipleReceiptsOneByOne(
  receipts: PaymentReceipt[],
  options?: {
    employeeName?: string;
    companyName?: string;
    companyNit?: string;
    filePrefix?: string;
  }
): Promise<void> {
  if (receipts.length === 0) {
    throw new Error('No hay recibos para exportar.');
  }

  const {
    employeeName,
    companyName = 'GUARDIA REAL DE GUATEMALA',
    companyNit = 'NIT: 9812401-2',
    filePrefix = 'Recibos_UnoPorUno'
  } = options || {};

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'letter',
  });

  receipts.forEach((receipt, index) => {
    if (index > 0) {
      doc.addPage('letter', 'portrait');
    }
    drawSingleVoucherLetterPage(doc, receipt, companyName, companyNit);
  });

  const cleanName = (employeeName || 'Guardias').replace(/[^a-zA-Z0-9]/g, '_');
  doc.save(`${filePrefix}_${cleanName}_${receipts.length}recibos.pdf`);
}

/**
 * Exporta recibos uniendo 2 recibos por cada hoja tamaño carta (con línea de corte).
 */
export async function exportQuincenaReceiptsToPDF(
  options: QuincenaExportOptions
): Promise<void> {
  const {
    receipts,
    employeeName,
    periodLabel,
    companyName = 'GUARDIA REAL DE GUATEMALA',
    companyNit = 'NIT: 9812401-2'
  } = options;

  if (receipts.length === 0) {
    throw new Error('No hay recibos disponibles para exportar.');
  }

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'letter',
  });

  const cutY = LETTER_HEIGHT_MM / 2;

  if (receipts.length === 1) {
    const singleReceipt = receipts[0];
    doc.setFillColor(255, 255, 255);
    doc.rect(0, 0, LETTER_WIDTH_MM, LETTER_HEIGHT_MM, 'F');

    drawVoucherOnDoc(doc, singleReceipt, 7, VOUCHER_HEIGHT, 'ORIGINAL - ADMINISTRACIÓN', companyName, companyNit);

    doc.setLineDashPattern([2, 2], 0);
    doc.setDrawColor(148, 163, 184);
    doc.setLineWidth(0.3);
    doc.line(VOUCHER_MARGIN_X, cutY, LETTER_WIDTH_MM - VOUCHER_MARGIN_X, cutY);
    doc.setLineDashPattern([], 0);
    doc.setFontSize(6.2);
    doc.setTextColor(100, 116, 139);
    doc.text('✂ - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - LÍNEA DE CORTE - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ✂', LETTER_WIDTH_MM / 2, cutY + 0.5, { align: 'center' });

    drawVoucherOnDoc(doc, singleReceipt, 146, VOUCHER_HEIGHT, 'COPIA - COLABORADOR', companyName, companyNit);
  } else {
    for (let i = 0; i < receipts.length; i += 2) {
      if (i > 0) {
        doc.addPage('letter', 'portrait');
      }

      doc.setFillColor(255, 255, 255);
      doc.rect(0, 0, LETTER_WIDTH_MM, LETTER_HEIGHT_MM, 'F');

      const receipt1 = receipts[i];
      const receipt2 = receipts[i + 1];

      drawVoucherOnDoc(
        doc,
        receipt1,
        7,
        VOUCHER_HEIGHT,
        `COMPROBANTE 1 - ${periodLabel}`,
        companyName,
        companyNit
      );

      doc.setLineDashPattern([2, 2], 0);
      doc.setDrawColor(148, 163, 184);
      doc.setLineWidth(0.3);
      doc.line(VOUCHER_MARGIN_X, cutY, LETTER_WIDTH_MM - VOUCHER_MARGIN_X, cutY);
      doc.setLineDashPattern([], 0);
      doc.setFontSize(6.2);
      doc.setTextColor(100, 116, 139);
      doc.text('✂ - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - LÍNEA DE CORTE - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ✂', LETTER_WIDTH_MM / 2, cutY + 0.5, { align: 'center' });

      if (receipt2) {
        drawVoucherOnDoc(
          doc,
          receipt2,
          146,
          VOUCHER_HEIGHT,
          `COMPROBANTE 2 - ${periodLabel}`,
          companyName,
          companyNit
        );
      } else {
        drawVoucherOnDoc(
          doc,
          receipt1,
          146,
          VOUCHER_HEIGHT,
          'COPIA - COLABORADOR',
          companyName,
          companyNit
        );
      }
    }
  }

  const cleanPeriod = periodLabel.replace(/[^a-zA-Z0-9]/g, '_');
  const cleanName = (employeeName || 'Guardias').replace(/[^a-zA-Z0-9]/g, '_');
  const fileName = `Recibos_HojaCarta_2en1_${cleanName}_${cleanPeriod}.pdf`;
  doc.save(fileName);
}

/**
 * Genera el documento del HISTÓRICO DE RECIBOS EMITIDOS (en Hoja Carta).
 * Cumple con el requisito: "colocar boton que permita descargar es historico de los recibos que se han dado,
 * y elegir entre quincena 1ra o 2da en la pestaña de trabjadores".
 */
export async function exportReceiptsHistoryReportToPDF(
  options: ReceiptsHistoryReportOptions
): Promise<void> {
  const {
    receipts,
    periodLabel,
    quincenaFilter = 'ALL',
    month,
    year,
    companyName = 'GUARDIA REAL DE GUATEMALA',
    companyNit = 'NIT: 9812401-2',
    generatedBy = 'Administración Central'
  } = options;

  if (receipts.length === 0) {
    throw new Error('No hay recibos en el período seleccionado para exportar el histórico.');
  }

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'letter', // 215.9 x 279.4 mm
  });

  const margin = 12;
  const contentWidth = LETTER_WIDTH_MM - (margin * 2); // 191.9 mm

  // Métricas del Histórico
  const totalAmount = receipts.reduce((sum, r) => sum + r.amount, 0);
  const uniqueEmployees = new Set(receipts.map(r => r.employeeId)).size;
  const totalTransfers = receipts.filter(r => r.paymentMethod === 'TRANSFERENCIA').reduce((sum, r) => sum + r.amount, 0);
  const totalCheques = receipts.filter(r => r.paymentMethod === 'CHEQUE').reduce((sum, r) => sum + r.amount, 0);
  const totalCash = receipts.filter(r => r.paymentMethod === 'EFECTIVO').reduce((sum, r) => sum + r.amount, 0);

  const rowsPerPage = 18;
  const totalPages = Math.ceil(receipts.length / rowsPerPage) || 1;

  for (let page = 0; page < totalPages; page++) {
    if (page > 0) {
      doc.addPage('letter', 'portrait');
    }

    // Fondo blanco
    doc.setFillColor(255, 255, 255);
    doc.rect(0, 0, LETTER_WIDTH_MM, LETTER_HEIGHT_MM, 'F');

    // Marco exterior sutil
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.5);
    doc.roundedRect(margin - 2, margin - 2, contentWidth + 4, LETTER_HEIGHT_MM - (margin * 2) + 4, 3, 3, 'S');

    // Cabecera institucional
    doc.setFillColor(15, 23, 42); // slate-900
    doc.roundedRect(margin, margin, contentWidth, 32, 2.5, 2.5, 'F');
    doc.setFillColor(6, 182, 212); // cyan-500
    doc.rect(margin, margin, contentWidth, 2.2, 'F');

    // Logo
    const logoH = 20;
    try {
      doc.addImage(GUARDIA_REAL_LOGO_BASE64, 'JPEG', margin + 4, margin + 6, logoH, logoH);
    } catch {
      // fallback
    }

    const headTextX = margin + logoH + 7;
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12.5);
    doc.text(companyName.toUpperCase(), headTextX, margin + 11.5);

    doc.setTextColor(148, 163, 184);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.text('CONTROL GENERAL & HISTÓRICO DE RECIBOS DE PAGO EMITIDOS', headTextX, margin + 17);
    doc.text(`${companyNit} · República de Guatemala · Nómina Operativa`, headTextX, margin + 22);
    doc.text(`Generado por: ${generatedBy} · Fecha: ${formatDate(new Date().toISOString().split('T')[0])}`, headTextX, margin + 27);

    // Badge derecho de período
    const badgeW = 62;
    const badgeX = margin + contentWidth - badgeW - 3;
    doc.setFillColor(30, 41, 59);
    doc.roundedRect(badgeX, margin + 5, badgeW, 22, 2, 2, 'F');
    doc.setDrawColor(6, 182, 212);
    doc.setLineWidth(0.4);
    doc.roundedRect(badgeX, margin + 5, badgeW, 22, 2, 2, 'S');

    doc.setTextColor(6, 182, 212);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.8);
    const quincenaTag = quincenaFilter === '1RA_QUINCENA' ? '1RA QUINCENA' : quincenaFilter === '2DA_QUINCENA' ? '2DA QUINCENA' : 'TODAS LAS QUINCENAS';
    doc.text(`FILTRO: ${quincenaTag}`, badgeX + (badgeW / 2), margin + 10.5, { align: 'center' });

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text(periodLabel.toUpperCase(), badgeX + (badgeW / 2), margin + 16.5, { align: 'center' });

    doc.setTextColor(203, 213, 225);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.8);
    doc.text(`Página ${page + 1} de ${totalPages} · Hoja Carta`, badgeX + (badgeW / 2), margin + 22.5, { align: 'center' });

    let currentY = margin + 37;

    // Solo en la página 1 mostramos las tarjetas métricas resumen
    if (page === 0) {
      const metricW = (contentWidth - 9) / 4;
      const mH = 15;

      // Métrica 1: Total Liquidado
      doc.setFillColor(236, 254, 255);
      doc.setDrawColor(8, 145, 178);
      doc.setLineWidth(0.4);
      doc.roundedRect(margin, currentY, metricW, mH, 1.5, 1.5, 'FD');
      doc.setTextColor(14, 116, 144);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.2);
      doc.text('TOTAL GENERAL LIQUIDADO', margin + 3.5, currentY + 4.5);
      doc.setFontSize(10.5);
      doc.setTextColor(15, 23, 42);
      doc.text(`Q ${totalAmount.toFixed(2)}`, margin + 3.5, currentY + 11.5);

      // Métrica 2: Total Recibos
      const m2X = margin + metricW + 3;
      doc.setFillColor(240, 253, 244);
      doc.setDrawColor(22, 163, 74);
      doc.roundedRect(m2X, currentY, metricW, mH, 1.5, 1.5, 'FD');
      doc.setTextColor(21, 128, 61);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.2);
      doc.text('RECIBOS EMITIDOS', m2X + 3.5, currentY + 4.5);
      doc.setFontSize(10.5);
      doc.setTextColor(15, 23, 42);
      doc.text(`${receipts.length} Comprobantes`, m2X + 3.5, currentY + 11.5);

      // Métrica 3: Guardias
      const m3X = margin + (metricW * 2) + 6;
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(100, 116, 139);
      doc.roundedRect(m3X, currentY, metricW, mH, 1.5, 1.5, 'FD');
      doc.setTextColor(71, 85, 105);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.2);
      doc.text('COLABORADORES BENEFICIADOS', m3X + 3.5, currentY + 4.5);
      doc.setFontSize(10.5);
      doc.setTextColor(15, 23, 42);
      doc.text(`${uniqueEmployees} Guardias`, m3X + 3.5, currentY + 11.5);

      // Métrica 4: Desglose Métodos
      const m4X = margin + (metricW * 3) + 9;
      doc.setFillColor(254, 243, 199);
      doc.setDrawColor(217, 119, 6);
      doc.roundedRect(m4X, currentY, metricW, mH, 1.5, 1.5, 'FD');
      doc.setTextColor(180, 83, 9);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6);
      doc.text('MÉTODOS DE PAGO', m4X + 3, currentY + 4.5);
      doc.setFontSize(6.5);
      doc.setTextColor(15, 23, 42);
      doc.text(`Transf: Q${totalTransfers.toFixed(0)} · Efec: Q${totalCash.toFixed(0)}`, m4X + 3, currentY + 11.5);

      currentY += mH + 5;
    }

    // Cabecera de la Tabla
    doc.setFillColor(15, 23, 42);
    doc.roundedRect(margin, currentY, contentWidth, 7, 1.2, 1.2, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.8);

    const cNo = margin + 3;
    const cFecha = margin + 20;
    const cEmp = margin + 38;
    const cDpi = margin + 85;
    const cConcept = margin + 115;
    const cMetodo = margin + 154;
    const cMonto = margin + contentWidth - 3;

    doc.text('No. Recibo', cNo, currentY + 4.8);
    doc.text('Fecha', cFecha, currentY + 4.8);
    doc.text('Colaborador / Guardia', cEmp, currentY + 4.8);
    doc.text('DPI (CUI)', cDpi, currentY + 4.8);
    doc.text('Concepto / Quincena', cConcept, currentY + 4.8);
    doc.text('Método / Ref', cMetodo, currentY + 4.8);
    doc.text('Monto', cMonto, currentY + 4.8, { align: 'right' });

    currentY += 7.5;

    // Filas de comprobantes para esta página
    const startIdx = page * rowsPerPage;
    const pageReceipts = receipts.slice(startIdx, startIdx + rowsPerPage);

    pageReceipts.forEach((r, idx) => {
      const isEven = idx % 2 === 0;
      doc.setFillColor(isEven ? 255 : 248, isEven ? 255 : 250, isEven ? 255 : 252);
      doc.setDrawColor(226, 232, 240);
      doc.rect(margin, currentY, contentWidth, 7.8, 'FD');

      doc.setTextColor(14, 116, 144);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.8);
      doc.text(`#${r.id.slice(0, 7).toUpperCase()}`, cNo, currentY + 5.2);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(71, 85, 105);
      const rDate = `${String(r.day).padStart(2, '0')}/${String(r.month).padStart(2, '0')}/${r.year}`;
      doc.text(rDate, cFecha, currentY + 5.2);

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
      const shortEmp = r.employeeName.length > 26 ? r.employeeName.slice(0, 24) + '...' : r.employeeName;
      doc.text(shortEmp, cEmp, currentY + 5.2);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(71, 85, 105);
      doc.text(r.employeeDpi ? formatDPI(r.employeeDpi) : '—', cDpi, currentY + 5.2);

      const shortConcept = r.concept.length > 25 ? r.concept.slice(0, 23) + '..' : r.concept;
      doc.text(shortConcept, cConcept, currentY + 5.2);

      const refStr = r.referenceNumber ? ` (${r.referenceNumber.slice(0, 7)})` : '';
      const methodStr = `${(r.paymentMethod || 'TRANSF').slice(0, 6)}${refStr}`;
      doc.text(methodStr, cMetodo, currentY + 5.2);

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text(`Q ${r.amount.toFixed(2)}`, cMonto, currentY + 5.2, { align: 'right' });

      currentY += 7.8;
    });

    // En la última página mostramos el total y la firma de auditoría
    if (page === totalPages - 1) {
      doc.setFillColor(241, 245, 249);
      doc.setDrawColor(203, 213, 225);
      doc.setLineWidth(0.5);
      doc.rect(margin, currentY, contentWidth, 8.5, 'FD');

      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.text(`TOTAL HISTÓRICO GENERAL (${receipts.length} COMPROBANTES):`, cConcept, currentY + 5.5);

      doc.setTextColor(8, 145, 178);
      doc.setFontSize(9.5);
      doc.text(`Q ${totalAmount.toFixed(2)}`, cMonto, currentY + 5.5, { align: 'right' });

      currentY += 15;

      // Sección de Control y Auditoría
      if (currentY + 28 <= LETTER_HEIGHT_MM - margin) {
        const sigWidth = 85;
        const sigX = margin + (contentWidth / 2) - (sigWidth / 2);

        doc.setDrawColor(15, 23, 42);
        doc.setLineWidth(0.6);
        doc.line(sigX, currentY + 16, sigX + sigWidth, currentY + 16);

        doc.setTextColor(15, 23, 42);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.8);
        doc.text('ADMINISTRACIÓN & AUDITORÍA DE NÓMINA', margin + (contentWidth / 2), currentY + 20.5, { align: 'center' });

        doc.setTextColor(100, 116, 139);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(6.8);
        doc.text('Control y Arqueo Oficial de Comprobantes de Pago · Guardia Real GT', margin + (contentWidth / 2), currentY + 24.5, { align: 'center' });
      }
    }

    // Pie de página
    const footY = LETTER_HEIGHT_MM - margin - 2;
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.4);
    doc.line(margin, footY - 3, margin + contentWidth, footY - 3);

    doc.setTextColor(148, 163, 184);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.text(`Reporte Oficial de Nómina · Hoja Tamaño Carta · ${companyName}`, margin, footY);
    doc.text(`Página ${page + 1} de ${totalPages} · ${formatDateTime(new Date().toISOString())}`, margin + contentWidth, footY, { align: 'right' });
  }

  const cleanPeriod = periodLabel.replace(/[^a-zA-Z0-9]/g, '_');
  const fileName = `Historico_Recibos_Carta_${cleanPeriod}.pdf`;
  doc.save(fileName);
}

/**
 * Genera el estado consolidado de pagos y recibos en Hoja Tamaño Carta.
 */
export async function exportEmployeePaymentsStatementToPDF(
  options: EmployeeStatementExportOptions
): Promise<void> {
  const {
    employee,
    receipts,
    payments = [],
    month,
    year,
    companyName = 'GUARDIA REAL DE GUATEMALA',
    companyNit = 'NIT: 9812401-2',
    companyAddress = 'Ciudad de Guatemala, Guatemala',
    generatedBy = 'Administración Central'
  } = options;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'letter',
  });

  const margin = 12;
  const contentWidth = LETTER_WIDTH_MM - (margin * 2);

  const filteredReceipts = receipts.filter(
    r => r.employeeId === employee.id && r.month === month && r.year === year
  );

  const monthName = MONTH_NAMES[month - 1] || `Mes ${month}`;
  const totalAmountPaid = filteredReceipts.reduce((sum, r) => sum + r.amount, 0);

  doc.setFillColor(255, 255, 255);
  doc.rect(0, 0, LETTER_WIDTH_MM, LETTER_HEIGHT_MM, 'F');

  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.6);
  doc.roundedRect(margin - 2, margin - 2, contentWidth + 4, LETTER_HEIGHT_MM - (margin * 2) + 4, 3, 3, 'S');

  doc.setFillColor(15, 23, 42);
  doc.roundedRect(margin, margin, contentWidth, 34, 2.5, 2.5, 'F');

  doc.setFillColor(6, 182, 212);
  doc.rect(margin, margin, contentWidth, 2.2, 'F');

  const logoH = 22;
  try {
    doc.addImage(GUARDIA_REAL_LOGO_BASE64, 'JPEG', margin + 4, margin + 6, logoH, logoH);
  } catch {
    // Fallback
  }

  const headTextX = margin + logoH + 8;
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text(companyName.toUpperCase(), headTextX, margin + 12);

  doc.setTextColor(148, 163, 184);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.8);
  doc.text('Departamento de Nómina & Operaciones de Seguridad Privada', headTextX, margin + 18);
  doc.text(`${companyNit} · ${companyAddress}`, headTextX, margin + 23);
  doc.text(`Documento emitido para: ${employee.name}`, headTextX, margin + 28);

  const badgeW = 60;
  const badgeX = margin + contentWidth - badgeW - 3;
  doc.setFillColor(30, 41, 59);
  doc.roundedRect(badgeX, margin + 5.5, badgeW, 23, 2, 2, 'F');
  doc.setDrawColor(6, 182, 212);
  doc.setLineWidth(0.4);
  doc.roundedRect(badgeX, margin + 5.5, badgeW, 23, 2, 2, 'S');

  doc.setTextColor(6, 182, 212);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.text('ESTADO DE CUENTA LABORAL', badgeX + (badgeW / 2), margin + 11, { align: 'center' });

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.text(`${monthName.toUpperCase()} ${year}`, badgeX + (badgeW / 2), margin + 18, { align: 'center' });

  doc.setTextColor(203, 213, 225);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  doc.text(`Hoja Carta · ${formatDate(new Date().toISOString().split('T')[0])}`, badgeX + (badgeW / 2), margin + 24, { align: 'center' });

  let currentY = margin + 39;

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('DETALLE CONSOLIDADO DE PAGOS Y RECIBOS', margin, currentY);

  currentY += 5;

  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.4);
  doc.roundedRect(margin, currentY, contentWidth, 31, 2, 2, 'FD');

  doc.setFillColor(6, 182, 212);
  doc.rect(margin, currentY, 2.5, 31, 'F');

  const c1 = margin + 6;
  const c2 = margin + 70;
  const c3 = margin + 132;

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.text('COLABORADOR:', c1, currentY + 6.5);
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9.5);
  doc.text(employee.name, c1, currentY + 13);
  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.2);
  doc.text(`Puesto: ${employee.position || 'Guardia de Seguridad'}`, c1, currentY + 19.5);
  doc.text(`DPI: ${formatDPI(employee.dpi) || 'No registrado'}`, c1, currentY + 25.5);

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.text('CONDICIONES SALARIALES:', c2, currentY + 6.5);
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(8.5);
  doc.text(`Salario Base: Q ${(employee.monthlySalary || 0).toFixed(2)}`, c2, currentY + 13);
  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.2);
  doc.text(`Retención IGSS: ${employee.appliesIGSS !== false ? 'Aplica (4.83%)' : 'No Aplica'}`, c2, currentY + 19.5);
  doc.text(`Estado: ${employee.status === 'ACTIVO' ? 'Colaborador Activo' : 'De Baja'}`, c2, currentY + 25.5);

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.text('FORMA DE COBRO:', c3, currentY + 6.5);
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(8.5);
  doc.text(employee.paymentMethodPreference || 'TRANSFERENCIA', c3, currentY + 13);
  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.2);
  doc.text(`Banco: ${employee.bankName || 'General'}`, c3, currentY + 19.5);
  doc.text(`Cuenta: ${employee.bankAccountNumber || 'No especificada'}`, c3, currentY + 25.5);

  currentY += 36;

  const mW = (contentWidth - 6) / 3;

  doc.setFillColor(236, 254, 255);
  doc.setDrawColor(8, 145, 178);
  doc.roundedRect(margin, currentY, mW, 18, 1.8, 1.8, 'FD');
  doc.setTextColor(14, 116, 144);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.text('TOTAL RECIBOS LIQUIDADOS', margin + 4, currentY + 5.5);
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text(`Q ${totalAmountPaid.toFixed(2)}`, margin + 4, currentY + 14);

  const m2X = margin + mW + 3;
  doc.setFillColor(240, 253, 244);
  doc.setDrawColor(22, 163, 74);
  doc.roundedRect(m2X, currentY, mW, 18, 1.8, 1.8, 'FD');
  doc.setTextColor(21, 128, 61);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.text('COMPROBANTES EMITIDOS', m2X + 4, currentY + 5.5);
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text(`${filteredReceipts.length} Comprobante(s)`, m2X + 4, currentY + 14);

  const m3X = margin + (mW * 2) + 6;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(m3X, currentY, mW, 18, 1.8, 1.8, 'FD');
  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.text('SALARIO MENSUAL BASE', m3X + 4, currentY + 5.5);
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text(`Q ${(employee.monthlySalary || 0).toFixed(2)}`, m3X + 4, currentY + 14);

  currentY += 23;

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(`Historial de Comprobantes de Pago (${monthName} ${year})`, margin, currentY);

  currentY += 4;

  doc.setFillColor(15, 23, 42);
  doc.roundedRect(margin, currentY, contentWidth, 7, 1.2, 1.2, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);

  const colFecha = margin + 3;
  const colNo = margin + 22;
  const colConcepto = margin + 50;
  const colMetodo = margin + 118;
  const colRef = margin + 152;
  const colMonto = margin + contentWidth - 4;

  doc.text('Fecha', colFecha, currentY + 4.8);
  doc.text('No. Recibo', colNo, currentY + 4.8);
  doc.text('Concepto / Liquidación', colConcepto, currentY + 4.8);
  doc.text('Método', colMetodo, currentY + 4.8);
  doc.text('Referencia', colRef, currentY + 4.8);
  doc.text('Monto', colMonto, currentY + 4.8, { align: 'right' });

  currentY += 7.5;

  if (filteredReceipts.length === 0) {
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.rect(margin, currentY, contentWidth, 14, 'FD');
    doc.setTextColor(100, 116, 139);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`No se registraron recibos de pago emitidos para ${monthName} de ${year}.`, margin + (contentWidth / 2), currentY + 8.5, { align: 'center' });
    currentY += 18;
  } else {
    filteredReceipts.forEach((r, idx) => {
      const isEven = idx % 2 === 0;
      doc.setFillColor(isEven ? 255 : 248, isEven ? 255 : 250, isEven ? 255 : 252);
      doc.setDrawColor(226, 232, 240);
      doc.rect(margin, currentY, contentWidth, 7.5, 'FD');

      doc.setTextColor(71, 85, 105);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.2);

      const rDate = `${String(r.day).padStart(2, '0')}/${String(r.month).padStart(2, '0')}/${r.year}`;
      doc.text(rDate, colFecha, currentY + 5);

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(14, 116, 144);
      doc.text(`#${r.id.slice(0, 8).toUpperCase()}`, colNo, currentY + 5);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(15, 23, 42);
      const shortConcept = r.concept.length > 40 ? r.concept.slice(0, 38) + '...' : r.concept;
      doc.text(shortConcept, colConcepto, currentY + 5);

      doc.setTextColor(71, 85, 105);
      doc.text(r.paymentMethod || 'TRANSFERENCIA', colMetodo, currentY + 5);

      const refText = r.referenceNumber ? r.referenceNumber.slice(0, 12) : '—';
      doc.text(refText, colRef, currentY + 5);

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text(`Q ${r.amount.toFixed(2)}`, colMonto, currentY + 5, { align: 'right' });

      currentY += 7.5;
    });

    doc.setFillColor(241, 245, 249);
    doc.setDrawColor(203, 213, 225);
    doc.setLineWidth(0.4);
    doc.rect(margin, currentY, contentWidth, 8, 'FD');
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.8);
    doc.text('TOTAL GENERAL PERÍODO:', colConcepto, currentY + 5.2);
    doc.setTextColor(8, 145, 178);
    doc.setFontSize(8.8);
    doc.text(`Q ${totalAmountPaid.toFixed(2)}`, colMonto, currentY + 5.2, { align: 'right' });

    currentY += 12;
  }

  // FIRMA EXCLUSIVA DEL COLABORADOR
  currentY = Math.max(currentY, 225);
  const sigLineWidth = 95;
  const sigX = margin + (contentWidth / 2) - (sigLineWidth / 2);

  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.6);
  doc.line(sigX, currentY + 16, sigX + sigLineWidth, currentY + 16);

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text(employee.name.toUpperCase(), margin + (contentWidth / 2), currentY + 21, { align: 'center' });

  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  if (employee.dpi) {
    doc.text(`DPI: ${formatDPI(employee.dpi)}`, margin + (contentWidth / 2), currentY + 25.5, { align: 'center' });
  }

  doc.setTextColor(8, 145, 178);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text('FIRMA DE CONFORME / RECIBIDO (COLABORADOR)', margin + (contentWidth / 2), currentY + (employee.dpi ? 30 : 27), { align: 'center' });

  const footY = LETTER_HEIGHT_MM - margin - 3;
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.4);
  doc.line(margin, footY - 3, margin + contentWidth, footY - 3);

  doc.setTextColor(148, 163, 184);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.text('Constancia confidencial emitida en hoja tamaño carta · Guardia Real de Guatemala.', margin, footY);
  doc.text(`Emisión: ${formatDateTime(new Date().toISOString())}`, margin + contentWidth, footY, { align: 'right' });

  const cleanName = employee.name.replace(/[^a-zA-Z0-9]/g, '_');
  const fileName = `Detalle_Pagos_Recibos_Carta_${cleanName}_${monthName}_${year}.pdf`;
  doc.save(fileName);
}
