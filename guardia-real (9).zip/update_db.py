import json
import uuid

# Load current DB
with open('data/db.json', 'r') as f:
    db = json.load(f)

# Clear existing companies and employees
db['companies'] = []
db['employees'] = []

# New data based on the provided PDF
companies_data = [
    {"id": "comp-1", "name": "PIEDRA AZUL", "employees": [
        {"name": "FREDY ABEL VASQUEZ RAMOS", "startDate": "2025-10-20"},
        {"name": "KENGLER ABRAHAM MIRANDA GONZALEZ", "startDate": "2026-08-05", "endDate": "2026-10-01", "status": "DE_BAJA"},
        {"name": "MARTIN CHUB MAQUIN", "startDate": "2026-02-19"}
    ]},
    {"id": "comp-2", "name": "COUNTRY CLUB", "employees": [
        {"name": "FAUSTINO VASQUEZ MALDONADO", "startDate": "2025-02-01"}
    ]},
    {"id": "comp-3", "name": "HOTEL BELLA LUNA", "employees": [
        {"name": "CARLOS ISMAEL GOMEZ PEREZ", "startDate": "2025-03-01"}
    ]},
    {"id": "comp-4", "name": "EL BRINDIS", "employees": [
        {"name": "EMERSON KEVIN DUBUISSON CAAL", "startDate": "2026-06-17"}
    ]},
    {"id": "comp-5", "name": "FERMAC", "employees": [
        {"name": "RAMIRO MENA MENDEZ", "startDate": "2025-04-06"},
        {"name": "GELBER FILOMENO OSORIO MARTINEZ", "startDate": "2025-05-03"}
    ]},
    {"id": "comp-6", "name": "FERMAC QUICHE", "employees": [
        {"name": "TEBANDO ACEVEDO SAGASTUME", "startDate": "2025-10-04"},
        {"name": "JOSE PEREZ GOMEZ", "startDate": "2026-07-30"}
    ]},
    {"id": "comp-7", "name": "DESCANSEROS", "employees": [
        {"name": "LEONEL OSORIO", "startDate": "2026-04-01"}
    ]},
    {"id": "comp-8", "name": "BAZAR CHINO SAN MATEO", "employees": [
        {"name": "BRANDI FLORENTIN AVILA MACARIO", "startDate": "2025-06-20"}
    ]},
    {"id": "comp-9", "name": "RELAMPAGO", "employees": [
        {"name": "ARMANDO AGUSTIN LOPEZ GARCIA", "startDate": "2026-06-24"}
    ]},
    {"id": "comp-10", "name": "RELAMPAGO HUEHUE", "employees": [
        {"name": "ENRIQUE CASTRO MENDOZA", "startDate": "2025-06-20"}
    ]},
    {"id": "comp-11", "name": "SAN BARTOLOMÉ 25 AV", "employees": [
        {"name": "VICTOR ADOLFO PAZ DARDON", "startDate": "2026-03-02"},
        {"name": "DIEGO MOISES MIRANDA COLOP", "startDate": "2026-10-12"}
    ]},
    {"id": "comp-12", "name": "SAN BARTOLOMÉ 29 AV", "employees": [
        {"name": "HECTOR GOMEZ OXLAJ", "startDate": "2025-01-18"}
    ]},
    {"id": "comp-13", "name": "HOTEL CENTENARIO", "employees": [
        {"name": "EDWIN NOE CORTEZ SACALXOT", "startDate": "2026-02-25"}
    ]},
    {"id": "comp-14", "name": "CENDALA", "employees": [
        {"name": "SERGIO ENRIQUE LOPEZ LOPEZ", "startDate": "2026-03-02"},
        {"name": "AUGUSTO SEM CEBALLOS", "startDate": "2026-02-02"}
    ]},
    {"id": "comp-15", "name": "ITALPIEL", "employees": [
        {"name": "CRESENCIO CRUZ LOPEZ OROZCO", "startDate": "2025-12-10"},
        {"name": "EDGAR RONALDO RAMOS QUIXTAN", "startDate": "2026-02-17"}
    ]},
    {"id": "comp-16", "name": "TEXACO", "employees": [
        {"name": "MARTIN CHUB MAQUIN", "startDate": "2026-02-19"},
        {"name": "GUSTAVO FRÍAS DIAZ", "startDate": "2026-06-05"}
    ]},
    {"id": "comp-17", "name": "COCA COLA REU", "employees": [
        {"name": "PEDRO ROCAEL SACALXOT CHACHALAC", "startDate": "2026-10-02"},
        {"name": "PEDRO PELICO", "startDate": "2026-02-14"},
        {"name": "FRISLI JAVIER PELICO COYOY", "startDate": "2026-04-15"},
        {"name": "MARCOS FELIPE VICENTE YAC", "startDate": "2026-05-08"},
        {"name": "MARBIN ELISEO ECOM SOLIS", "startDate": "2026-07-23"}
    ]},
    {"id": "comp-18", "name": "BAZAR CHINO XELA", "employees": [
        {"name": "SAMUEL CRUZ", "startDate": "2026-09-17"},
        {"name": "RODOLFO MARCELINO CRUZ MENDOZA", "startDate": "2026-09-16"}
    ]},
    {"id": "comp-19", "name": "COMERCIAL EL ROSARIO", "employees": [
        {"name": "AVILIO YOVANI MENDEZ QUICHE", "startDate": "2026-09-16"}
    ]},
    {"id": "comp-20", "name": "COMERCIAL MACEDONIA", "employees": [
        {"name": "RENE RIVERA NORIEGA", "startDate": "2026-08-01"},
        {"name": "ELMER LEONARDO MARTINEZ GUTIERREZ", "startDate": "2026-09-16"}
    ]},
    {"id": "comp-21", "name": "BAZAR CHINO Z 8", "employees": [
        {"name": "OSCAR DAVID GARCÍA", "startDate": "2026-07-23", "endDate": "2026-10-12", "status": "DE_BAJA"},
        {"name": "PEDRO MARCOS", "startDate": "2026-08-25", "endDate": "2026-10-01", "status": "DE_BAJA"},
        {"name": "RIGOBERTO PINTO LUCAS", "startDate": "2026-10-12"}
    ]},
    {"id": "comp-22", "name": "CIUDAD DE LOS ALTOS", "employees": [
        {"name": "JESUS ANTONIO PEREZ MORALES", "startDate": "2026-05-12"},
        {"name": "JOSUE SALOMON VARGAS LOPEZ", "startDate": "2025-07-23"},
        {"name": "EDWIN VILLAGRAN", "startDate": "2026-06-12", "endDate": "2026-09-30", "status": "DE_BAJA"},
        {"name": "RODRIGO GOMEZ", "startDate": "2026-06-12", "endDate": "2026-09-30", "status": "DE_BAJA"},
        {"name": "ADOLFO GABINO BULUX TAX", "startDate": "2026-10-01"},
        {"name": "JOSE ISAAC CHACAJ SANCHEZ", "startDate": "2026-10-03"}
    ]},
    {"id": "comp-23", "name": "BAZAR CHINO TERMINAL", "employees": [
        {"name": "RIGOBERTO PINTO LUCAS", "startDate": "2026-08-12", "endDate": "2026-10-01", "status": "DE_BAJA"},
        {"name": "OSCAR MORALES", "startDate": "2029-09-08"},
        {"name": "VICTOR ADOLFO PAZ DARDON", "startDate": "2026-02-03"}
    ]}
]

for c in companies_data:
    db['companies'].append({
        "id": c['id'],
        "name": c['name'],
        "createdAt": "2026-01-01T08:00:00Z",
        "updatedAt": "2026-01-01T08:00:00Z"
    })
    for e in c['employees']:
        emp_id = f"emp-{uuid.uuid4().hex[:8]}"
        db['employees'].append({
            "id": emp_id,
            "companyId": c['id'],
            "name": e['name'],
            "position": "Guardia de Seguridad",
            "monthlySalary": 4200,
            "appliesIGSS": True,
            "startDate": e['startDate'],
            "endDate": e.get('endDate'),
            "status": e.get('status', 'ACTIVO'),
            "createdAt": "2026-01-01T08:00:00Z",
            "updatedAt": "2026-01-01T08:00:00Z",
            "lastModifiedBy": "Administrador Principal"
        })

with open('data/db.json', 'w') as f:
    json.dump(db, f, indent=2)
