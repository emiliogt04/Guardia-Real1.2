import json

with open('data/db.json', 'r') as f:
    db = json.load(f)

# Crear un mapa de nombre a PIN de usuario
user_pin_map = {u['name']: u.get('personalAccessCode') for u in db['users']}

# Actualizar el pinCode en el objeto Employee si existe en el mapa de usuarios
for emp in db['employees']:
    if emp['name'] in user_pin_map:
        emp['pinCode'] = user_pin_map[emp['name']]

with open('data/db.json', 'w') as f:
    json.dump(db, f, indent=2)
